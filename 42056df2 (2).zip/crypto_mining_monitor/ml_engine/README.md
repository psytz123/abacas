
# Crypto Mining ML Recommendation Engine

> **Update (May 21, 2025)**: Technical issues with the ML recommendation engine have been resolved. See [CHANGELOG.md](./CHANGELOG.md) for details on the fixes implemented.

This module implements the machine learning recommendation engine for the Cryptocurrency Mining Monitoring System. It provides data-driven recommendations to optimize mining operations, including coin switching, power optimization, hardware configuration, maintenance, and upgrade recommendations.

## Table of Contents

- [Overview](#overview)
- [Components](#components)
- [Installation](#installation)
- [Usage](#usage)
- [API Reference](#api-reference)
- [Integration with Web Application](#integration-with-web-application)
- [Development with Mock Data](#development-with-mock-data)
- [Future Enhancements](#future-enhancements)

## Overview

The ML recommendation engine analyzes mining telemetry data, pool performance metrics, and cryptocurrency market data to generate actionable recommendations that help miners maximize profitability and optimize resource utilization. The engine uses gradient boosting models for profitability prediction and Bayesian optimization for power settings optimization.

This implementation focuses on the core functionality described in the ML recommendation architecture document, with an emphasis on:

1. Feature engineering pipeline for processing mining telemetry and market data
2. Implementation of core ML models (gradient boosting and Bayesian optimization)
3. Recommendation generation logic that converts model outputs into actionable recommendations
4. A simple API that the web application can use to retrieve recommendations

## Components

The recommendation engine consists of the following key components:

### Feature Engineering Pipeline

Located in `feature_engineering.py`, this component:
- Processes raw miner telemetry data to extract performance and health metrics
- Transforms pool performance data into profitability and efficiency features
- Processes cryptocurrency market data to extract price dynamics and mining economics
- Combines features from different sources for model training and inference
- Includes a mock data generator for development and testing

### ML Models

Located in the `models` directory:

1. **Profit Prediction Model** (`profit_model.py`):
   - Uses gradient boosting (XGBoost) to predict mining profitability
   - Trained on historical mining and market data
   - Provides profitability forecasts for different cryptocurrencies

2. **Power Optimization Model** (`power_optimizer.py`):
   - Uses Bayesian optimization to find optimal power settings
   - Balances efficiency, hashrate, and hardware health
   - Considers constraints like temperature limits and minimum hashrate

### Recommendation Engine

Located in `recommender.py`, this component:
- Converts model outputs into actionable recommendations
- Applies business rules and user preferences to filter recommendations
- Generates explanations and implementation steps for each recommendation
- Tracks recommendation history to avoid excessive changes

### API

Located in `api.py`, this component:
- Provides a RESTful API for the web application to retrieve recommendations
- Handles data validation and error handling
- Includes endpoints for submitting feedback on recommendations
- Offers a mock data endpoint for testing

## Installation

1. Ensure you have Python 3.8+ installed
2. Install the required dependencies:

```bash
cd ~/crypto_mining_monitor/ml_engine
pip install -r requirements.txt
```

## Usage

### Training Models

To train the ML models with mock data:

```bash
# Train profit prediction model
python -m ml_engine.models.profit_model

# Train power optimization model
python -m ml_engine.models.power_optimizer
```

### Generating Recommendations

To generate recommendations using the trained models:

```python
from ml_engine.feature_engineering import FeatureEngineeringPipeline
from ml_engine.recommender import RecommendationEngine

# Initialize components
pipeline = FeatureEngineeringPipeline()
recommender = RecommendationEngine(
    profit_model_path="path/to/profit_model.joblib",
    power_model_path="path/to/power_optimizer.joblib"
)

# Process features
processed_miner = pipeline.process_miner_telemetry(miner_data)
processed_pool = pipeline.process_pool_performance(pool_data)
processed_market = pipeline.process_market_data(market_data)

# Generate recommendations
recommendations = recommender.generate_all_recommendations(
    processed_miner, processed_pool, processed_market
)

# Access specific recommendation types
coin_recommendations = recommendations.get('coin_switching', [])
power_recommendations = recommendations.get('power_optimization', [])
```

### Starting the API Server

To start the API server:

```bash
python -m ml_engine.api
```

The API will be available at `http://localhost:8000`.

## API Reference

### Endpoints

#### `GET /`
Returns basic API information.

#### `GET /health`
Health check endpoint.

#### `POST /recommendations`
Generates recommendations based on provided data.

**Request Body:**
```json
{
  "miner_telemetry": [
    {
      "miner_id": "miner_001",
      "timestamp": "2025-05-20T12:00:00",
      "hashrate_th_s": 95.5,
      "power_consumption_w": 3200,
      "avg_chip_temp_c": 65.2,
      "max_chip_temp_c": 68.7,
      "fan_speed_percent": 70.0,
      "accepted_shares": 1250,
      "rejected_shares": 5,
      "overclock_profile": "normal"
    }
  ],
  "pool_performance": [
    {
      "worker_id": "worker_001",
      "timestamp": "2025-05-20T12:00:00",
      "effective_hashrate_th_s": 92.3,
      "hashrate_th_s": 95.5,
      "earnings_usd_24h": 12.75,
      "primary_coin": "BTC",
      "merge_mining_enabled": false
    }
  ],
  "market_data": [
    {
      "coin_id": "BTC",
      "timestamp": "2025-05-20T12:00:00",
      "price_usd": 55000.0,
      "network_difficulty": 30000000000000.0,
      "block_reward_usd": 343750.0
    },
    {
      "coin_id": "ETH",
      "timestamp": "2025-05-20T12:00:00",
      "price_usd": 2500.0,
      "network_difficulty": 10000000000000.0,
      "block_reward_usd": 5000.0
    }
  ],
  "user_preferences": {
    "min_improvement_threshold": 0.05,
    "confidence_threshold": 0.7,
    "cooldown_period_hours": 12
  }
}
```

**Response:**
```json
{
  "recommendations": {
    "coin_switching": [
      {
        "id": "123e4567-e89b-12d3-a456-426614174000",
        "type": "coin_switching",
        "miner_id": "miner_001",
        "current_coin": "BTC",
        "recommended_coin": "ETH",
        "improvement_percent": 8.5,
        "confidence": 0.85,
        "reasoning": "Switching from BTC to ETH is projected to increase profitability by 8.5%...",
        "implementation_steps": [
          "Log in to your mining pool account.",
          "Navigate to the worker settings for miner miner_001.",
          "Change the primary mining coin to ETH.",
          "Save the new settings and wait for the changes to take effect (typically 5-10 minutes).",
          "Monitor the miner's performance for the next few hours to ensure stability."
        ],
        "timestamp": "2025-05-21T10:15:30.123456"
      }
    ],
    "power_optimization": [
      {
        "id": "123e4567-e89b-12d3-a456-426614174001",
        "type": "power_optimization",
        "miner_id": "miner_001",
        "current_power": 3200,
        "recommended_power": 3000,
        "power_reduction_percent": 6.25,
        "efficiency_improvement_percent": 4.8,
        "hashrate_impact_percent": -1.2,
        "net_profitability_impact_percent": 3.6,
        "confidence": 0.9,
        "reasoning": "Reducing power to 93.8% of current setting improves energy efficiency by 4.8%...",
        "implementation_steps": [
          "Log in to your miner's administration interface.",
          "Navigate to the power settings for miner miner_001.",
          "Reduce the power limit to 3000W (approximately 94% of current setting).",
          "Save the new settings and monitor the miner for stability over the next 30 minutes.",
          "If the miner shows any instability, gradually increase the power limit until stability is restored."
        ],
        "timestamp": "2025-05-21T10:15:30.123456"
      }
    ]
  },
  "timestamp": "2025-05-21T10:15:30.123456",
  "request_id": "123e4567-e89b-12d3-a456-426614174002"
}
```

#### `GET /mock-data`
Returns mock data for testing.

#### `POST /feedback`
Submits feedback on a recommendation.

**Request Body:**
```json
{
  "recommendation_id": "123e4567-e89b-12d3-a456-426614174000",
  "feedback_type": "implemented",
  "details": "Implemented the recommendation and saw a 4.8% improvement in profitability."
}
```

#### `GET /models`
Lists available ML models.

## Integration with Web Application

The ML recommendation engine integrates with the web application through the API. The web application can:

1. **Retrieve Recommendations**:
   - Make a POST request to `/recommendations` with the current mining data
   - Display the recommendations to the user in the UI
   - Allow users to accept, reject, or implement recommendations

2. **Submit Feedback**:
   - Send user feedback to the `/feedback` endpoint
   - Track the outcomes of implemented recommendations

3. **Development Testing**:
   - Use the `/mock-data` endpoint to get test data during development
   - Test the UI with realistic recommendation examples

### Integration Example

```javascript
// Example of fetching recommendations from the web application
async function fetchRecommendations() {
  const miningData = await collectMiningData();
  
  const response = await fetch('http://localhost:8000/recommendations', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(miningData),
  });
  
  const recommendations = await response.json();
  displayRecommendations(recommendations);
}

// Example of submitting feedback
async function submitFeedback(recommendationId, feedbackType, details) {
  await fetch('http://localhost:8000/feedback', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      recommendation_id: recommendationId,
      feedback_type: feedbackType,
      details: details
    }),
  });
}
```

## Development with Mock Data

For development and testing without real mining data, the engine includes a mock data generator:

```python
from ml_engine.feature_engineering import MockDataGenerator

# Generate mock data
generator = MockDataGenerator(num_miners=5, num_coins=3, days=7, interval_minutes=60)
miner_data, pool_data, market_data = generator.generate_all_data()

# Save to CSV for inspection
miner_data.to_csv('mock_miner_data.csv', index=False)
pool_data.to_csv('mock_pool_data.csv', index=False)
market_data.to_csv('mock_market_data.csv', index=False)
```

The mock data generator creates realistic mining telemetry, pool performance, and market data with temporal patterns and correlations between metrics.

## Future Enhancements

Future versions of the ML recommendation engine will include:

1. **Additional Recommendation Types**:
   - Hardware configuration recommendations
   - Maintenance recommendations
   - Hardware upgrade recommendations

2. **Advanced Models**:
   - LSTM models for time-series forecasting
   - Anomaly detection for hardware issues
   - Reinforcement learning for dynamic optimization

3. **Abacus.AI Integration**:
   - Feature store integration
   - Automated model training
   - Real-time inference
   - Model monitoring and management

4. **Continuous Learning**:
   - Feedback loop integration
   - Concept drift detection
   - Automated retraining

5. **Enhanced Personalization**:
   - User preference learning
   - Risk tolerance adaptation
   - Custom recommendation strategies
