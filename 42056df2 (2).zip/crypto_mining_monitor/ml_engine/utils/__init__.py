"""
Utility functions and shared code for the ML recommendation engine.
"""
