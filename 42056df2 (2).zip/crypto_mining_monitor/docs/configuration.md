
# Configuration

This guide provides detailed information on configuring the Cryptocurrency Mining Monitoring System to meet your specific needs.

## Table of Contents

- [Configuration Overview](#configuration-overview)
- [Environment Variables](#environment-variables)
- [Miner Configuration](#miner-configuration)
- [Pool Configuration](#pool-configuration)
- [Market Data Configuration](#market-data-configuration)
- [Data Pipeline Configuration](#data-pipeline-configuration)
- [ML Engine Configuration](#ml-engine-configuration)
- [Web Application Configuration](#web-application-configuration)
- [Advanced Configuration](#advanced-configuration)

## Configuration Overview

The Cryptocurrency Mining Monitoring System can be configured through several methods:

1. **Environment Variables**: Basic configuration for services and API keys
2. **Configuration Files**: Detailed settings for components
3. **Web Interface**: User-specific settings and preferences
4. **Database**: Persistent configuration storage

Most configuration changes take effect immediately, but some may require service restarts.

## Environment Variables

Environment variables provide the primary method for configuring the system. These can be set in the `.env` file or through your deployment environment.

### Core Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `NODE_ENV` | Environment mode (development, production) | `production` | Yes |
| `PORT` | Web application port | `3000` | No |
| `LOG_LEVEL` | Logging verbosity (debug, info, warn, error) | `info` | No |
| `DATABASE_URL` | Database connection string | - | Yes |
| `REDIS_URL` | Redis connection string | - | Yes |

### API Credentials

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `PROHASHING_API_KEY` | Prohashing.com API key | - | Yes |
| `COINGECKO_API_KEY` | CoinGecko API key | - | No |
| `COINMARKETCAP_API_KEY` | CoinMarketCap API key | - | No |

### Abacus.AI Integration

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `ABACUS_API_KEY` | Abacus.AI API key | - | Yes |
| `ABACUS_PROJECT_ID` | Abacus.AI project ID | - | Yes |
| `ABACUS_FEATURE_STORE_ID` | Abacus.AI feature store ID | - | No |
| `ABACUS_MODEL_DEPLOYMENT_ID` | Abacus.AI model deployment ID | - | No |

### Security Settings

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `JWT_SECRET` | Secret for JWT token generation | - | Yes |
| `JWT_EXPIRY` | JWT token expiry time in seconds | `86400` (24h) | No |
| `COOKIE_SECRET` | Secret for cookie signing | - | Yes |
| `ENABLE_RATE_LIMITING` | Enable API rate limiting | `true` | No |
| `RATE_LIMIT_WINDOW` | Rate limit window in milliseconds | `60000` (1m) | No |
| `RATE_LIMIT_MAX` | Maximum requests per window | `100` | No |

## Miner Configuration

Miner configuration involves setting up connections to your ASIC miners running Vnish firmware.

### Adding Miners

Miners can be added through the web interface:

1. Navigate to Settings > Miners
2. Click "Add Miner"
3. Enter the following information:
   - **Name**: A descriptive name for the miner
   - **IP Address**: The IP address of the miner
   - **Port**: The port for the Vnish API (usually 80)
   - **Username**: The Vnish firmware username (usually "admin")
   - **Password**: The Vnish firmware password
   - **Model**: The miner model (e.g., "Antminer S19")
   - **Location**: Optional location information
   - **Tags**: Optional tags for grouping miners

### Miner Groups

You can organize miners into groups for easier management:

1. Navigate to Settings > Miner Groups
2. Click "Create Group"
3. Enter a name and description for the group
4. Select miners to include in the group
5. Click "Save"

### Polling Configuration

You can configure how frequently the system polls miners for data:

1. Navigate to Settings > Data Collection
2. Under "Miner Polling", set the following:
   - **High-frequency metrics interval**: How often to collect critical metrics (1-5 minutes recommended)
   - **Configuration and status interval**: How often to collect configuration data (15-30 minutes recommended)
   - **Enable adaptive polling**: Automatically adjust polling frequency based on miner status
   - **Minimum polling interval**: Minimum time between polls (1 minute recommended)
   - **Maximum polling interval**: Maximum time between polls (30 minutes recommended)

### Configuration File

For advanced configuration, you can edit the miner configuration file:

```bash
# For Docker installation
nano config/miners.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/miners.yaml
```

Example configuration:

```yaml
miners:
  - id: miner_01
    name: "Rack 1 - S19 Pro"
    ip: "192.168.1.101"
    port: 80
    username: "admin"
    password: "${MINER_PASSWORD}"
    model: "ANTMINER_S19_Pro"
    location: "Data Center 1"
    tags: ["rack1", "high_performance"]
    polling:
      high_frequency_interval_seconds: 300
      status_interval_seconds: 1800
      adaptive: true
  
  - id: miner_02
    name: "Rack 1 - S19j"
    ip: "192.168.1.102"
    port: 80
    username: "admin"
    password: "${MINER_PASSWORD}"
    model: "ANTMINER_S19j"
    location: "Data Center 1"
    tags: ["rack1", "standard"]
    polling:
      high_frequency_interval_seconds: 300
      status_interval_seconds: 1800
      adaptive: true
```

## Pool Configuration

Pool configuration involves setting up connections to mining pools, particularly Prohashing.com for merge mining.

### Adding Pools

Pools can be added through the web interface:

1. Navigate to Settings > Pools
2. Click "Add Pool"
3. Enter the following information:
   - **Name**: A descriptive name for the pool
   - **Type**: Select "Prohashing"
   - **API Key**: Your Prohashing API key
   - **Worker IDs**: Comma-separated list of your worker IDs
   - **Default Algorithm**: The primary mining algorithm (e.g., "Scrypt")

### Pool Data Collection

Configure how the system collects data from mining pools:

1. Navigate to Settings > Data Collection
2. Under "Pool Data Collection", set the following:
   - **Worker status interval**: How often to collect worker status (5-10 minutes recommended)
   - **Profitability data interval**: How often to collect profitability data (15-30 minutes recommended)
   - **Historical data interval**: How often to collect historical data (1-6 hours recommended)
   - **Enable WAMP connection**: Use WebSocket for real-time updates (recommended)
   - **WAMP reconnect interval**: How often to attempt reconnection if disconnected

### Configuration File

For advanced configuration, you can edit the pool configuration file:

```bash
# For Docker installation
nano config/pools.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/pools.yaml
```

Example configuration:

```yaml
pools:
  - name: "Prohashing"
    type: "prohashing"
    api_key: "${PROHASHING_API_KEY}"
    workers:
      - id: "worker1"
        name: "Rack 1 Workers"
        algorithms: ["Scrypt", "SHA-256"]
      - id: "worker2"
        name: "Rack 2 Workers"
        algorithms: ["Scrypt"]
    wamp:
      enabled: true
      url: "wss://prohashing.com:3333/ws"
      realm: "realm1"
      subscriptions:
        - "com.prohashing.profitability"
        - "com.prohashing.worker"
    http:
      enabled: true
      base_url: "https://prohashing.com/api/v1"
      polling_intervals:
        status_seconds: 300
        profitability_seconds: 900
        historical_seconds: 3600
```

## Market Data Configuration

Market data configuration controls how the system collects cryptocurrency market information.

### Market Data Sources

Configure market data sources through the web interface:

1. Navigate to Settings > Market Data
2. For each source (CoinGecko, CoinMarketCap), configure:
   - **API Key**: Your API key for the service
   - **Enable/Disable**: Toggle the data source
   - **Polling Interval**: How often to collect data
   - **Coins to Track**: Select cryptocurrencies to monitor

### Data Collection Settings

Fine-tune market data collection:

1. Navigate to Settings > Data Collection
2. Under "Market Data Collection", set the following:
   - **Price data interval**: How often to collect price data (5-15 minutes recommended)
   - **Technical data interval**: How often to collect technical indicators (1-6 hours recommended)
   - **Global metrics interval**: How often to collect market-wide metrics (1 hour recommended)
   - **Enable caching**: Cache responses to reduce API usage
   - **Cache expiry**: How long to keep cached data

### Configuration File

For advanced configuration, you can edit the market data configuration file:

```bash
# For Docker installation
nano config/market_data.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/market_data.yaml
```

Example configuration:

```yaml
market_data:
  coingecko:
    enabled: true
    api_key: "${COINGECKO_API_KEY}"
    coins:
      - "bitcoin"
      - "ethereum"
      - "litecoin"
      - "dogecoin"
    vs_currencies:
      - "usd"
      - "btc"
    polling_intervals:
      simple_price_seconds: 300
      market_data_seconds: 900
      historical_seconds: 3600
    caching:
      enabled: true
      expiry_seconds: 60
  
  coinmarketcap:
    enabled: true
    api_key: "${COINMARKETCAP_API_KEY}"
    tier: "basic"
    polling_intervals:
      listings_seconds: 900
      global_metrics_seconds: 3600
    caching:
      enabled: true
      expiry_seconds: 60
```

## Data Pipeline Configuration

The data pipeline handles the collection, transformation, and storage of data from various sources.

### Data Collection Schedule

Configure the data collection schedule:

1. Navigate to Settings > Data Pipeline
2. Under "Collection Schedule", set the following:
   - **Enable scheduled collection**: Toggle scheduled data collection
   - **Collection frequency**: How often to run the collection pipeline
   - **Stagger collection**: Distribute collection tasks to avoid API rate limits
   - **Retry failed collections**: Automatically retry failed collection tasks
   - **Maximum retries**: Maximum number of retry attempts

### Data Transformation

Configure data transformation settings:

1. Navigate to Settings > Data Pipeline
2. Under "Transformation Settings", configure:
   - **Enable data validation**: Validate data against schemas
   - **Handle missing values**: How to handle missing data (ignore, fill, or error)
   - **Calculate derived metrics**: Generate additional metrics from raw data
   - **Normalization**: Standardize units and formats

### Data Storage

Configure data storage settings:

1. Navigate to Settings > Data Pipeline
2. Under "Storage Settings", configure:
   - **Storage format**: Format for storing data (JSON, Parquet, etc.)
   - **Compression**: Enable/disable data compression
   - **Partitioning**: How to partition data (by date, miner, etc.)
   - **Retention period**: How long to keep historical data

### Configuration File

For advanced configuration, you can edit the data pipeline configuration file:

```bash
# For Docker installation
nano config/data_pipeline.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/data_pipeline.yaml
```

Example configuration:

```yaml
data_pipeline:
  general:
    timezone: "UTC"
    log_level: "INFO"
    storage_base_path: "/data/crypto_mining_monitor"
  
  collection:
    schedule: "*/5 * * * *"  # Every 5 minutes
    stagger_seconds: 30
    retry:
      enabled: true
      max_attempts: 3
      backoff_factor: 2
  
  transformation:
    validation:
      enabled: true
      strict_mode: false
    missing_values:
      strategy: "fill"
      fill_method: "interpolate"
    derived_metrics:
      enabled: true
      calculation_frequency: "hourly"
  
  storage:
    format: "parquet"
    compression: "snappy"
    partitioning:
      enabled: true
      scheme: ["year", "month", "day"]
    retention:
      high_resolution_days: 30
      medium_resolution_days: 180
      low_resolution_days: 1095  # 3 years
```

## ML Engine Configuration

The ML engine configuration controls how the system analyzes data and generates recommendations.

### Feature Store

Configure the feature store:

1. Navigate to Settings > ML Engine
2. Under "Feature Store", configure:
   - **Feature update frequency**: How often to update features
   - **Feature groups**: Enable/disable specific feature groups
   - **Feature freshness threshold**: Maximum age of features for real-time inference
   - **Enable feature monitoring**: Monitor feature drift and quality

### Model Training

Configure model training settings:

1. Navigate to Settings > ML Engine
2. Under "Model Training", configure:
   - **Training schedule**: How often to retrain models
   - **Evaluation metrics**: Metrics to use for model evaluation
   - **Hyperparameter tuning**: Enable/disable automatic hyperparameter optimization
   - **Model registry**: Settings for model versioning and storage

### Recommendation Engine

Configure the recommendation engine:

1. Navigate to Settings > ML Engine
2. Under "Recommendation Engine", configure:
   - **Recommendation types**: Enable/disable specific recommendation types
   - **Confidence threshold**: Minimum confidence level for recommendations
   - **User preference learning**: How to incorporate user feedback
   - **Recommendation frequency**: How often to generate new recommendations

### Configuration File

For advanced configuration, you can edit the ML engine configuration file:

```bash
# For Docker installation
nano config/ml_engine.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/ml_engine.yaml
```

Example configuration:

```yaml
ml_engine:
  general:
    project_id: "${ABACUS_PROJECT_ID}"
    api_key: "${ABACUS_API_KEY}"
    environment: "production"
  
  feature_store:
    update_frequency: "hourly"
    feature_groups:
      miner_telemetry:
        enabled: true
        update_interval_minutes: 15
      pool_performance:
        enabled: true
        update_interval_minutes: 30
      market_data:
        enabled: true
        update_interval_minutes: 15
      derived_metrics:
        enabled: true
        update_interval_minutes: 60
    monitoring:
      enabled: true
      drift_detection:
        enabled: true
        sensitivity: "medium"
  
  model_training:
    schedule:
      profitability_prediction: "0 0 * * *"  # Daily at midnight
      power_optimization: "0 0 * * 0"  # Weekly on Sunday
      anomaly_detection: "0 0 * * 0"  # Weekly on Sunday
      hardware_lifecycle: "0 0 1 * *"  # Monthly on the 1st
    evaluation:
      cross_validation_folds: 5
      metrics:
        regression: ["rmse", "mae", "r2"]
        classification: ["accuracy", "f1", "auc"]
    hyperparameter_tuning:
      enabled: true
      optimization_metric: "auto"
      max_trials: 20
  
  recommendation_engine:
    types:
      coin_switching:
        enabled: true
        confidence_threshold: 0.7
        max_daily_recommendations: 3
      power_optimization:
        enabled: true
        confidence_threshold: 0.8
        max_daily_recommendations: 2
      hardware_configuration:
        enabled: true
        confidence_threshold: 0.8
        max_daily_recommendations: 2
      maintenance:
        enabled: true
        confidence_threshold: 0.6
        max_daily_recommendations: 5
      hardware_upgrade:
        enabled: true
        confidence_threshold: 0.9
        max_monthly_recommendations: 1
    user_preferences:
      learning_rate: 0.1
      feedback_weight_decay: 0.9
    scheduling:
      real_time_enabled: true
      batch_schedule: "0 */6 * * *"  # Every 6 hours
```

## Web Application Configuration

The web application configuration controls the user interface and application behavior.

### General Settings

Configure general application settings:

1. Navigate to Settings > Application
2. Under "General Settings", configure:
   - **Application name**: Customize the application name
   - **Theme**: Select light, dark, or system theme
   - **Language**: Set the default language
   - **Timezone**: Set the default timezone for displaying dates and times

### Dashboard Configuration

Configure dashboard settings:

1. Navigate to Settings > Dashboard
2. Configure the following:
   - **Default dashboard**: Set the default dashboard view
   - **Auto-refresh interval**: How often to refresh dashboard data
   - **Chart time range**: Default time range for charts
   - **Visible widgets**: Select which widgets to display
   - **Widget layout**: Arrange dashboard widgets

### Notification Settings

Configure notification settings:

1. Navigate to Settings > Notifications
2. Configure the following:
   - **Enable notifications**: Toggle all notifications
   - **Notification channels**: Enable email, browser, or mobile notifications
   - **Notification types**: Configure which events trigger notifications
   - **Notification frequency**: Control how often notifications are sent
   - **Quiet hours**: Set times when notifications are suppressed

### User Management

Configure user management settings:

1. Navigate to Settings > Users
2. As an administrator, you can:
   - **Add users**: Create new user accounts
   - **Edit users**: Modify existing user accounts
   - **Assign roles**: Set user permissions
   - **Deactivate users**: Temporarily disable accounts

### Configuration File

For advanced configuration, you can edit the web application configuration file:

```bash
# For Docker installation
nano config/webapp.yaml

# For manual installation
nano /path/to/crypto_mining_monitor/config/webapp.yaml
```

Example configuration:

```yaml
webapp:
  general:
    name: "Crypto Mining Monitor"
    default_theme: "system"
    default_language: "en"
    default_timezone: "UTC"
  
  server:
    port: 3000
    host: "0.0.0.0"
    api_base_path: "/api"
    session:
      secret: "${COOKIE_SECRET}"
      max_age: 86400000  # 24 hours
    rate_limiting:
      enabled: true
      window_ms: 60000  # 1 minute
      max_requests: 100
  
  dashboard:
    default_view: "overview"
    auto_refresh_seconds: 300
    default_time_range: "24h"
    widgets:
      miner_status:
        enabled: true
        position: 1
      pool_performance:
        enabled: true
        position: 2
      recommendations:
        enabled: true
        position: 3
      historical_analysis:
        enabled: true
        position: 4
  
  notifications:
    enabled: true
    channels:
      email:
        enabled: true
        daily_digest: true
        digest_time: "08:00"
      browser:
        enabled: true
        max_displayed: 5
    types:
      critical_alerts:
        enabled: true
        channels: ["email", "browser"]
      recommendations:
        enabled: true
        channels: ["browser"]
        min_confidence: 0.8
      performance_updates:
        enabled: true
        channels: ["browser"]
        frequency: "daily"
    quiet_hours:
      enabled: true
      start: "22:00"
      end: "08:00"
      timezone: "user"
```

## Advanced Configuration

### Custom Scripts

You can create custom scripts for specialized functionality:

1. Navigate to Settings > Advanced
2. Under "Custom Scripts", you can:
   - **Create scripts**: Write custom scripts for data processing or automation
   - **Schedule scripts**: Set when scripts should run
   - **View logs**: Monitor script execution and output

### API Configuration

Configure the system's API for external integrations:

1. Navigate to Settings > API
2. Under "API Settings", you can:
   - **Generate API keys**: Create keys for external access
   - **Set permissions**: Control what each key can access
   - **View usage**: Monitor API usage and rate limits

### Backup and Restore

Configure backup settings:

1. Navigate to Settings > Backup
2. Under "Backup Settings", configure:
   - **Automatic backups**: Schedule regular backups
   - **Backup location**: Where to store backups
   - **Retention policy**: How long to keep backups
   - **Backup contents**: What to include in backups

### System Monitoring

Configure system monitoring:

1. Navigate to Settings > Monitoring
2. Under "System Monitoring", configure:
   - **Resource monitoring**: Track CPU, memory, and disk usage
   - **Service monitoring**: Monitor service health
   - **Alert thresholds**: Set when to trigger alerts
   - **Alert recipients**: Who should receive system alerts

