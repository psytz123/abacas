
# Troubleshooting

This guide provides solutions for common issues you might encounter when using the Cryptocurrency Mining Monitoring System.

## Table of Contents

- [General Troubleshooting Process](#general-troubleshooting-process)
- [Connection Issues](#connection-issues)
- [Data Collection Problems](#data-collection-problems)
- [Web Application Issues](#web-application-issues)
- [API Issues](#api-issues)
- [ML Engine Problems](#ml-engine-problems)
- [Performance Issues](#performance-issues)
- [Common Error Messages](#common-error-messages)
- [Getting Support](#getting-support)

## General Troubleshooting Process

When encountering issues with the system, follow this general troubleshooting process:

1. **Check System Status**:
   - Navigate to Settings > System Status to check the health of all components
   - Review system logs for error messages
   - Verify that all services are running

2. **Check Connectivity**:
   - Ensure network connectivity to miners, pools, and external APIs
   - Verify firewall settings allow necessary connections
   - Test basic connectivity using ping or telnet

3. **Review Logs**:
   - Check application logs for error messages
   - Review system logs for hardware or resource issues
   - Look for patterns or recurring errors

4. **Restart Services**:
   - Restart specific services that are experiencing issues
   - In some cases, a full system restart may be necessary

5. **Update Software**:
   - Ensure you're running the latest version of the software
   - Apply any available patches or updates

## Connection Issues

### Miner Connection Problems

**Symptoms**:
- Miners show as "Offline" or "Unreachable"
- Error messages about connection timeouts
- Missing or outdated miner data

**Solutions**:

1. **Verify Network Connectivity**:
   ```bash
   # Check if the miner is reachable
   ping <miner_ip_address>
   
   # Test connection to the Vnish API port (usually 80)
   telnet <miner_ip_address> 80
   ```

2. **Check Miner Status**:
   - Physically verify the miner is powered on and running
   - Check network cables and connections
   - Restart the miner if necessary

3. **Verify Credentials**:
   - Ensure the username and password for the Vnish firmware are correct
   - Try accessing the miner's web interface directly using the same credentials

4. **Check Firewall Settings**:
   - Ensure your firewall allows connections to the miners
   - Verify network routing between the server and miners

5. **Update Miner Configuration**:
   - Navigate to Settings > Miners
   - Edit the problematic miner
   - Update the IP address, port, and credentials
   - Save changes and test the connection

### Pool Connection Problems

**Symptoms**:
- Pool data is missing or outdated
- Error messages about API key or authentication
- "Pool connection failed" alerts

**Solutions**:

1. **Verify API Key**:
   - Check that your Prohashing API key is valid and active
   - Regenerate the API key if necessary
   - Update the API key in Settings > Pools

2. **Test API Connection**:
   ```bash
   # Test connection to Prohashing API
   curl -v https://prohashing.com/api/v1/status
   ```

3. **Check Network Connectivity**:
   - Ensure your server can reach the Prohashing API
   - Verify that outbound connections are allowed by your firewall

4. **Verify WAMP Connection**:
   - If using WAMP for real-time updates, check WebSocket connectivity
   - Try disabling WAMP temporarily and using HTTP fallback

5. **Review Rate Limits**:
   - Check if you've exceeded API rate limits
   - Adjust polling intervals in Settings > Data Collection

### Market Data API Connection Problems

**Symptoms**:
- Missing or outdated market data
- Error messages about API limits or authentication
- Empty market data charts

**Solutions**:

1. **Verify API Keys**:
   - Check that your CoinGecko and/or CoinMarketCap API keys are valid
   - Update API keys in Settings > Market Data

2. **Check Rate Limits**:
   - Verify you haven't exceeded API rate limits
   - Adjust polling intervals in Settings > Data Collection
   - Consider upgrading to a higher API tier if consistently hitting limits

3. **Test API Connection**:
   ```bash
   # Test connection to CoinGecko API
   curl -v https://api.coingecko.com/api/v3/ping
   
   # Test connection to CoinMarketCap API
   curl -v -H "X-CMC_PRO_API_KEY: your_api_key" https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?limit=1
   ```

4. **Enable Caching**:
   - Turn on API response caching in Settings > Market Data
   - Increase cache duration to reduce API calls

5. **Try Alternative API**:
   - If one API is unavailable, enable an alternative
   - Configure fallback options in Settings > Market Data

## Data Collection Problems

### Missing or Incomplete Data

**Symptoms**:
- Gaps in historical data
- Some metrics missing while others are present
- Charts showing incomplete data

**Solutions**:

1. **Check Collection Schedule**:
   - Verify that data collection is scheduled and running
   - Navigate to Settings > Data Pipeline > Collection Schedule
   - Ensure scheduled collection is enabled

2. **Review Collection Logs**:
   - Check data collection logs for errors
   - Navigate to Logs > Data Pipeline
   - Look for specific error messages related to data collection

3. **Verify Source Availability**:
   - Ensure data sources (miners, pools, APIs) were available during collection
   - Check for temporary outages or maintenance periods

4. **Adjust Collection Settings**:
   - Increase collection frequency for critical metrics
   - Enable retry for failed collections
   - Configure staggered collection to avoid rate limits

5. **Manually Trigger Collection**:
   - Navigate to Settings > Data Pipeline
   - Click "Run Collection Now" to manually trigger data collection
   - Check results and logs for any issues

### Data Validation Errors

**Symptoms**:
- Error messages about invalid or malformed data
- Warnings about schema validation failures
- Missing derived metrics

**Solutions**:

1. **Check Raw Data**:
   - Examine the raw data from sources
   - Look for unexpected formats or values
   - Verify that API responses match expected schemas

2. **Adjust Validation Settings**:
   - Navigate to Settings > Data Pipeline > Transformation Settings
   - Consider relaxing validation rules temporarily
   - Set "strict_mode" to false if needed

3. **Update Data Schemas**:
   - If APIs have changed their response format, update schemas
   - Check for version changes in external APIs

4. **Handle Missing Values**:
   - Configure how missing values are handled
   - Options include ignoring, filling with defaults, or interpolating

5. **Restart Transformation Pipeline**:
   - Restart the data transformation service
   - For Docker: `docker-compose restart data-pipeline`
   - For manual installation: `sudo systemctl restart crypto-data-pipeline.service`

### Historical Data Import Issues

**Symptoms**:
- Error messages during historical data import
- Incomplete historical data
- Performance issues during import

**Solutions**:

1. **Check File Format**:
   - Ensure import files are in the correct format (CSV, JSON, etc.)
   - Verify column names and data types match expected schema

2. **Adjust Batch Size**:
   - Reduce batch size for large imports
   - Navigate to Settings > Data Pipeline > Import Settings
   - Set smaller batch size to avoid memory issues

3. **Check Storage Space**:
   - Verify sufficient disk space for imported data
   - Clean up temporary import files if needed

4. **Validate Date Formats**:
   - Ensure dates in import files use consistent format
   - Configure date parsing settings if needed

5. **Run Import in Segments**:
   - Split large imports into smaller time periods
   - Import one segment at a time to avoid timeouts

## Web Application Issues

### Login Problems

**Symptoms**:
- Unable to log in to the web interface
- "Invalid credentials" error messages
- Session expires immediately after login

**Solutions**:

1. **Verify Credentials**:
   - Ensure username and password are correct
   - Check for caps lock or keyboard layout issues
   - Try resetting your password

2. **Check Browser Settings**:
   - Ensure cookies are enabled
   - Clear browser cache and cookies
   - Try a different browser

3. **Verify JWT Settings**:
   - Check JWT token expiration settings
   - Navigate to Settings > Security (admin only)
   - Adjust token lifetime if needed

4. **Check Server Time**:
   - Ensure server time is correct
   - Synchronize with NTP if needed
   ```bash
   # Check server time
   date
   
   # Synchronize time
   sudo timedatectl set-ntp true
   ```

5. **Reset Admin Password** (if locked out):
   ```bash
   # For Docker installation
   docker-compose exec webapp npm run reset-admin-password
   
   # For manual installation
   cd /path/to/crypto_mining_monitor/webapp
   npm run reset-admin-password
   ```

### Dashboard Display Issues

**Symptoms**:
- Charts not loading or displaying incorrectly
- Missing widgets or components
- Layout problems or visual glitches

**Solutions**:

1. **Refresh the Browser**:
   - Try a hard refresh (Ctrl+F5 or Cmd+Shift+R)
   - Clear browser cache and reload

2. **Check Browser Console**:
   - Open browser developer tools (F12 or Ctrl+Shift+I)
   - Check console for JavaScript errors
   - Look for network request failures

3. **Verify Data Availability**:
   - Ensure data is available for the selected time period
   - Check API responses in the Network tab of developer tools

4. **Reset Dashboard Layout**:
   - Navigate to Settings > Dashboard
   - Click "Reset to Default Layout"
   - Save changes and refresh

5. **Try Different Browser**:
   - Test in another browser to rule out browser-specific issues
   - Ensure you're using a supported browser (Chrome, Firefox, Edge, Safari)

### Slow Web Interface

**Symptoms**:
- Dashboard takes a long time to load
- Charts render slowly
- Actions (clicks, navigation) have delayed response

**Solutions**:

1. **Check Network Performance**:
   - Test your network connection speed
   - Verify latency between your browser and the server

2. **Optimize Data Requests**:
   - Reduce the time range for displayed data
   - Decrease auto-refresh frequency
   - Limit the number of visible widgets

3. **Check Server Resources**:
   - Monitor CPU, memory, and disk usage
   - Navigate to Settings > System > Resources
   - Upgrade resources if consistently high

4. **Enable Caching**:
   - Configure browser caching for static assets
   - Enable API response caching
   - Implement Redis caching if not already used

5. **Optimize Database Queries**:
   - Check database performance
   - Add indexes for frequently queried fields
   - Optimize complex queries

## API Issues

### Authentication Failures

**Symptoms**:
- 401 Unauthorized responses from API
- "Invalid token" error messages
- Unable to authenticate with API

**Solutions**:

1. **Verify API Key**:
   - Ensure you're using a valid API key
   - Check that the key hasn't expired
   - Regenerate the key if necessary

2. **Check Token Format**:
   - Verify the Authorization header format
   - Should be `Authorization: Bearer <token>`
   - Ensure no extra spaces or characters

3. **Verify Token Expiration**:
   - Check if the token has expired
   - Tokens typically expire after 24 hours
   - Use the refresh token endpoint to get a new token

4. **Check User Permissions**:
   - Ensure the user has appropriate permissions
   - Admin users have access to all endpoints
   - Other roles may have limited access

5. **Review API Logs**:
   - Check server logs for authentication issues
   - Look for specific error messages
   - Verify IP address restrictions if configured

### Rate Limiting Issues

**Symptoms**:
- 429 Too Many Requests responses
- "Rate limit exceeded" error messages
- Intermittent API failures

**Solutions**:

1. **Check Rate Limits**:
   - Review your current rate limits
   - Navigate to Settings > API > Rate Limits
   - Note the limits in the `X-RateLimit-*` response headers

2. **Implement Request Throttling**:
   - Add delays between requests
   - Batch requests when possible
   - Implement exponential backoff for retries

3. **Optimize API Usage**:
   - Reduce unnecessary API calls
   - Cache responses when appropriate
   - Request only needed fields

4. **Increase Rate Limits**:
   - If you're an administrator, increase rate limits
   - Navigate to Settings > API > Rate Limits
   - Adjust limits based on usage patterns

5. **Distribute Requests**:
   - Spread requests over time
   - Avoid bursts of simultaneous requests
   - Implement request queuing if needed

### Incorrect or Missing Data in API Responses

**Symptoms**:
- API returns unexpected data
- Some fields are missing from responses
- Data format differs from documentation

**Solutions**:

1. **Check API Version**:
   - Verify you're using the correct API version
   - Include appropriate version headers if required
   - Check for recent API changes

2. **Review Request Parameters**:
   - Ensure all required parameters are included
   - Check parameter formats and values
   - Verify query string encoding

3. **Examine Raw Responses**:
   - Use tools like curl or Postman to examine raw responses
   - Compare with expected format from documentation
   ```bash
   curl -v -H "Authorization: Bearer your_token" https://your-server.com/api/v1/miners
   ```

4. **Check Data Sources**:
   - Verify that underlying data sources are available
   - Ensure data collection is working properly
   - Check for data transformation issues

5. **Clear API Cache**:
   - If responses are cached, try clearing the cache
   - Navigate to Settings > API > Cache
   - Click "Clear Cache" or restart the API service

## ML Engine Problems

### Missing Recommendations

**Symptoms**:
- No recommendations are being generated
- Recommendations dashboard is empty
- "No recommendations available" message

**Solutions**:

1. **Check ML Engine Status**:
   - Verify the ML engine is running
   - Navigate to Settings > System Status
   - Check the ML engine component status

2. **Review Model Training Status**:
   - Ensure models have been trained
   - Navigate to Settings > ML Engine > Models
   - Check for successful training completion

3. **Verify Data Availability**:
   - Ensure sufficient data is available for generating recommendations
   - Models typically need several days of data
   - Check feature store status and data freshness

4. **Adjust Confidence Threshold**:
   - Lower the confidence threshold for recommendations
   - Navigate to Settings > ML Engine > Recommendation Engine
   - Reduce the minimum confidence level

5. **Manually Trigger Recommendation Generation**:
   - Navigate to Settings > ML Engine
   - Click "Generate Recommendations Now"
   - Check logs for any errors during generation

### Poor Recommendation Quality

**Symptoms**:
- Recommendations don't make sense
- Suggested changes have negative impacts
- Low confidence scores on recommendations

**Solutions**:

1. **Check Data Quality**:
   - Verify input data quality and completeness
   - Look for anomalies or incorrect values
   - Ensure all required features are available

2. **Review Model Performance**:
   - Check model evaluation metrics
   - Navigate to Settings > ML Engine > Model Performance
   - Look for degraded performance compared to baseline

3. **Retrain Models**:
   - Trigger model retraining with latest data
   - Navigate to Settings > ML Engine > Training
   - Click "Retrain Models" and select affected models

4. **Provide Feedback**:
   - Submit feedback on poor recommendations
   - This helps improve future recommendations
   - Include detailed information about why the recommendation was inappropriate

5. **Adjust Feature Engineering**:
   - Review feature importance and contribution
   - Modify feature engineering pipeline if needed
   - Add or remove features based on analysis

### Abacus.AI Integration Issues

**Symptoms**:
- Error messages about Abacus.AI connection
- Feature store synchronization failures
- Model training or inference errors

**Solutions**:

1. **Verify API Key**:
   - Check that your Abacus.AI API key is valid
   - Update the API key in Settings > ML Engine > Abacus.AI

2. **Test Abacus.AI Connection**:
   ```bash
   # Test Abacus.AI API connection
   curl -v -H "Authorization: Bearer your_abacus_api_key" https://api.abacus.ai/api/v0/user
   ```

3. **Check Project Configuration**:
   - Verify project ID and other settings
   - Navigate to Settings > ML Engine > Abacus.AI
   - Update configuration if needed

4. **Review Integration Logs**:
   - Check logs for Abacus.AI integration issues
   - Navigate to Logs > ML Engine
   - Look for specific error messages

5. **Reinstall Abacus.AI SDK**:
   ```bash
   # For Docker installation
   docker-compose exec ml-engine pip install --upgrade abacusai
   
   # For manual installation
   source /path/to/crypto_mining_monitor/venv/bin/activate
   pip install --upgrade abacusai
   ```

## Performance Issues

### High CPU Usage

**Symptoms**:
- System CPU usage consistently high
- Slow response times
- Thermal throttling or overheating

**Solutions**:

1. **Identify Resource-Intensive Processes**:
   ```bash
   # Check CPU usage by process
   top
   
   # Or for more detailed information
   htop
   ```

2. **Optimize Data Collection**:
   - Reduce polling frequency
   - Stagger collection tasks
   - Limit concurrent connections

3. **Adjust Database Settings**:
   - Optimize database configuration
   - Limit maximum connections
   - Configure appropriate cache size

4. **Scale Resources**:
   - Increase available CPU resources
   - For Docker, adjust CPU allocation
   - For VMs or physical servers, add CPU cores

5. **Enable Caching**:
   - Implement Redis caching
   - Cache frequent queries and API responses
   - Use in-memory caching for hot data

### Memory Leaks

**Symptoms**:
- Increasing memory usage over time
- System becomes slower after running for days
- Out of memory errors

**Solutions**:

1. **Monitor Memory Usage**:
   ```bash
   # Check memory usage
   free -h
   
   # Monitor memory usage over time
   watch -n 10 free -h
   
   # Check memory usage by process
   ps aux --sort=-%mem | head -n 10
   ```

2. **Restart Services Periodically**:
   - Set up automatic service restarts
   - Schedule restarts during low-usage periods
   - For Docker: `docker-compose restart service_name`
   - For manual installation: `sudo systemctl restart service_name`

3. **Check for Memory Leaks**:
   - Review application logs for memory warnings
   - Look for increasing memory patterns
   - Use tools like `memwatch` or `heapdump` for Node.js services

4. **Optimize Memory Settings**:
   - Adjust Node.js memory limits
   - Configure database memory allocation
   - Set appropriate JVM heap size for Java services

5. **Implement Memory Monitoring**:
   - Set up alerts for high memory usage
   - Monitor memory trends over time
   - Take action before memory is exhausted

### Disk Space Issues

**Symptoms**:
- "No space left on device" errors
- Slow disk operations
- Failed writes or database errors

**Solutions**:

1. **Check Disk Usage**:
   ```bash
   # Check disk space
   df -h
   
   # Find large files and directories
   du -h --max-depth=1 /path/to/check | sort -hr
   
   # Find files larger than 100MB
   find /path/to/check -type f -size +100M -exec ls -lh {} \;
   ```

2. **Clean Up Logs**:
   - Remove or compress old log files
   - Configure log rotation
   - Adjust log verbosity

3. **Manage Database Size**:
   - Implement data retention policies
   - Archive old data
   - Optimize database storage

4. **Clear Temporary Files**:
   - Remove temporary and cache files
   - Clean up Docker images and volumes if using Docker
   ```bash
   # Clean up Docker
   docker system prune -a
   ```

5. **Add Storage Capacity**:
   - Increase disk space
   - Add additional volumes
   - Configure storage expansion

## Common Error Messages

### "Failed to connect to miner: Connection timed out"

**Cause**: The system cannot establish a connection to the miner's API.

**Solutions**:
1. Verify the miner is powered on and connected to the network
2. Check network connectivity between the server and miner
3. Ensure the miner's IP address is correct in the configuration
4. Check firewall settings that might block the connection
5. Verify the Vnish firmware is running properly on the miner

### "API key invalid or expired"

**Cause**: The API key for an external service (Prohashing, CoinGecko, etc.) is invalid or has expired.

**Solutions**:
1. Verify the API key in Settings > API Credentials
2. Generate a new API key from the service provider
3. Update the API key in the system configuration
4. Check if the service requires periodic key renewal
5. Ensure you're using the correct API endpoint for the key

### "Database connection failed"

**Cause**: The system cannot connect to the database.

**Solutions**:
1. Check if the database service is running
   ```bash
   # For Docker
   docker-compose ps
   
   # For manual installation
   sudo systemctl status postgresql
   ```
2. Verify database credentials in the configuration
3. Check database logs for errors
   ```bash
   # PostgreSQL logs
   sudo tail -f /var/log/postgresql/postgresql-*.log
   ```
4. Ensure the database has sufficient connections available
5. Restart the database service if needed

### "Feature store synchronization failed"

**Cause**: The system cannot synchronize data with the Abacus.AI feature store.

**Solutions**:
1. Verify Abacus.AI API key and project ID
2. Check network connectivity to Abacus.AI services
3. Review feature definitions for errors
4. Check for data format or schema issues
5. Verify feature store configuration in Settings > ML Engine

### "Recommendation generation failed: Insufficient data"

**Cause**: The ML engine doesn't have enough data to generate reliable recommendations.

**Solutions**:
1. Ensure data collection is working properly
2. Wait for more data to be collected (typically 3-7 days needed)
3. Check for gaps in historical data
4. Verify feature computation is working correctly
5. Adjust the minimum data requirements in Settings > ML Engine

## Getting Support

If you've tried the troubleshooting steps and still have issues, you can get additional support:

### Community Support

1. **Community Forums**:
   - Visit our community forums at [forums.crypto-mining-monitor.com](https://forums.crypto-mining-monitor.com)
   - Search for similar issues before posting
   - Include detailed information about your problem

2. **GitHub Issues**:
   - Check existing issues on our GitHub repository
   - Open a new issue with detailed reproduction steps
   - Include logs and system information

### Professional Support

1. **Email Support**:
   - Contact our support team at support@crypto-mining-monitor.com
   - Include your system ID (found in Settings > System Information)
   - Attach relevant logs and screenshots

2. **Premium Support**:
   - For enterprise customers with premium support
   - Use your dedicated support channel
   - Reference your support contract ID

### Preparing Support Information

When seeking support, please provide the following information:

1. **System Information**:
   - Software version
   - Deployment method (Docker or manual)
   - Operating system and version
   - Hardware specifications

2. **Logs**:
   - Application logs
   - Error messages
   - System logs during the issue

3. **Problem Description**:
   - Detailed description of the issue
   - Steps to reproduce
   - When the problem started
   - Any recent changes to the system

4. **Screenshots**:
   - Screenshots of error messages
   - Dashboard or UI showing the issue
   - System status page

