# ML Engine to Vnish Firmware Integration

This document explains the implementation of the integration between the ML recommendation engine and Vnish firmware, which allows ML-generated recommendations to be applied directly to miners.

## Overview

The integration enables the ML engine to adjust miner settings through the Vnish firmware API, including:

1. **Hashrate tuning** - Adjusting the miner's hashrate as a percentage of maximum capacity
2. **Power optimization** - Setting power limits to optimize efficiency
3. **Overclocking** - Applying advanced overclocking settings including core clock, memory clock, and voltage adjustments

The implementation includes secure credential management, comprehensive validation for configuration changes, error handling, and logging throughout the system.

## Architecture

The integration consists of the following components:

1. **VnishFirmwareClient (Python)** - A client for the Vnish firmware API that handles communication with miners
2. **VnishCredentialManager** - Securely stores and retrieves credentials for Vnish firmware access
3. **Configuration Validation** - Ensures all settings are within safe and acceptable ranges
4. **VnishMLIntegration** - Connects the ML engine with the Vnish firmware client
5. **API Endpoints** - Exposes the integration functionality through REST API
6. **Web Application Integration** - Updates to the web application to use the new API endpoints

### Component Diagram

```
┌─────────────────┐      ┌───────────────────┐      ┌─────────────────┐
│                 │      │                   │      │                 │
│  Web Application│<─────│  ML Engine API    │<─────│ ML Recommendation│
│  (Next.js)      │      │  (FastAPI)        │      │ Engine          │
│                 │      │                   │      │                 │
└────────┬────────┘      └─────────┬─────────┘      └────────┬────────┘
         │                         │                          │
         │                         │                          │
         │                         ▼                          │
         │               ┌─────────────────────┐              │
         │               │                     │              │
         └──────────────>│  VnishMLIntegration │<─────────────┘
                         │                     │
                         └──────────┬──────────┘
                                    │
                                    │
                         ┌──────────▼──────────┐
                         │                     │
                         │  VnishFirmwareClient│
                         │                     │
                         └──────────┬──────────┘
                                    │
                                    │
                         ┌──────────▼──────────┐
                         │                     │
                         │  Vnish Firmware API │
                         │                     │
                         └──────────┬──────────┘
                                    │
                                    │
                         ┌──────────▼──────────┐
                         │                     │
                         │  ASIC Miners        │
                         │                     │
                         └─────────────────────┘
```

## Implementation Details

### 1. VnishFirmwareClient (Python)

The `VnishFirmwareClient` class provides methods for interacting with the Vnish firmware API, including:

- Getting miner status and telemetry data
- Setting frequency, voltage, and power limits
- Applying ML-recommended settings for hashrate tuning, power optimization, and overclocking

Key features:
- HTTP Basic Authentication for secure API access
- Retry mechanism for failed requests
- Comprehensive error handling
- Telemetry data transformation to match expected schemas

File: `/api_clients/vnish_firmware_client.py`

### 2. Credential Management

The `VnishCredentialManager` class provides secure storage and retrieval of Vnish firmware access credentials:

- Supports environment variables (`VNISH_HOST`, `VNISH_USERNAME`, `VNISH_PASSWORD`)
- Secure storage of credentials in encrypted files
- Per-miner credential management
- Default credentials for convenience

File: `/api_clients/credential_store.py`

### 3. Configuration Validation

The configuration validation module ensures that all settings are within safe and acceptable ranges before being applied to miners:

- Pydantic models for validation with field constraints
- Comprehensive validation for all configuration types
- Warning logs for potentially unsafe configurations
- Clear error messages for validation failures

File: `/api_clients/config_validation.py`

### 4. VnishMLIntegration

The `VnishMLIntegration` class connects the ML engine with the Vnish firmware client:

- Methods for applying different types of recommendations
- Support for dry-run mode to validate without applying changes
- Telemetry data collection for ML model input
- Batch processing of recommendations

File: `/ml_engine/vnish_integration.py`

### 5. API Endpoints

New API endpoints expose the integration functionality through REST API:

- Credential management endpoints
- Telemetry data endpoints
- Endpoints for applying specific optimization types
- Endpoints for applying ML recommendations
- Batch processing endpoints

Files:
- `/ml_engine/api_vnish_endpoints.py`
- `/ml_engine/api.py` (updated to include the new endpoints)

### 6. Web Application Integration

Updates to the web application to use the new API endpoints:

- Updated `VNishFirmwareClient` (TypeScript) to use the ML API
- New routes for applying recommendations
- New routes for optimization operations
- Telemetry data retrieval

Files:
- `/webapp/app/lib/vnish/firmware-client.ts`
- `/webapp/app/app/api/recommendations/apply/route.ts`
- `/webapp/app/app/api/miners/optimization/route.ts`
- `/webapp/app/app/api/miners/telemetry/route.ts`

## How It Works

### Applying ML Recommendations to Miners

1. The ML engine generates recommendations based on telemetry data, pool performance, and market conditions
2. The recommendations are stored and can be viewed in the web application
3. When a user decides to apply a recommendation, the web application calls the appropriate API endpoint
4. The API endpoint validates the recommendation and retrieves the necessary credentials
5. The VnishFirmwareClient applies the recommendation to the miner through the Vnish firmware API
6. The result is returned to the web application and displayed to the user

### Example: Applying a Hashrate Tuning Recommendation

1. ML engine generates a recommendation to reduce hashrate to 80% to optimize efficiency
2. User views the recommendation in the web application and clicks "Apply"
3. Web application calls `/api/recommendations/apply` with the recommendation ID
4. API endpoint retrieves the recommendation details and validates the configuration
5. VnishFirmwareClient calculates the target frequency based on the current frequency and hashrate percentage
6. VnishFirmwareClient sends a request to the Vnish firmware API to set the new frequency
7. Result is returned to the web application and displayed to the user

## Security Considerations

1. **Credential Management**
   - Credentials are stored securely using encryption
   - Environment variables can be used for sensitive information
   - Restrictive file permissions for credential files

2. **Input Validation**
   - All inputs are validated before being sent to the Vnish firmware API
   - Constraints on parameter ranges prevent unsafe settings

3. **Error Handling**
   - Comprehensive error handling prevents cascading failures
   - Detailed error messages help diagnose issues

4. **Logging**
   - Detailed logging throughout the system
   - Sensitive information is not logged

## Configuration

### Environment Variables

- `VNISH_HOST` - Default miner IP address
- `VNISH_USERNAME` - Default username for Vnish firmware access
- `VNISH_PASSWORD` - Default password for Vnish firmware access
- `CRYPTO_MINING_MONITOR_KEY` - Encryption key for credential storage
- `ML_API_ENDPOINT` - Endpoint for the ML API (for web application)

### Credential Storage

Credentials are stored in `~/.crypto_mining_monitor/credentials.json` by default, with an encryption key in `~/.crypto_mining_monitor/.encryption_key`.

## Usage Examples

### Python API

```python
from ml_engine.vnish_integration import VnishMLIntegration
from ml_engine.recommender import RecommendationEngine

# Initialize components
recommendation_engine = RecommendationEngine()
vnish_integration = VnishMLIntegration(recommendation_engine)

# Apply a hashrate tuning recommendation
recommendation = {
    "id": "rec-123",
    "type": "dynamic_hashrate_tuning",
    "miner_id": "miner_192.168.1.101",
    "recommended_hashrate_percent": 80.0
}
result = vnish_integration.apply_hashrate_tuning_recommendation(recommendation)
print(result)
```

### REST API

```bash
# Apply a hashrate tuning recommendation
curl -X POST http://localhost:8000/vnish/hashrate-tuning \
  -H "Content-Type: application/json" \
  -d '{
    "miner_id": "miner_001",
    "miner_ip": "192.168.1.101",
    "hashrate_percent": 80.0
  }'

# Apply a power optimization recommendation
curl -X POST http://localhost:8000/vnish/power-optimization \
  -H "Content-Type: application/json" \
  -d '{
    "miner_id": "miner_001",
    "miner_ip": "192.168.1.101",
    "power_limit_factor": 0.85
  }'

# Apply an overclocking recommendation
curl -X POST http://localhost:8000/vnish/overclocking \
  -H "Content-Type: application/json" \
  -d '{
    "miner_id": "miner_001",
    "miner_ip": "192.168.1.101",
    "core_clock_offset": 50,
    "memory_clock_offset": 200,
    "power_limit_percent": 85.0,
    "core_voltage_offset": 10
  }'
```

### Web Application

```typescript
import VNishFirmwareClient from '@/lib/vnish/firmware-client';

// Initialize the client
const vnishClient = new VNishFirmwareClient({
  apiEndpoint: 'http://localhost:8000',
  apiKey: '',
  timeout: 30000
});

// Apply a hashrate tuning recommendation
const result = await vnishClient.applyHashrateTuning({
  miner_id: 'miner_001',
  miner_ip: '192.168.1.101',
  hashrate_percent: 80.0
});
console.log(result);
```

## Troubleshooting

### Common Issues

1. **Authentication Failures**
   - Check that the correct credentials are being used
   - Verify that the miner IP address is correct
   - Ensure that the Vnish firmware is running and accessible

2. **Validation Errors**
   - Check that the parameters are within the acceptable ranges
   - Review the error message for specific validation failures

3. **Connection Issues**
   - Verify that the miner is on the network and accessible
   - Check firewall settings
   - Ensure that the Vnish firmware API is enabled

### Logs

Logs are available in the following locations:
- ML Engine: `/crypto_mining_monitor/ml_engine/logs/`
- Web Application: Browser console and server logs

## Future Improvements

1. **Enhanced Validation**
   - More sophisticated validation based on miner model and firmware version
   - Dynamic parameter ranges based on hardware capabilities

2. **Advanced Monitoring**
   - Real-time monitoring of miners after applying recommendations
   - Automatic rollback if performance degrades

3. **Batch Operations**
   - Improved support for applying recommendations to multiple miners
   - Scheduling of recommendation application

4. **User Interface Enhancements**
   - Visual feedback on recommendation application
   - Historical tracking of applied recommendations and their effects

## Conclusion

The integration between the ML recommendation engine and Vnish firmware enables automatic optimization of miner settings based on ML-generated recommendations. This improves mining efficiency, reduces energy consumption, and increases profitability while maintaining hardware safety through comprehensive validation and error handling.
