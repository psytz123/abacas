
# Installation and Setup

This guide provides step-by-step instructions for installing and setting up the Cryptocurrency Mining Monitoring System.

## Table of Contents

- [Prerequisites](#prerequisites)
- [System Requirements](#system-requirements)
- [Installation Options](#installation-options)
- [Docker Installation](#docker-installation)
- [Manual Installation](#manual-installation)
- [Initial Configuration](#initial-configuration)
- [Verifying Installation](#verifying-installation)
- [Next Steps](#next-steps)

## Prerequisites

Before installing the Cryptocurrency Mining Monitoring System, ensure you have the following:

1. **Mining Hardware**:
   - ASIC miners with Vnish firmware installed
   - Network connectivity to all miners

2. **Mining Pool Account**:
   - Prohashing.com account
   - API key with appropriate permissions

3. **Market Data API Access**:
   - CoinGecko API access (free tier is sufficient for basic usage)
   - CoinMarketCap API key (optional, for enhanced market data)

4. **Abacus.AI Account**:
   - Account with appropriate access level
   - API key for integration

## System Requirements

### Minimum Requirements

- **CPU**: 4 cores
- **RAM**: 8 GB
- **Storage**: 50 GB SSD
- **Network**: 10 Mbps stable internet connection
- **Operating System**: Ubuntu 20.04 LTS or later

### Recommended Requirements

- **CPU**: 8+ cores
- **RAM**: 16+ GB
- **Storage**: 100+ GB SSD
- **Network**: 100+ Mbps stable internet connection
- **Operating System**: Ubuntu 22.04 LTS

## Installation Options

The Cryptocurrency Mining Monitoring System can be installed using two methods:

1. **Docker Installation** (Recommended): Simplified deployment using Docker containers
2. **Manual Installation**: Step-by-step installation of all components

## Docker Installation

Docker installation is the recommended method for most users as it simplifies deployment and ensures consistent environments.

### 1. Install Docker and Docker Compose

```bash
# Update package index
sudo apt update

# Install prerequisites
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common

# Add Docker's official GPG key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

# Add Docker repository
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

# Install Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.18.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Add your user to the docker group
sudo usermod -aG docker $USER

# Apply changes (or log out and back in)
newgrp docker
```

### 2. Clone the Repository

```bash
# Clone the repository
git clone https://github.com/yourusername/crypto_mining_monitor.git
cd crypto_mining_monitor
```

### 3. Configure Environment Variables

```bash
# Copy the example environment file
cp .env.example .env

# Edit the environment file with your settings
nano .env
```

Update the following variables in the `.env` file:

```
# API Credentials
PROHASHING_API_KEY=your_prohashing_api_key
COINGECKO_API_KEY=your_coingecko_api_key
COINMARKETCAP_API_KEY=your_coinmarketcap_api_key

# Abacus.AI Integration
ABACUS_API_KEY=your_abacus_api_key
ABACUS_PROJECT_ID=your_abacus_project_id

# Database Configuration
DB_PASSWORD=secure_password_here

# Web Application
APP_SECRET=secure_random_string
```

### 4. Start the System

```bash
# Build and start the containers
docker-compose up -d

# Check the status
docker-compose ps
```

### 5. Access the Web Interface

Once the system is running, you can access the web interface at:

```
http://your_server_ip:3000
```

## Manual Installation

If you prefer to install the system manually, follow these steps:

### 1. Install System Dependencies

```bash
# Update package index
sudo apt update

# Install system dependencies
sudo apt install -y python3 python3-pip python3-venv nodejs npm postgresql postgresql-contrib redis-server nginx

# Install Node.js and npm
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installations
python3 --version
node --version
npm --version
```

### 2. Clone the Repository

```bash
# Clone the repository
git clone https://github.com/yourusername/crypto_mining_monitor.git
cd crypto_mining_monitor
```

### 3. Set Up Python Environment

```bash
# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
```

### 4. Set Up Database

```bash
# Create database and user
sudo -u postgres psql -c "CREATE DATABASE crypto_mining_monitor;"
sudo -u postgres psql -c "CREATE USER crypto_user WITH ENCRYPTED PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE crypto_mining_monitor TO crypto_user;"

# Run database migrations
python manage.py migrate
```

### 5. Set Up Web Application

```bash
# Navigate to webapp directory
cd webapp

# Install dependencies
npm install

# Build the application
npm run build
```

### 6. Configure Environment Variables

Create a `.env` file in the project root directory:

```bash
# Create environment file
nano .env
```

Add the following variables:

```
# API Credentials
PROHASHING_API_KEY=your_prohashing_api_key
COINGECKO_API_KEY=your_coingecko_api_key
COINMARKETCAP_API_KEY=your_coinmarketcap_api_key

# Abacus.AI Integration
ABACUS_API_KEY=your_abacus_api_key
ABACUS_PROJECT_ID=your_abacus_project_id

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=crypto_mining_monitor
DB_USER=crypto_user
DB_PASSWORD=your_secure_password

# Web Application
APP_SECRET=secure_random_string
```

### 7. Set Up Services

Create systemd service files for the different components:

```bash
# Create data pipeline service
sudo nano /etc/systemd/system/crypto-data-pipeline.service
```

Add the following content:

```
[Unit]
Description=Cryptocurrency Mining Monitor Data Pipeline
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/path/to/crypto_mining_monitor
ExecStart=/path/to/crypto_mining_monitor/venv/bin/python -m data_pipeline.main
Restart=always
Environment=PYTHONUNBUFFERED=1
EnvironmentFile=/path/to/crypto_mining_monitor/.env

[Install]
WantedBy=multi-user.target
```

Create a service for the web application:

```bash
# Create web application service
sudo nano /etc/systemd/system/crypto-webapp.service
```

Add the following content:

```
[Unit]
Description=Cryptocurrency Mining Monitor Web Application
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/path/to/crypto_mining_monitor/webapp
ExecStart=/usr/bin/npm start
Restart=always
Environment=NODE_ENV=production
EnvironmentFile=/path/to/crypto_mining_monitor/.env

[Install]
WantedBy=multi-user.target
```

Enable and start the services:

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable services
sudo systemctl enable crypto-data-pipeline.service
sudo systemctl enable crypto-webapp.service

# Start services
sudo systemctl start crypto-data-pipeline.service
sudo systemctl start crypto-webapp.service

# Check status
sudo systemctl status crypto-data-pipeline.service
sudo systemctl status crypto-webapp.service
```

### 8. Configure Nginx

```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/crypto-mining-monitor
```

Add the following content:

```
server {
    listen 80;
    server_name your_domain_or_ip;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site and restart Nginx:

```bash
# Create symbolic link
sudo ln -s /etc/nginx/sites-available/crypto-mining-monitor /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

## Initial Configuration

After installation, you need to perform initial configuration:

### 1. Create Admin User

```bash
# For Docker installation
docker-compose exec webapp npm run create-admin

# For manual installation
cd webapp
npm run create-admin
```

Follow the prompts to create an admin user.

### 2. Configure Miner Connections

1. Log in to the web interface using your admin credentials
2. Navigate to Settings > Miners
3. Click "Add Miner" and enter the following information:
   - Miner Name: A descriptive name
   - IP Address: The IP address of the miner
   - Username: The Vnish firmware username (usually "admin")
   - Password: The Vnish firmware password
4. Click "Save" to add the miner
5. Repeat for all miners you want to monitor

### 3. Configure Pool Connection

1. Navigate to Settings > Pools
2. Click "Add Pool" and enter the following information:
   - Pool Name: A descriptive name (e.g., "Prohashing")
   - API Key: Your Prohashing API key
   - Worker IDs: Comma-separated list of your worker IDs
3. Click "Save" to add the pool

## Verifying Installation

To verify that the installation was successful:

1. **Check Services**:
   ```bash
   # For Docker installation
   docker-compose ps
   
   # For manual installation
   sudo systemctl status crypto-data-pipeline.service
   sudo systemctl status crypto-webapp.service
   ```

2. **Check Logs**:
   ```bash
   # For Docker installation
   docker-compose logs -f
   
   # For manual installation
   sudo journalctl -u crypto-data-pipeline.service
   sudo journalctl -u crypto-webapp.service
   ```

3. **Access Web Interface**:
   Open a web browser and navigate to `http://your_server_ip` or `http://your_domain`

4. **Verify Data Collection**:
   - Log in to the web interface
   - Navigate to Dashboard
   - Verify that miner data is being displayed
   - Check that pool data is being updated

## Next Steps

After completing the installation and initial configuration:

1. Review the [Configuration](configuration.md) guide for advanced settings
2. Explore the [Usage Guide](usage.md) to learn how to use the system
3. Set up [Maintenance and Updates](maintenance.md) procedures

