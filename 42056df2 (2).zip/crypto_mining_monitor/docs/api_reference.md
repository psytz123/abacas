
# API Reference

This document provides comprehensive documentation for the Cryptocurrency Mining Monitoring System's API, enabling developers to integrate with and extend the system.

## Table of Contents

- [API Overview](#api-overview)
- [Authentication](#authentication)
- [Miner API](#miner-api)
- [Pool API](#pool-api)
- [Recommendation API](#recommendation-api)
- [Data API](#data-api)
- [User API](#user-api)
- [System API](#system-api)
- [Webhooks](#webhooks)
- [Error Handling](#error-handling)
- [Rate Limiting](#rate-limiting)
- [Examples](#examples)

## API Overview

The Cryptocurrency Mining Monitoring System provides a RESTful API that allows developers to:

- Retrieve miner telemetry and status
- Access pool performance data
- Get and provide feedback on recommendations
- Query historical data
- Manage users and settings
- Receive notifications via webhooks

### Base URL

All API endpoints are relative to the base URL:

```
https://your-server-domain/api/v1
```

### Response Format

All API responses are in JSON format with the following structure:

```json
{
  "success": true,
  "data": {
    // Response data here
  },
  "meta": {
    // Metadata about the response (pagination, etc.)
  }
}
```

For error responses:

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {
      // Additional error details (optional)
    }
  }
}
```

## Authentication

The API uses JSON Web Tokens (JWT) for authentication.

### Obtaining a Token

```
POST /auth/login
```

**Request Body:**

```json
{
  "username": "your_username",
  "password": "your_password"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_at": "2025-05-22T05:45:00.000Z",
    "user": {
      "id": "user_123",
      "username": "your_username",
      "role": "admin"
    }
  }
}
```

### Using the Token

Include the token in the `Authorization` header of all API requests:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Refreshing a Token

```
POST /auth/refresh
```

**Request Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_at": "2025-05-23T05:45:00.000Z"
  }
}
```

## Miner API

The Miner API provides access to miner data and operations.

### Get All Miners

```
GET /miners
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | Filter by status (mining, idle, error) |
| `model` | string | Filter by miner model |
| `location` | string | Filter by location |
| `tags` | string | Filter by tags (comma-separated) |
| `page` | integer | Page number for pagination |
| `limit` | integer | Number of results per page |

**Response:**

```json
{
  "success": true,
  "data": [
    {
      "id": "miner_001",
      "name": "Rack 1 - S19 Pro",
      "ip_address": "192.168.1.101",
      "model": "ANTMINER_S19_Pro",
      "status": "mining",
      "hashrate": 95.5,
      "hashrate_unit": "TH/s",
      "temperature": {
        "average": 66,
        "max": 72
      },
      "power": {
        "consumption": 3400,
        "efficiency": 35.6
      },
      "last_updated": "2025-05-21T05:30:00.000Z"
    },
    // Additional miners...
  ],
  "meta": {
    "total": 24,
    "page": 1,
    "limit": 10,
    "pages": 3
  }
}
```

### Get Miner Details

```
GET /miners/:id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "miner_001",
    "name": "Rack 1 - S19 Pro",
    "ip_address": "192.168.1.101",
    "model": "ANTMINER_S19_Pro",
    "firmware_version": "Vnish 1.0",
    "status": "mining",
    "hashrate": {
      "total": 95.5,
      "unit": "TH/s",
      "per_hashboard": [
        {
          "board_id": 1,
          "hashrate": 32.1,
          "status": "active"
        },
        {
          "board_id": 2,
          "hashrate": 31.8,
          "status": "active"
        },
        {
          "board_id": 3,
          "hashrate": 31.6,
          "status": "active"
        }
      ]
    },
    "temperature": {
      "ambient": 28,
      "avg_chip": 66,
      "max_chip": 72,
      "per_hashboard": [
        {
          "board_id": 1,
          "pcb_temp": 65,
          "chip_temp": 70
        },
        {
          "board_id": 2,
          "pcb_temp": 67,
          "chip_temp": 72
        },
        {
          "board_id": 3,
          "pcb_temp": 66,
          "chip_temp": 71
        }
      ]
    },
    "power": {
      "consumption": 3400,
      "unit": "W",
      "efficiency": 35.6,
      "efficiency_unit": "J/TH"
    },
    "fans": [
      {
        "fan_id": 1,
        "speed": 5400,
        "speed_percent": 80,
        "status": "normal"
      },
      {
        "fan_id": 2,
        "speed": 5500,
        "speed_percent": 82,
        "status": "normal"
      }
    ],
    "pool": {
      "url": "stratum+tcp://pool.example.com:3333",
      "user": "worker1",
      "status": "connected"
    },
    "shares": {
      "accepted": 12450,
      "rejected": 23,
      "stale": 5,
      "last_share_time": "2025-05-21T05:29:45.000Z"
    },
    "uptime": 259200,
    "uptime_formatted": "3 days",
    "config": {
      "frequency": 900,
      "overclock_profile": "efficiency",
      "power_limit": 3400
    },
    "location": "Data Center 1",
    "tags": ["rack1", "high_performance"],
    "last_updated": "2025-05-21T05:30:00.000Z"
  }
}
```

### Get Miner Telemetry History

```
GET /miners/:id/telemetry
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Aggregation interval (raw, 5m, 1h, 1d) |
| `metrics` | string | Specific metrics to include (comma-separated) |

**Response:**

```json
{
  "success": true,
  "data": {
    "timestamps": [
      "2025-05-20T05:00:00.000Z",
      "2025-05-20T06:00:00.000Z",
      "2025-05-20T07:00:00.000Z"
      // Additional timestamps...
    ],
    "metrics": {
      "hashrate": [94.2, 94.5, 95.1],
      "power_consumption": [3410, 3405, 3400],
      "temperature_avg": [65, 66, 66],
      "efficiency": [36.2, 36.0, 35.8]
      // Additional metrics...
    }
  },
  "meta": {
    "miner_id": "miner_001",
    "interval": "1h",
    "start_time": "2025-05-20T05:00:00.000Z",
    "end_time": "2025-05-21T05:00:00.000Z"
  }
}
```

### Restart Miner

```
POST /miners/:id/restart
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "miner_001",
    "status": "restarting",
    "message": "Restart command sent successfully",
    "estimated_completion_time": "2025-05-21T05:35:00.000Z"
  }
}
```

### Update Miner Configuration

```
PUT /miners/:id/config
```

**Request Body:**

```json
{
  "overclock_profile": "balanced",
  "power_limit": 3200,
  "fan_mode": "auto",
  "pool": {
    "url": "stratum+tcp://new-pool.example.com:3333",
    "user": "worker1",
    "pass": "x"
  }
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "miner_001",
    "message": "Configuration updated successfully",
    "applied_changes": {
      "overclock_profile": "balanced",
      "power_limit": 3200,
      "pool": {
        "url": "stratum+tcp://new-pool.example.com:3333"
      }
    }
  }
}
```

## Pool API

The Pool API provides access to mining pool data and operations.

### Get Pool Status

```
GET /pool/status
```

**Response:**

```json
{
  "success": true,
  "data": {
    "connected": true,
    "updating": true,
    "last_updates": {
      "profitability": "2025-05-21T05:15:00.000Z",
      "workers": "2025-05-21T05:20:00.000Z"
    },
    "workers": {
      "total": 5,
      "active": 5,
      "inactive": 0
    }
  }
}
```

### Get Profitability Data

```
GET /pool/profitability
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `algorithm` | string | Filter by algorithm (e.g., "Scrypt") |
| `convert` | string | Currency to convert values to (default: "USD") |

**Response:**

```json
{
  "success": true,
  "data": {
    "algorithms": [
      {
        "id": 1,
        "name": "Scrypt",
        "profitability": {
          "usd": 0.0025041009705167,
          "btc": 6.8628068694276e-7
        },
        "coins": [
          {
            "symbol": "LTC",
            "name": "Litecoin",
            "contribution": 0.85
          },
          {
            "symbol": "DOGE",
            "name": "Dogecoin",
            "contribution": 0.15
          }
        ],
        "timestamp": "2025-05-21T05:15:00.000Z"
      },
      // Additional algorithms...
    ]
  }
}
```

### Get Worker Performance

```
GET /pool/workers/:worker_id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "worker_id": "worker1",
    "algorithm": "Scrypt",
    "hashrate": {
      "reported": 95.5,
      "effective": 94.2,
      "unit": "TH/s"
    },
    "shares": {
      "accepted": 12450,
      "rejected": 23,
      "stale": 5,
      "invalid": 0
    },
    "earnings": {
      "amount": 0.0125,
      "currency": "BTC",
      "time_period": "24h",
      "usd_value": 45.75
    },
    "coins_mined": [
      {
        "coin_id": "litecoin",
        "symbol": "LTC",
        "amount": 0.15,
        "usd_value": 38.25,
        "mining_type": "primary"
      },
      {
        "coin_id": "dogecoin",
        "symbol": "DOGE",
        "amount": 25.5,
        "usd_value": 7.5,
        "mining_type": "merge-mined"
      }
    ],
    "status": "active",
    "last_updated": "2025-05-21T05:20:00.000Z"
  }
}
```

### Get Worker History

```
GET /pool/workers/:worker_id/history
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Aggregation interval (raw, 1h, 1d) |

**Response:**

```json
{
  "success": true,
  "data": {
    "timestamps": [
      "2025-05-20T05:00:00.000Z",
      "2025-05-20T06:00:00.000Z",
      "2025-05-20T07:00:00.000Z"
      // Additional timestamps...
    ],
    "metrics": {
      "hashrate": [94.2, 94.5, 95.1],
      "accepted_shares": [520, 518, 525],
      "rejected_shares": [2, 1, 1],
      "earnings_btc": [0.00052, 0.00053, 0.00054]
      // Additional metrics...
    }
  },
  "meta": {
    "worker_id": "worker1",
    "interval": "1h",
    "start_time": "2025-05-20T05:00:00.000Z",
    "end_time": "2025-05-21T05:00:00.000Z"
  }
}
```

## Recommendation API

The Recommendation API provides access to system recommendations and feedback.

### Get Recommendations

```
GET /recommendations
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `type` | string | Filter by recommendation type |
| `status` | string | Filter by status (pending, implemented, rejected) |
| `miner_id` | string | Filter by miner ID |
| `min_confidence` | number | Minimum confidence score (0-1) |
| `page` | integer | Page number for pagination |
| `limit` | integer | Number of results per page |

**Response:**

```json
{
  "success": true,
  "data": [
    {
      "id": "rec_001",
      "type": "coin_switching",
      "status": "pending",
      "miner_id": "miner_001",
      "description": "Switch from Bitcoin to Litecoin + Dogecoin (merge mining) for the next 48 hours",
      "expected_impact": {
        "profitability_increase": 12.3,
        "unit": "percent"
      },
      "confidence": 0.85,
      "reasoning": "Recent Dogecoin price surge combined with stable Litecoin difficulty",
      "created_at": "2025-05-21T04:30:00.000Z",
      "expires_at": "2025-05-23T04:30:00.000Z"
    },
    {
      "id": "rec_002",
      "type": "power_optimization",
      "status": "pending",
      "miner_id": "miner_003",
      "description": "Reduce power limit from 3400W to 3100W",
      "expected_impact": {
        "efficiency_improvement": 8.5,
        "hashrate_impact": -3.2,
        "net_profitability": 4.1,
        "unit": "percent"
      },
      "confidence": 0.75,
      "reasoning": "Current power efficiency curve indicates optimal point at lower power",
      "created_at": "2025-05-21T03:15:00.000Z",
      "expires_at": "2025-05-28T03:15:00.000Z"
    }
    // Additional recommendations...
  ],
  "meta": {
    "total": 8,
    "page": 1,
    "limit": 10,
    "pages": 1
  }
}
```

### Get Recommendation Details

```
GET /recommendations/:id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "rec_001",
    "type": "coin_switching",
    "status": "pending",
    "miner_id": "miner_001",
    "description": "Switch from Bitcoin to Litecoin + Dogecoin (merge mining) for the next 48 hours",
    "expected_impact": {
      "profitability_increase": 12.3,
      "unit": "percent"
    },
    "confidence": 0.85,
    "reasoning": "Recent Dogecoin price surge combined with stable Litecoin difficulty",
    "implementation_steps": [
      {
        "step": 1,
        "description": "Change pool URL to stratum+tcp://prohashing.com:3333",
        "automated": true
      },
      {
        "step": 2,
        "description": "Update worker name to include c=litecoin parameter",
        "automated": true
      },
      {
        "step": 3,
        "description": "Restart miner to apply changes",
        "automated": true
      }
    ],
    "created_at": "2025-05-21T04:30:00.000Z",
    "expires_at": "2025-05-23T04:30:00.000Z",
    "model_version": "profitability_prediction_v1.2",
    "features_used": [
      "litecoin_price_trend",
      "dogecoin_price_trend",
      "network_difficulty_ratio",
      "merge_mining_bonus"
    ]
  }
}
```

### Implement Recommendation

```
POST /recommendations/:id/implement
```

**Request Body:**

```json
{
  "auto_implement": true
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "rec_001",
    "status": "implementing",
    "implementation_id": "impl_001",
    "message": "Implementation in progress",
    "estimated_completion_time": "2025-05-21T05:40:00.000Z"
  }
}
```

### Get Implementation Status

```
GET /recommendations/:id/implementation/:implementation_id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "impl_001",
    "recommendation_id": "rec_001",
    "status": "completed",
    "steps": [
      {
        "step": 1,
        "description": "Change pool URL to stratum+tcp://prohashing.com:3333",
        "status": "completed",
        "completed_at": "2025-05-21T05:38:30.000Z"
      },
      {
        "step": 2,
        "description": "Update worker name to include c=litecoin parameter",
        "status": "completed",
        "completed_at": "2025-05-21T05:38:45.000Z"
      },
      {
        "step": 3,
        "description": "Restart miner to apply changes",
        "status": "completed",
        "completed_at": "2025-05-21T05:39:30.000Z"
      }
    ],
    "started_at": "2025-05-21T05:38:00.000Z",
    "completed_at": "2025-05-21T05:39:30.000Z",
    "result": {
      "success": true,
      "message": "Implementation completed successfully"
    }
  }
}
```

### Provide Recommendation Feedback

```
POST /recommendations/:id/feedback
```

**Request Body:**

```json
{
  "status": "implemented",
  "effectiveness": 4,
  "comments": "Worked well, saw immediate profitability increase",
  "actual_impact": {
    "profitability_increase": 10.5,
    "unit": "percent"
  }
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "rec_001",
    "status": "implemented",
    "feedback_id": "fb_001",
    "message": "Feedback recorded successfully"
  }
}
```

### Get Recommendation History

```
GET /recommendations/history
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `type` | string | Filter by recommendation type |
| `status` | string | Filter by status |
| `page` | integer | Page number for pagination |
| `limit` | integer | Number of results per page |

**Response:**

```json
{
  "success": true,
  "data": [
    {
      "id": "rec_001",
      "type": "coin_switching",
      "status": "implemented",
      "miner_id": "miner_001",
      "description": "Switch from Bitcoin to Litecoin + Dogecoin (merge mining) for the next 48 hours",
      "expected_impact": {
        "profitability_increase": 12.3,
        "unit": "percent"
      },
      "actual_impact": {
        "profitability_increase": 10.5,
        "unit": "percent"
      },
      "effectiveness": 4,
      "created_at": "2025-05-21T04:30:00.000Z",
      "implemented_at": "2025-05-21T05:39:30.000Z"
    },
    // Additional recommendations...
  ],
  "meta": {
    "total": 25,
    "page": 1,
    "limit": 10,
    "pages": 3
  }
}
```

## Data API

The Data API provides access to historical and aggregated data.

### Get Historical Data

```
GET /data/historical
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `type` | string | Data type (miner, pool, market) |
| `id` | string | Entity ID (miner_id, worker_id, coin_id) |
| `metrics` | string | Specific metrics to include (comma-separated) |
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Aggregation interval (raw, 5m, 1h, 1d) |

**Response:**

```json
{
  "success": true,
  "data": {
    "timestamps": [
      "2025-05-20T00:00:00.000Z",
      "2025-05-21T00:00:00.000Z"
      // Additional timestamps...
    ],
    "metrics": {
      "hashrate": [95.2, 95.5],
      "power_consumption": [3400, 3400],
      "temperature_avg": [65, 66],
      "efficiency": [35.7, 35.6]
      // Additional metrics...
    }
  },
  "meta": {
    "type": "miner",
    "id": "miner_001",
    "interval": "1d",
    "start_time": "2025-05-20T00:00:00.000Z",
    "end_time": "2025-05-22T00:00:00.000Z"
  }
}
```

### Get Aggregated Data

```
GET /data/aggregated
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `type` | string | Data type (miner, pool, market) |
| `group_by` | string | Grouping field (model, location, algorithm) |
| `metrics` | string | Specific metrics to include (comma-separated) |
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Aggregation interval (1h, 1d, 1w, 1m) |

**Response:**

```json
{
  "success": true,
  "data": {
    "groups": [
      {
        "name": "ANTMINER_S19_Pro",
        "count": 5,
        "metrics": {
          "hashrate_avg": 95.3,
          "power_consumption_avg": 3400,
          "temperature_avg": 66,
          "efficiency_avg": 35.7
        }
      },
      {
        "name": "ANTMINER_S19j",
        "count": 8,
        "metrics": {
          "hashrate_avg": 90.1,
          "power_consumption_avg": 3300,
          "temperature_avg": 64,
          "efficiency_avg": 36.6
        }
      }
      // Additional groups...
    ]
  },
  "meta": {
    "type": "miner",
    "group_by": "model",
    "interval": "1d",
    "start_time": "2025-05-20T00:00:00.000Z",
    "end_time": "2025-05-21T00:00:00.000Z"
  }
}
```

### Get Market Data

```
GET /data/market/:coin_id
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Data interval (1h, 1d, 1w) |

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "bitcoin",
    "symbol": "BTC",
    "name": "Bitcoin",
    "price_data": {
      "timestamps": [
        "2025-05-20T00:00:00.000Z",
        "2025-05-21T00:00:00.000Z"
      ],
      "prices": [106500, 106679],
      "market_caps": [2115000000000, 2119422882399],
      "volumes": [33500000000, 33801158041]
    },
    "current_data": {
      "price_usd": 106679,
      "market_cap_usd": 2119422882399,
      "volume_24h_usd": 33801158041,
      "price_change_24h_percent": 0.21394,
      "market_cap_change_24h_percent": 0.19457,
      "last_updated": "2025-05-21T05:45:00.000Z"
    },
    "mining_data": {
      "algorithm": "SHA-256",
      "network_hashrate": 550000000,
      "network_hashrate_unit": "TH/s",
      "difficulty": 78350000000000,
      "block_reward": 3.125,
      "block_time": 600
    }
  }
}
```

## User API

The User API provides user management functionality.

### Get Current User

```
GET /users/me
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "user_123",
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin",
    "preferences": {
      "theme": "dark",
      "language": "en",
      "timezone": "UTC",
      "dashboard_layout": "default"
    },
    "created_at": "2025-01-01T00:00:00.000Z",
    "last_login": "2025-05-21T05:00:00.000Z"
  }
}
```

### Update User Preferences

```
PUT /users/me/preferences
```

**Request Body:**

```json
{
  "theme": "light",
  "language": "en",
  "timezone": "America/New_York",
  "dashboard_layout": "compact"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "preferences": {
      "theme": "light",
      "language": "en",
      "timezone": "America/New_York",
      "dashboard_layout": "compact"
    },
    "message": "Preferences updated successfully"
  }
}
```

### Get All Users (Admin Only)

```
GET /users
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `role` | string | Filter by role |
| `page` | integer | Page number for pagination |
| `limit` | integer | Number of results per page |

**Response:**

```json
{
  "success": true,
  "data": [
    {
      "id": "user_123",
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin",
      "created_at": "2025-01-01T00:00:00.000Z",
      "last_login": "2025-05-21T05:00:00.000Z"
    },
    {
      "id": "user_124",
      "username": "operator",
      "email": "operator@example.com",
      "role": "operator",
      "created_at": "2025-01-15T00:00:00.000Z",
      "last_login": "2025-05-20T10:00:00.000Z"
    }
    // Additional users...
  ],
  "meta": {
    "total": 5,
    "page": 1,
    "limit": 10,
    "pages": 1
  }
}
```

### Create User (Admin Only)

```
POST /users
```

**Request Body:**

```json
{
  "username": "new_user",
  "email": "new_user@example.com",
  "password": "secure_password",
  "role": "viewer"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "user_125",
    "username": "new_user",
    "email": "new_user@example.com",
    "role": "viewer",
    "created_at": "2025-05-21T05:45:00.000Z",
    "message": "User created successfully"
  }
}
```

### Update User (Admin Only)

```
PUT /users/:id
```

**Request Body:**

```json
{
  "email": "updated_email@example.com",
  "role": "operator"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "user_125",
    "username": "new_user",
    "email": "updated_email@example.com",
    "role": "operator",
    "message": "User updated successfully"
  }
}
```

### Delete User (Admin Only)

```
DELETE /users/:id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "message": "User deleted successfully"
  }
}
```

## System API

The System API provides system-level information and operations.

### Get System Status

```
GET /system/status
```

**Response:**

```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "version": "1.2.0",
    "uptime": 259200,
    "uptime_formatted": "3 days",
    "components": {
      "data_pipeline": {
        "status": "healthy",
        "last_run": "2025-05-21T05:30:00.000Z"
      },
      "ml_engine": {
        "status": "healthy",
        "last_recommendation_generation": "2025-05-21T04:30:00.000Z"
      },
      "web_application": {
        "status": "healthy",
        "active_users": 3
      },
      "database": {
        "status": "healthy",
        "size": "1.2 GB"
      }
    },
    "resources": {
      "cpu_usage": 25,
      "memory_usage": 40,
      "disk_usage": 35
    }
  }
}
```

### Get System Logs

```
GET /system/logs
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `level` | string | Filter by log level (info, warn, error) |
| `component` | string | Filter by component |
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `limit` | integer | Number of log entries to return |

**Response:**

```json
{
  "success": true,
  "data": {
    "logs": [
      {
        "timestamp": "2025-05-21T05:30:00.000Z",
        "level": "info",
        "component": "data_pipeline",
        "message": "Data collection completed successfully",
        "details": {
          "miners_processed": 24,
          "duration_ms": 5200
        }
      },
      {
        "timestamp": "2025-05-21T05:15:00.000Z",
        "level": "warn",
        "component": "ml_engine",
        "message": "Feature drift detected in power_efficiency",
        "details": {
          "drift_score": 0.15,
          "threshold": 0.1
        }
      }
      // Additional logs...
    ]
  },
  "meta": {
    "total": 1250,
    "returned": 10,
    "level": "info",
    "start_time": "2025-05-21T00:00:00.000Z",
    "end_time": "2025-05-21T06:00:00.000Z"
  }
}
```

### Get System Metrics

```
GET /system/metrics
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `metrics` | string | Specific metrics to include (comma-separated) |
| `start_time` | string | Start time in ISO format |
| `end_time` | string | End time in ISO format |
| `interval` | string | Aggregation interval (1m, 5m, 1h) |

**Response:**

```json
{
  "success": true,
  "data": {
    "timestamps": [
      "2025-05-21T05:00:00.000Z",
      "2025-05-21T05:05:00.000Z",
      "2025-05-21T05:10:00.000Z"
      // Additional timestamps...
    ],
    "metrics": {
      "cpu_usage": [24, 26, 25],
      "memory_usage": [38, 39, 40],
      "disk_usage": [35, 35, 35],
      "api_requests": [120, 95, 110],
      "active_users": [3, 3, 2]
      // Additional metrics...
    }
  },
  "meta": {
    "interval": "5m",
    "start_time": "2025-05-21T05:00:00.000Z",
    "end_time": "2025-05-21T05:30:00.000Z"
  }
}
```

### Trigger System Backup (Admin Only)

```
POST /system/backup
```

**Request Body:**

```json
{
  "include_data": true,
  "include_configs": true,
  "include_logs": false
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "backup_id": "backup_20250521_054500",
    "status": "in_progress",
    "estimated_completion_time": "2025-05-21T05:50:00.000Z",
    "message": "Backup initiated successfully"
  }
}
```

### Get Backup Status (Admin Only)

```
GET /system/backup/:backup_id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "backup_id": "backup_20250521_054500",
    "status": "completed",
    "size": "250 MB",
    "location": "/backups/backup_20250521_054500.zip",
    "contents": {
      "data": true,
      "configs": true,
      "logs": false
    },
    "started_at": "2025-05-21T05:45:00.000Z",
    "completed_at": "2025-05-21T05:48:30.000Z"
  }
}
```

## Webhooks

The system can send webhook notifications for various events.

### Register Webhook

```
POST /webhooks
```

**Request Body:**

```json
{
  "url": "https://your-server.com/webhook-endpoint",
  "secret": "your_webhook_secret",
  "events": [
    "recommendation.created",
    "miner.status_changed",
    "alert.critical"
  ],
  "description": "Production monitoring webhook"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "webhook_001",
    "url": "https://your-server.com/webhook-endpoint",
    "events": [
      "recommendation.created",
      "miner.status_changed",
      "alert.critical"
    ],
    "description": "Production monitoring webhook",
    "created_at": "2025-05-21T05:45:00.000Z",
    "message": "Webhook registered successfully"
  }
}
```

### List Webhooks

```
GET /webhooks
```

**Response:**

```json
{
  "success": true,
  "data": [
    {
      "id": "webhook_001",
      "url": "https://your-server.com/webhook-endpoint",
      "events": [
        "recommendation.created",
        "miner.status_changed",
        "alert.critical"
      ],
      "description": "Production monitoring webhook",
      "created_at": "2025-05-21T05:45:00.000Z",
      "last_triggered": "2025-05-21T05:50:00.000Z",
      "status": "active"
    }
    // Additional webhooks...
  ]
}
```

### Update Webhook

```
PUT /webhooks/:id
```

**Request Body:**

```json
{
  "events": [
    "recommendation.created",
    "recommendation.implemented",
    "miner.status_changed",
    "alert.critical",
    "alert.warning"
  ],
  "description": "Updated production monitoring webhook"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": "webhook_001",
    "events": [
      "recommendation.created",
      "recommendation.implemented",
      "miner.status_changed",
      "alert.critical",
      "alert.warning"
    ],
    "description": "Updated production monitoring webhook",
    "message": "Webhook updated successfully"
  }
}
```

### Delete Webhook

```
DELETE /webhooks/:id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "message": "Webhook deleted successfully"
  }
}
```

### Webhook Payload Format

When an event occurs, the system sends a POST request to the registered webhook URL with the following payload:

```json
{
  "event": "recommendation.created",
  "timestamp": "2025-05-21T05:50:00.000Z",
  "data": {
    // Event-specific data
  },
  "signature": "sha256=..."
}
```

The `signature` is a HMAC SHA-256 hash of the payload using the webhook secret, allowing you to verify the authenticity of the webhook.

## Error Handling

The API uses standard HTTP status codes and provides detailed error information in the response body.

### Common Error Codes

| Status Code | Description |
|-------------|-------------|
| 400 | Bad Request - Invalid parameters or request body |
| 401 | Unauthorized - Missing or invalid authentication |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource already exists or state conflict |
| 422 | Unprocessable Entity - Validation error |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error - Server-side error |

### Error Response Format

```json
{
  "success": false,
  "error": {
    "code": "INVALID_PARAMETERS",
    "message": "Invalid parameters provided",
    "details": {
      "power_limit": "Must be between 1000 and 4000"
    }
  }
}
```

## Rate Limiting

The API implements rate limiting to prevent abuse and ensure fair usage.

### Rate Limit Headers

All API responses include the following headers:

| Header | Description |
|--------|-------------|
| `X-RateLimit-Limit` | Maximum number of requests allowed in the current window |
| `X-RateLimit-Remaining` | Number of requests remaining in the current window |
| `X-RateLimit-Reset` | Time when the current rate limit window resets (Unix timestamp) |

### Rate Limit Exceeded Response

When the rate limit is exceeded, the API returns a 429 Too Many Requests response:

```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded. Please try again later.",
    "details": {
      "limit": 100,
      "reset_at": 1716355500
    }
  }
}
```

## Examples

### Example: Retrieving Miner Status and Implementing a Recommendation

```javascript
// JavaScript example using fetch API

// Step 1: Authenticate
async function authenticate() {
  const response = await fetch('https://your-server.com/api/v1/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      username: 'admin',
      password: 'your_password'
    })
  });
  
  const data = await response.json();
  return data.data.token;
}

// Step 2: Get miner status
async function getMinerStatus(token, minerId) {
  const response = await fetch(`https://your-server.com/api/v1/miners/${minerId}`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  return await response.json();
}

// Step 3: Get recommendations for the miner
async function getMinerRecommendations(token, minerId) {
  const response = await fetch(`https://your-server.com/api/v1/recommendations?miner_id=${minerId}&status=pending`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  return await response.json();
}

// Step 4: Implement a recommendation
async function implementRecommendation(token, recommendationId) {
  const response = await fetch(`https://your-server.com/api/v1/recommendations/${recommendationId}/implement`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      auto_implement: true
    })
  });
  
  return await response.json();
}

// Step 5: Check implementation status
async function checkImplementationStatus(token, recommendationId, implementationId) {
  const response = await fetch(`https://your-server.com/api/v1/recommendations/${recommendationId}/implementation/${implementationId}`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  return await response.json();
}

// Main function
async function main() {
  try {
    // Authenticate
    const token = await authenticate();
    
    // Get miner status
    const minerId = 'miner_001';
    const minerStatus = await getMinerStatus(token, minerId);
    console.log('Miner Status:', minerStatus.data);
    
    // Get recommendations
    const recommendations = await getMinerRecommendations(token, minerId);
    
    if (recommendations.data.length > 0) {
      const recommendation = recommendations.data[0];
      console.log('Recommendation:', recommendation);
      
      // Implement the recommendation
      const implementation = await implementRecommendation(token, recommendation.id);
      console.log('Implementation Started:', implementation.data);
      
      // Wait for implementation to complete
      const implementationId = implementation.data.implementation_id;
      
      // Poll for implementation status
      let implementationStatus;
      do {
        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
        implementationStatus = await checkImplementationStatus(token, recommendation.id, implementationId);
        console.log('Implementation Status:', implementationStatus.data.status);
      } while (implementationStatus.data.status === 'in_progress');
      
      console.log('Final Implementation Status:', implementationStatus.data);
    } else {
      console.log('No pending recommendations for this miner');
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

main();
```

### Example: Monitoring Multiple Miners with Webhooks

```python
# Python example using requests library

import requests
import hmac
import hashlib
import time
from flask import Flask, request, jsonify

# API client
class CryptoMiningMonitorClient:
    def __init__(self, base_url, username, password):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.token = None
    
    def authenticate(self):
        response = requests.post(
            f"{self.base_url}/auth/login",
            json={
                "username": self.username,
                "password": self.password
            }
        )
        data = response.json()
        self.token = data["data"]["token"]
        return self.token
    
    def get_miners(self):
        response = requests.get(
            f"{self.base_url}/miners",
            headers={"Authorization": f"Bearer {self.token}"}
        )
        return response.json()
    
    def register_webhook(self, webhook_url, secret, events):
        response = requests.post(
            f"{self.base_url}/webhooks",
            headers={"Authorization": f"Bearer {self.token}"},
            json={
                "url": webhook_url,
                "secret": secret,
                "events": events,
                "description": "Miner monitoring webhook"
            }
        )
        return response.json()

# Webhook server
app = Flask(__name__)

# Webhook secret (should match what you register)
WEBHOOK_SECRET = "your_webhook_secret"

@app.route('/webhook', methods=['POST'])
def webhook():
    # Get the signature from the headers
    signature_header = request.headers.get('X-Signature')
    
    # Calculate the expected signature
    payload = request.data
    expected_signature = hmac.new(
        WEBHOOK_SECRET.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    expected_header = f"sha256={expected_signature}"
    
    # Verify the signature
    if not hmac.compare_digest(signature_header, expected_header):
        return jsonify({"success": False, "error": "Invalid signature"}), 401
    
    # Process the webhook
    data = request.json
    event = data["event"]
    timestamp = data["timestamp"]
    event_data = data["data"]
    
    print(f"Received event: {event} at {timestamp}")
    
    # Handle different event types
    if event == "miner.status_changed":
        miner_id = event_data["miner_id"]
        old_status = event_data["old_status"]
        new_status = event_data["new_status"]
        print(f"Miner {miner_id} status changed from {old_status} to {new_status}")
        
        # Take action based on status change
        if new_status == "error":
            # Send alert, trigger automation, etc.
            print(f"ALERT: Miner {miner_id} is in error state!")
    
    elif event == "recommendation.created":
        recommendation_id = event_data["id"]
        recommendation_type = event_data["type"]
        miner_id = event_data["miner_id"]
        description = event_data["description"]
        
        print(f"New recommendation {recommendation_id} for miner {miner_id}: {description}")
    
    return jsonify({"success": True})

# Main function
def main():
    # Initialize API client
    client = CryptoMiningMonitorClient(
        base_url="https://your-server.com/api/v1",
        username="admin",
        password="your_password"
    )
    
    # Authenticate
    client.authenticate()
    
    # Get all miners
    miners_response = client.get_miners()
    miners = miners_response["data"]
    
    print(f"Monitoring {len(miners)} miners:")
    for miner in miners:
        print(f"- {miner['name']} ({miner['id']}): {miner['status']}")
    
    # Register webhook for monitoring
    webhook_url = "https://your-webhook-server.com/webhook"
    events = [
        "miner.status_changed",
        "recommendation.created",
        "alert.critical"
    ]
    
    webhook_response = client.register_webhook(webhook_url, WEBHOOK_SECRET, events)
    print(f"Webhook registered: {webhook_response['data']['id']}")
    
    # Start webhook server
    app.run(host='0.0.0.0', port=5000)

if __name__ == "__main__":
    main()
```

