
# Abacus.AI Integration for Cryptocurrency Mining Monitoring System

This directory contains the integration code for connecting our cryptocurrency mining monitoring system with Abacus.AI's machine learning platform. The integration enables our ML recommendation engine to work with real mining data from Vnish firmware and Prohashing.com.

## Table of Contents

1. [Overview](#overview)
2. [Setup Instructions](#setup-instructions)
3. [Feature Stores](#feature-stores)
4. [Model Training](#model-training)
5. [Model Deployment](#model-deployment)
6. [API Integration](#api-integration)
7. [Monitoring and Maintenance](#monitoring-and-maintenance)

## Overview

Our ML recommendation architecture uses Abacus.AI to:

1. Store and manage mining telemetry and performance data in feature stores
2. Train and deploy models for different recommendation types:
   - Coin switching recommendations
   - Power optimization recommendations
   - Hardware configuration recommendations
   - Maintenance recommendations
   - Hardware upgrade recommendations
3. Serve real-time recommendations to our web application
4. Collect and incorporate user feedback for continuous improvement

## Setup Instructions

### Prerequisites

1. Abacus.AI account with API access
2. Python 3.8+ with pip
3. Access to Vnish firmware and Prohashing.com API credentials

### Installation

```bash
# Install the Abacus.AI Python SDK
pip install abacusai

# Set up environment variables for API access
export ABACUSAI_API_KEY="your_api_key_here"
```

### Configuration

1. Update the `config.py` file with your Abacus.AI API key and other settings
2. Run the setup script to create the initial feature stores and models:

```bash
python setup_abacus.py
```

## Feature Stores

We use the following feature stores in Abacus.AI:

1. **Miner Telemetry Features** - Stores data from Vnish firmware API
   - Entity ID: `miner_id`
   - Key features: hashrate, temperature, power consumption, efficiency metrics

2. **Pool Performance Features** - Stores data from Prohashing.com API
   - Entity ID: `worker_id`
   - Key features: earnings, shares, profitability metrics, coin-specific performance

3. **Market Data Features** - Stores cryptocurrency market data
   - Entity ID: `coin_id`
   - Key features: price, volume, market cap, technical indicators

4. **Derived Mining Metrics** - Stores calculated metrics across data sources
   - Entity ID: `miner_id`
   - Key features: cross-source metrics, optimization indicators, risk metrics

See `feature_store_setup.py` for implementation details.

## Model Training

We train the following models in Abacus.AI:

1. **Profitability Prediction Models** - Predict mining profitability for different coins
   - Algorithm: XGBoost/LightGBM for short-term, LSTM for medium-term
   - Training frequency: Daily

2. **Power Optimization Models** - Determine optimal power settings
   - Algorithm: Bayesian Optimization
   - Training frequency: Weekly

3. **Anomaly Detection Models** - Identify hardware issues
   - Algorithm: Isolation Forest
   - Training frequency: Weekly

4. **Hardware Lifecycle Models** - Predict maintenance needs and optimal replacement timing
   - Algorithm: Survival Analysis (Cox Proportional Hazards)
   - Training frequency: Monthly

See `training_pipeline.py` for implementation details.

## Model Deployment

Models are deployed as real-time endpoints in Abacus.AI, allowing our web application to request recommendations on demand. The deployment configuration includes:

- Scalable infrastructure for varying load
- Low-latency configuration for real-time responses
- Authentication and access control
- Monitoring and alerting

See `deployment_config.py` for implementation details.

## API Integration

Our web application integrates with the Abacus.AI endpoints through:

1. **Recommendation API** - Fetches recommendations for display in the UI
2. **Feedback API** - Sends user feedback to improve models
3. **Telemetry Ingestion API** - Streams mining data to feature stores

See `serving_client.py` for client implementation and `routes.md` for API route examples.

## Monitoring and Maintenance

We monitor the performance of our ML pipeline using:

1. **Model Performance Monitoring** - Tracks prediction accuracy and drift
2. **Feature Monitoring** - Ensures data quality and freshness
3. **Recommendation Quality Monitoring** - Tracks user acceptance and impact
4. **System Performance Monitoring** - Ensures reliable operation

See `monitoring_setup.py` for implementation details.
