
"""
Setup script for Abacus.AI integration.

This script sets up the complete Abacus.AI integration for the cryptocurrency
mining monitoring system, including feature stores, model training, deployment,
and monitoring.
"""

import logging
import time
import argparse
from typing import Dict, List, Optional, Any

from feature_store_setup import setup_feature_stores
from training_pipeline import setup_training_pipeline
from deployment_config import deploy_models
from monitoring_setup import setup_monitoring
from serving_client import create_recommendation_client

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def setup_abacus_integration(skip_training: bool = False):
    """
    Set up the complete Abacus.AI integration.
    
    Args:
        skip_training: Whether to skip model training (useful for testing)
    """
    logger.info("Starting Abacus.AI integration setup")
    
    # Step 1: Set up feature stores
    logger.info("Step 1: Setting up feature stores")
    feature_store_manager = setup_feature_stores()
    logger.info("Feature stores set up successfully")
    
    # Step 2: Set up model training pipeline (optional)
    if not skip_training:
        logger.info("Step 2: Setting up model training pipeline")
        training_manager = setup_training_pipeline()
        logger.info("Model training pipeline set up successfully")
    else:
        logger.info("Skipping model training")
    
    # Step 3: Deploy models
    logger.info("Step 3: Deploying models")
    deployment_manager = deploy_models()
    logger.info("Models deployed successfully")
    
    # Step 4: Set up monitoring
    logger.info("Step 4: Setting up monitoring")
    monitoring_manager = setup_monitoring()
    logger.info("Monitoring set up successfully")
    
    # Step 5: Create recommendation client
    logger.info("Step 5: Creating recommendation client")
    recommendation_client = create_recommendation_client()
    logger.info("Recommendation client created successfully")
    
    logger.info("Abacus.AI integration setup completed successfully")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Set up Abacus.AI integration')
    parser.add_argument('--skip-training', action='store_true', help='Skip model training')
    args = parser.parse_args()
    
    setup_abacus_integration(skip_training=args.skip_training)
