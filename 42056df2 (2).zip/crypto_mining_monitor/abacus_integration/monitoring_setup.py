
"""
Monitoring setup for Abacus.AI integration.

This module provides functions for setting up monitoring for the ML pipeline,
including model performance, feature drift, and recommendation quality.
"""

import logging
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import abacusai
from abacusai import ApiClient

from config import (
    ABACUSAI_API_KEY,
    MODELS,
    DEPLOYMENT_CONFIG
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MonitoringManager:
    """
    Manager for setting up monitoring for the ML pipeline.
    """
    
    def __init__(self, api_key: str = ABACUSAI_API_KEY):
        """
        Initialize the monitoring manager.
        
        Args:
            api_key: Abacus.AI API key
        """
        self.client = ApiClient(api_key=api_key)
        self.deployments = {}
        self.monitoring_configs = {}
    
    def initialize(self):
        """
        Initialize the manager by fetching deployment information.
        """
        # Get existing deployments
        deployments = self.client.list_deployments()
        
        for model_key, model_config in MODELS.items():
            deployment = next(
                (d for d in deployments if d.name == f"{model_config['name']}_deployment"),
                None
            )
            
            if deployment:
                self.deployments[model_key] = deployment
                logger.info(f"Found deployment for {model_config['name']} with ID: {deployment.id}")
            else:
                logger.warning(f"No deployment found for model {model_config['name']}")
    
    def setup_model_monitoring(self) -> Dict[str, str]:
        """
        Set up monitoring for all deployed models.
        
        Returns:
            Dict mapping model keys to monitoring configuration IDs
        """
        monitoring_ids = {}
        
        for model_key, deployment in self.deployments.items():
            logger.info(f"Setting up monitoring for model: {MODELS[model_key]['name']}")
            
            # Check if monitoring already exists
            existing_monitoring = self.client.list_deployment_monitorings()
            existing_config = next(
                (m for m in existing_monitoring if hasattr(m, 'deployment_id') and m.deployment_id == deployment.id),
                None
            )
            
            if existing_config:
                logger.info(f"Monitoring for {MODELS[model_key]['name']} already exists with ID: {existing_config.id}")
                monitoring_ids[model_key] = existing_config.id
                self.monitoring_configs[model_key] = existing_config
                continue
            
            # Create new monitoring configuration
            try:
                monitoring_config = self.client.create_deployment_monitoring(
                    deployment_id=deployment.id,
                    name=f"{MODELS[model_key]['name']}_monitoring",
                    description=f"Monitoring for {MODELS[model_key]['name']}",
                    enable_drift_detection=True,
                    enable_performance_monitoring=True,
                    alert_on_drift=True,
                    alert_on_performance_degradation=True
                )
                
                logger.info(f"Created monitoring for {MODELS[model_key]['name']} with ID: {monitoring_config.id}")
                monitoring_ids[model_key] = monitoring_config.id
                self.monitoring_configs[model_key] = monitoring_config
                
            except Exception as e:
                logger.error(f"Error setting up monitoring for {MODELS[model_key]['name']}: {str(e)}")
                # Continue with other models
        
        return monitoring_ids
    
    def setup_feature_monitoring(self) -> Dict[str, str]:
        """
        Set up monitoring for feature stores.
        
        Returns:
            Dict mapping feature store names to monitoring configuration IDs
        """
        # In a real implementation, this would set up monitoring for feature stores
        # For now, we'll return a placeholder
        return {}
    
    def setup_recommendation_quality_monitoring(self) -> Dict[str, str]:
        """
        Set up monitoring for recommendation quality.
        
        Returns:
            Dict mapping recommendation types to monitoring configuration IDs
        """
        # In a real implementation, this would set up monitoring for recommendation quality
        # For now, we'll return a placeholder
        return {}
    
    def setup_alerts(self) -> Dict[str, str]:
        """
        Set up alerts for monitoring.
        
        Returns:
            Dict mapping alert names to alert configuration IDs
        """
        alert_ids = {}
        
        # Set up model drift alerts
        for model_key, monitoring_config in self.monitoring_configs.items():
            logger.info(f"Setting up drift alert for model: {MODELS[model_key]['name']}")
            
            try:
                alert = self.client.create_alert(
                    name=f"{MODELS[model_key]['name']}_drift_alert",
                    description=f"Alert for drift in {MODELS[model_key]['name']}",
                    alert_type="DRIFT",
                    resource_id=monitoring_config.id,
                    threshold=0.5,  # Drift threshold
                    notification_channels=["EMAIL"]
                )
                
                logger.info(f"Created drift alert for {MODELS[model_key]['name']} with ID: {alert.id}")
                alert_ids[f"{model_key}_drift"] = alert.id
                
            except Exception as e:
                logger.error(f"Error setting up drift alert for {MODELS[model_key]['name']}: {str(e)}")
                # Continue with other alerts
        
        # Set up performance degradation alerts
        for model_key, monitoring_config in self.monitoring_configs.items():
            logger.info(f"Setting up performance alert for model: {MODELS[model_key]['name']}")
            
            try:
                alert = self.client.create_alert(
                    name=f"{MODELS[model_key]['name']}_performance_alert",
                    description=f"Alert for performance degradation in {MODELS[model_key]['name']}",
                    alert_type="PERFORMANCE",
                    resource_id=monitoring_config.id,
                    threshold=0.2,  # Performance degradation threshold (20%)
                    notification_channels=["EMAIL"]
                )
                
                logger.info(f"Created performance alert for {MODELS[model_key]['name']} with ID: {alert.id}")
                alert_ids[f"{model_key}_performance"] = alert.id
                
            except Exception as e:
                logger.error(f"Error setting up performance alert for {MODELS[model_key]['name']}: {str(e)}")
                # Continue with other alerts
        
        return alert_ids
    
    def create_monitoring_dashboard(self) -> str:
        """
        Create a monitoring dashboard.
        
        Returns:
            Dashboard ID
        """
        # In a real implementation, this would create a dashboard in Abacus.AI
        # For now, we'll return a placeholder
        dashboard_id = "dashboard_123"
        logger.info(f"Created monitoring dashboard with ID: {dashboard_id}")
        return dashboard_id

def setup_monitoring():
    """
    Set up monitoring for the ML pipeline.
    
    Returns:
        Monitoring manager instance
    """
    manager = MonitoringManager()
    
    # Initialize manager
    manager.initialize()
    
    # Set up model monitoring
    monitoring_ids = manager.setup_model_monitoring()
    logger.info(f"Set up model monitoring: {monitoring_ids}")
    
    # Set up feature monitoring
    feature_monitoring_ids = manager.setup_feature_monitoring()
    logger.info(f"Set up feature monitoring: {feature_monitoring_ids}")
    
    # Set up recommendation quality monitoring
    recommendation_monitoring_ids = manager.setup_recommendation_quality_monitoring()
    logger.info(f"Set up recommendation quality monitoring: {recommendation_monitoring_ids}")
    
    # Set up alerts
    alert_ids = manager.setup_alerts()
    logger.info(f"Set up alerts: {alert_ids}")
    
    # Create monitoring dashboard
    dashboard_id = manager.create_monitoring_dashboard()
    logger.info(f"Created monitoring dashboard: {dashboard_id}")
    
    return manager

if __name__ == "__main__":
    setup_monitoring()
