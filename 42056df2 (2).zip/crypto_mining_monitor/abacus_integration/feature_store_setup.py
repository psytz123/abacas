
"""
Feature store setup for Abacus.AI integration.

This module provides functions for creating and updating feature stores in Abacus.AI
to store and manage mining telemetry and performance data from our API clients.
"""

import logging
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import abacusai
from abacusai import ApiClient

from config import (
    ABACUSAI_API_KEY,
    FEATURE_STORES,
    FEATURE_DEFINITIONS
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FeatureStoreManager:
    """
    Manager for creating and updating feature stores in Abacus.AI.
    """
    
    def __init__(self, api_key: str = ABACUSAI_API_KEY):
        """
        Initialize the feature store manager.
        
        Args:
            api_key: Abacus.AI API key
        """
        self.client = ApiClient(api_key=api_key)
        self.feature_groups = {}
        self.deployments = {}
        
    def create_feature_stores(self) -> Dict[str, str]:
        """
        Create all feature stores defined in the configuration.
        
        Returns:
            Dict mapping feature store names to their IDs
        """
        feature_group_ids = {}
        
        for store_key, store_config in FEATURE_STORES.items():
            logger.info(f"Creating feature store: {store_config['name']}")
            
            # Check if feature group already exists
            existing_groups = self.client.list_feature_groups()
            existing_group = next(
                (g for g in existing_groups if g.name == store_config['name']),
                None
            )
            
            if existing_group:
                logger.info(f"Feature store {store_config['name']} already exists with ID: {existing_group.id}")
                feature_group_ids[store_key] = existing_group.id
                self.feature_groups[store_key] = existing_group
                continue
            
            # Create new feature group
            try:
                feature_group = self.client.create_feature_group(
                    name=store_config['name'],
                    description=store_config['description'],
                    feature_definitions=FEATURE_DEFINITIONS[store_key],
                    primary_key=store_config['entity_id'],
                    timestamp_key=store_config['timestamp_column']
                )
                
                logger.info(f"Created feature store {store_config['name']} with ID: {feature_group.id}")
                feature_group_ids[store_key] = feature_group.id
                self.feature_groups[store_key] = feature_group
                
            except Exception as e:
                logger.error(f"Error creating feature store {store_config['name']}: {str(e)}")
                raise
        
        return feature_group_ids
    
    def deploy_feature_stores(self) -> Dict[str, str]:
        """
        Deploy feature stores for online serving.
        
        Returns:
            Dict mapping feature store names to their deployment IDs
        """
        deployment_ids = {}
        
        for store_key, feature_group in self.feature_groups.items():
            logger.info(f"Deploying feature store: {feature_group.name}")
            
            # Check if deployment already exists
            existing_deployments = self.client.list_feature_group_deployments()
            existing_deployment = next(
                (d for d in existing_deployments if d.feature_group_id == feature_group.id),
                None
            )
            
            if existing_deployment:
                logger.info(f"Feature store deployment for {feature_group.name} already exists with ID: {existing_deployment.id}")
                deployment_ids[store_key] = existing_deployment.id
                self.deployments[store_key] = existing_deployment
                continue
            
            # Create new deployment
            try:
                deployment = self.client.create_feature_group_deployment(
                    feature_group_id=feature_group.id,
                    name=f"{feature_group.name}_deployment",
                    description=f"Deployment for {feature_group.name}"
                )
                
                logger.info(f"Created deployment for {feature_group.name} with ID: {deployment.id}")
                deployment_ids[store_key] = deployment.id
                self.deployments[store_key] = deployment
                
            except Exception as e:
                logger.error(f"Error deploying feature store {feature_group.name}: {str(e)}")
                raise
        
        return deployment_ids
    
    def upload_miner_telemetry_data(self, telemetry_data: List[Dict[str, Any]]) -> str:
        """
        Upload miner telemetry data to the feature store.
        
        Args:
            telemetry_data: List of telemetry data records
        
        Returns:
            Upload job ID
        """
        if 'miner_telemetry' not in self.feature_groups:
            raise ValueError("Miner telemetry feature store not initialized")
        
        feature_group = self.feature_groups['miner_telemetry']
        
        # Format data for upload
        formatted_data = []
        for record in telemetry_data:
            formatted_record = {
                "miner_id": record["miner_id"],
                "timestamp": datetime.fromtimestamp(record["timestamp"]).isoformat(),
                "hashrate_th_s": record["hashrate"]["total"],
                "power_consumption_w": record["power"]["consumption"],
                "efficiency_j_th": record["power"]["efficiency"],
                "avg_chip_temp_c": record["temperature"]["avg_chip"],
                "max_chip_temp_c": record["temperature"]["max_chip"],
                "fan_speed_percent": record["fans"][0]["speed_percent"] if record["fans"] else 0,
                "accepted_shares": record["shares"]["accepted"],
                "rejected_shares": record["shares"]["rejected"],
                # Derived features
                "hashrate_stability": self._calculate_hashrate_stability(record),
                "power_efficiency_trend": self._calculate_efficiency_trend(record),
                "thermal_efficiency": self._calculate_thermal_efficiency(record),
                "overclock_profile": record["config"]["overclock_profile"],
                "uptime_hours": record["status"]["uptime"] / 3600,
                "error_rate": self._calculate_error_rate(record),
                "hashboard_variance": self._calculate_hashboard_variance(record)
            }
            formatted_data.append(formatted_record)
        
        # Upload to feature store
        try:
            upload_job = self.client.create_feature_group_upload_job(
                feature_group_id=feature_group.id,
                data=formatted_data
            )
            
            logger.info(f"Uploaded {len(formatted_data)} telemetry records with job ID: {upload_job.id}")
            return upload_job.id
            
        except Exception as e:
            logger.error(f"Error uploading telemetry data: {str(e)}")
            raise
    
    def upload_pool_performance_data(self, pool_data: List[Dict[str, Any]]) -> str:
        """
        Upload pool performance data to the feature store.
        
        Args:
            pool_data: List of pool performance data records
        
        Returns:
            Upload job ID
        """
        if 'pool_performance' not in self.feature_groups:
            raise ValueError("Pool performance feature store not initialized")
        
        feature_group = self.feature_groups['pool_performance']
        
        # Format data for upload
        formatted_data = []
        for record in pool_data:
            formatted_record = {
                "worker_id": record["worker_id"],
                "timestamp": datetime.fromtimestamp(record["timestamp"]).isoformat(),
                "pool_id": record["pool_id"],
                "algorithm": record["algorithm"],
                "reported_hashrate": record["hashrate"]["reported"],
                "effective_hashrate": record["hashrate"]["effective"],
                "hashrate_unit": record["hashrate"]["unit"],
                "accepted_shares": record["shares"]["accepted"],
                "rejected_shares": record["shares"]["rejected"],
                "earnings_amount": record["earnings"]["amount"],
                "earnings_currency": record["earnings"]["currency"],
                "earnings_per_th_usd": self._calculate_earnings_per_th(record),
                "primary_coin": record["coins_mined"][0]["symbol"] if record["coins_mined"] else "",
                "merge_mining_bonus_percent": self._calculate_merge_mining_bonus(record),
                "difficulty": record["difficulty"],
                "status": record["status"]
            }
            formatted_data.append(formatted_record)
        
        # Upload to feature store
        try:
            upload_job = self.client.create_feature_group_upload_job(
                feature_group_id=feature_group.id,
                data=formatted_data
            )
            
            logger.info(f"Uploaded {len(formatted_data)} pool performance records with job ID: {upload_job.id}")
            return upload_job.id
            
        except Exception as e:
            logger.error(f"Error uploading pool performance data: {str(e)}")
            raise
    
    def upload_market_data(self, market_data: List[Dict[str, Any]]) -> str:
        """
        Upload cryptocurrency market data to the feature store.
        
        Args:
            market_data: List of market data records
        
        Returns:
            Upload job ID
        """
        if 'market_data' not in self.feature_groups:
            raise ValueError("Market data feature store not initialized")
        
        feature_group = self.feature_groups['market_data']
        
        # Format data for upload
        formatted_data = []
        for record in market_data:
            formatted_record = {
                "coin_id": record["coin_id"],
                "timestamp": datetime.fromtimestamp(record["timestamp"]).isoformat(),
                "symbol": record["symbol"],
                "price_usd": record["price_usd"],
                "price_btc": record["price_btc"],
                "market_cap_usd": record["market_cap_usd"],
                "volume_24h_usd": record["volume_24h_usd"],
                "price_change_24h_percent": record["price_change_24h_percent"],
                "price_change_7d_percent": record["price_change_7d_percent"],
                "network_hashrate": record["network_hashrate"],
                "network_difficulty": record["network_difficulty"],
                "block_reward_usd": record["block_reward_usd"],
                "transaction_fees_percent": record["transaction_fees_percent"],
                "volatility_30d": record["volatility_30d"],
                "halving_countdown_days": record["halving_countdown_days"]
            }
            formatted_data.append(formatted_record)
        
        # Upload to feature store
        try:
            upload_job = self.client.create_feature_group_upload_job(
                feature_group_id=feature_group.id,
                data=formatted_data
            )
            
            logger.info(f"Uploaded {len(formatted_data)} market data records with job ID: {upload_job.id}")
            return upload_job.id
            
        except Exception as e:
            logger.error(f"Error uploading market data: {str(e)}")
            raise
    
    def upload_derived_metrics(self, derived_metrics: List[Dict[str, Any]]) -> str:
        """
        Upload derived mining metrics to the feature store.
        
        Args:
            derived_metrics: List of derived metrics records
        
        Returns:
            Upload job ID
        """
        if 'derived_metrics' not in self.feature_groups:
            raise ValueError("Derived metrics feature store not initialized")
        
        feature_group = self.feature_groups['derived_metrics']
        
        # Upload to feature store
        try:
            upload_job = self.client.create_feature_group_upload_job(
                feature_group_id=feature_group.id,
                data=derived_metrics
            )
            
            logger.info(f"Uploaded {len(derived_metrics)} derived metrics records with job ID: {upload_job.id}")
            return upload_job.id
            
        except Exception as e:
            logger.error(f"Error uploading derived metrics: {str(e)}")
            raise
    
    def get_online_features(self, store_key: str, entity_ids: List[str]) -> Dict[str, Any]:
        """
        Get online features for specific entities.
        
        Args:
            store_key: Feature store key
            entity_ids: List of entity IDs
        
        Returns:
            Dict containing the feature values
        """
        if store_key not in self.deployments:
            raise ValueError(f"Feature store {store_key} not deployed")
        
        deployment = self.deployments[store_key]
        
        try:
            features = self.client.get_deployed_feature_values(
                deployment_id=deployment.id,
                entity_ids=entity_ids
            )
            
            return features
            
        except Exception as e:
            logger.error(f"Error getting online features: {str(e)}")
            raise
    
    def _calculate_hashrate_stability(self, record: Dict[str, Any]) -> float:
        """Calculate hashrate stability from telemetry data."""
        # This would typically use historical data to calculate variance
        # For now, we'll return a placeholder value
        return 0.95
    
    def _calculate_efficiency_trend(self, record: Dict[str, Any]) -> float:
        """Calculate power efficiency trend from telemetry data."""
        # This would typically use historical data to calculate trend
        # For now, we'll return a placeholder value
        return 0.0
    
    def _calculate_thermal_efficiency(self, record: Dict[str, Any]) -> float:
        """Calculate thermal efficiency from telemetry data."""
        hashrate = record["hashrate"]["total"]
        avg_temp = record["temperature"]["avg_chip"]
        
        if avg_temp <= 0:
            return 0.0
        
        return hashrate / avg_temp
    
    def _calculate_error_rate(self, record: Dict[str, Any]) -> float:
        """Calculate error rate from telemetry data."""
        accepted = record["shares"]["accepted"]
        rejected = record["shares"]["rejected"]
        
        if accepted + rejected == 0:
            return 0.0
        
        return rejected / (accepted + rejected)
    
    def _calculate_hashboard_variance(self, record: Dict[str, Any]) -> float:
        """Calculate variance between hashboards from telemetry data."""
        hashboards = record["hashrate"].get("per_hashboard", [])
        
        if not hashboards:
            return 0.0
        
        hashrates = [board.get("hashrate", 0.0) for board in hashboards]
        
        if not hashrates:
            return 0.0
        
        mean_hashrate = sum(hashrates) / len(hashrates)
        
        if mean_hashrate == 0:
            return 0.0
        
        variance = sum((hr - mean_hashrate) ** 2 for hr in hashrates) / len(hashrates)
        normalized_variance = variance / (mean_hashrate ** 2)
        
        return normalized_variance
    
    def _calculate_earnings_per_th(self, record: Dict[str, Any]) -> float:
        """Calculate earnings per TH/s in USD."""
        earnings = record["earnings"]["amount"]
        effective_hashrate = record["hashrate"]["effective"]
        hashrate_unit = record["hashrate"]["unit"]
        
        if effective_hashrate <= 0:
            return 0.0
        
        # Convert hashrate to TH/s if needed
        hashrate_th = effective_hashrate
        if hashrate_unit == "GH/s":
            hashrate_th = effective_hashrate / 1000
        elif hashrate_unit == "MH/s":
            hashrate_th = effective_hashrate / 1000000
        elif hashrate_unit == "KH/s":
            hashrate_th = effective_hashrate / 1000000000
        
        if hashrate_th <= 0:
            return 0.0
        
        return earnings / hashrate_th
    
    def _calculate_merge_mining_bonus(self, record: Dict[str, Any]) -> float:
        """Calculate merge mining bonus percentage."""
        coins_mined = record["coins_mined"]
        
        if len(coins_mined) <= 1:
            return 0.0
        
        primary_coin = next((c for c in coins_mined if c["mining_type"] == "primary"), None)
        merge_mined_coins = [c for c in coins_mined if c["mining_type"] != "primary"]
        
        if not primary_coin or not merge_mined_coins:
            return 0.0
        
        primary_value = primary_coin["usd_value"]
        merge_mined_value = sum(c["usd_value"] for c in merge_mined_coins)
        
        if primary_value <= 0:
            return 0.0
        
        return (merge_mined_value / primary_value) * 100

def setup_feature_stores():
    """
    Set up all feature stores in Abacus.AI.
    
    Returns:
        Feature store manager instance
    """
    manager = FeatureStoreManager()
    
    # Create feature stores
    feature_group_ids = manager.create_feature_stores()
    logger.info(f"Created feature stores: {feature_group_ids}")
    
    # Deploy feature stores
    deployment_ids = manager.deploy_feature_stores()
    logger.info(f"Deployed feature stores: {deployment_ids}")
    
    return manager

if __name__ == "__main__":
    setup_feature_stores()
