
"""
Model deployment configuration for Abacus.AI integration.

This module provides functions for deploying trained models as real-time
endpoints in Abacus.AI for serving recommendations.
"""

import logging
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import abacusai
from abacusai import ApiClient

from config import (
    ABACUSAI_API_KEY,
    MODELS,
    DEPLOYMENT_CONFIG
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModelDeploymentManager:
    """
    Manager for deploying trained models in Abacus.AI.
    """
    
    def __init__(self, api_key: str = ABACUSAI_API_KEY):
        """
        Initialize the model deployment manager.
        
        Args:
            api_key: Abacus.AI API key
        """
        self.client = ApiClient(api_key=api_key)
        self.model_versions = {}
        self.deployments = {}
    
    def initialize(self):
        """
        Initialize the manager by fetching existing model versions.
        """
        # Get existing model versions
        model_versions = self.client.list_model_versions()
        
        for model_key, model_config in MODELS.items():
            model_version = next(
                (m for m in model_versions if m.name == model_config['name']),
                None
            )
            
            if model_version:
                self.model_versions[model_key] = model_version
                logger.info(f"Found model version {model_config['name']} with ID: {model_version.id}")
            else:
                logger.warning(f"Model version {model_config['name']} not found")
    
    def deploy_models(self) -> Dict[str, str]:
        """
        Deploy all trained models as real-time endpoints.
        
        Returns:
            Dict mapping model keys to deployment IDs
        """
        deployment_ids = {}
        
        for model_key, model_version in self.model_versions.items():
            logger.info(f"Deploying model: {model_version.name}")
            
            # Check if deployment already exists
            existing_deployments = self.client.list_deployments()
            existing_deployment = next(
                (d for d in existing_deployments if d.model_version_id == model_version.id),
                None
            )
            
            if existing_deployment:
                logger.info(f"Deployment for {model_version.name} already exists with ID: {existing_deployment.id}")
                deployment_ids[model_key] = existing_deployment.id
                self.deployments[model_key] = existing_deployment
                continue
            
            # Create new deployment
            try:
                deployment = self.client.create_deployment(
                    model_version_id=model_version.id,
                    name=f"{model_version.name}_deployment",
                    description=f"Deployment for {model_version.name}",
                    min_workers=DEPLOYMENT_CONFIG['min_workers'],
                    max_workers=DEPLOYMENT_CONFIG['max_workers'],
                    per_worker=DEPLOYMENT_CONFIG['per_worker']
                )
                
                logger.info(f"Created deployment for {model_version.name} with ID: {deployment.id}")
                deployment_ids[model_key] = deployment.id
                self.deployments[model_key] = deployment
                
            except Exception as e:
                logger.error(f"Error deploying model {model_version.name}: {str(e)}")
                raise
        
        return deployment_ids
    
    def wait_for_deployments(self, timeout_minutes: int = 15) -> Dict[str, str]:
        """
        Wait for all deployments to be ready.
        
        Args:
            timeout_minutes: Maximum time to wait in minutes
        
        Returns:
            Dict mapping model keys to deployment status
        """
        start_time = time.time()
        timeout_seconds = timeout_minutes * 60
        deployment_status = {}
        
        # Initialize status for all deployments
        for model_key, deployment in self.deployments.items():
            deployment_status[model_key] = "DEPLOYING"
        
        # Wait for all deployments to be ready
        while any(status == "DEPLOYING" for status in deployment_status.values()):
            # Check timeout
            if time.time() - start_time > timeout_seconds:
                logger.warning(f"Timeout waiting for deployments to be ready after {timeout_minutes} minutes")
                break
            
            # Check status of each deployment
            for model_key, deployment in self.deployments.items():
                if deployment_status[model_key] == "DEPLOYING":
                    try:
                        updated_deployment = self.client.get_deployment(deployment.id)
                        
                        if updated_deployment.status in ["READY", "FAILED", "CANCELLED"]:
                            deployment_status[model_key] = updated_deployment.status
                            logger.info(f"Deployment for {self.model_versions[model_key].name} {updated_deployment.status}")
                    except Exception as e:
                        logger.error(f"Error checking deployment status: {str(e)}")
            
            # Wait before checking again
            time.sleep(30)
        
        return deployment_status
    
    def configure_monitoring(self) -> Dict[str, str]:
        """
        Configure monitoring for all deployments.
        
        Returns:
            Dict mapping model keys to monitoring configuration IDs
        """
        monitoring_ids = {}
        
        if not DEPLOYMENT_CONFIG['enable_monitoring']:
            logger.info("Monitoring is disabled in configuration")
            return monitoring_ids
        
        for model_key, deployment in self.deployments.items():
            logger.info(f"Configuring monitoring for deployment: {deployment.name}")
            
            # Configure monitoring
            try:
                monitoring_config = self.client.create_deployment_monitoring(
                    deployment_id=deployment.id,
                    name=f"{deployment.name}_monitoring",
                    description=f"Monitoring for {deployment.name}",
                    enable_drift_detection=True,
                    enable_performance_monitoring=True,
                    alert_on_drift=True,
                    alert_on_performance_degradation=True
                )
                
                logger.info(f"Configured monitoring for {deployment.name} with ID: {monitoring_config.id}")
                monitoring_ids[model_key] = monitoring_config.id
                
            except Exception as e:
                logger.error(f"Error configuring monitoring for {deployment.name}: {str(e)}")
                # Continue with other deployments
        
        return monitoring_ids
    
    def get_deployment_endpoints(self) -> Dict[str, str]:
        """
        Get the endpoint URLs for all deployments.
        
        Returns:
            Dict mapping model keys to endpoint URLs
        """
        endpoints = {}
        
        for model_key, deployment in self.deployments.items():
            try:
                deployment_details = self.client.get_deployment(deployment.id)
                
                if hasattr(deployment_details, 'endpoint_url') and deployment_details.endpoint_url:
                    endpoints[model_key] = deployment_details.endpoint_url
                    logger.info(f"Endpoint for {deployment.name}: {deployment_details.endpoint_url}")
                else:
                    logger.warning(f"No endpoint URL found for deployment {deployment.name}")
            except Exception as e:
                logger.error(f"Error getting endpoint URL for {deployment.name}: {str(e)}")
        
        return endpoints

def deploy_models():
    """
    Deploy all trained models in Abacus.AI.
    
    Returns:
        Model deployment manager instance
    """
    manager = ModelDeploymentManager()
    
    # Initialize manager
    manager.initialize()
    
    # Deploy models
    deployment_ids = manager.deploy_models()
    logger.info(f"Created deployments: {deployment_ids}")
    
    # Wait for deployments to be ready
    deployment_status = manager.wait_for_deployments()
    logger.info(f"Deployment status: {deployment_status}")
    
    # Configure monitoring
    monitoring_ids = manager.configure_monitoring()
    logger.info(f"Configured monitoring: {monitoring_ids}")
    
    # Get deployment endpoints
    endpoints = manager.get_deployment_endpoints()
    logger.info(f"Deployment endpoints: {endpoints}")
    
    return manager

if __name__ == "__main__":
    deploy_models()
