
"""
Configuration for Abacus.AI integration.

This module contains configuration settings for connecting to Abacus.AI,
defining feature stores, and setting up model training and deployment.
"""

import os
from typing import Dict, Any, List

# Abacus.AI API configuration
ABACUSAI_API_KEY = os.environ.get("ABACUSAI_API_KEY", "your_api_key_here")
ABACUSAI_BASE_URL = "https://api.abacus.ai"

# Project configuration
PROJECT_NAME = "Crypto Mining Recommendations"
PROJECT_DESCRIPTION = "ML recommendation engine for cryptocurrency mining optimization"

# Feature store configuration
FEATURE_STORES = {
    "miner_telemetry": {
        "name": "miner_telemetry_features",
        "description": "Telemetry data from cryptocurrency miners via Vnish firmware",
        "entity_id": "miner_id",
        "timestamp_column": "timestamp",
        "update_frequency_minutes": 15
    },
    "pool_performance": {
        "name": "pool_performance_features",
        "description": "Mining pool performance data from Prohashing.com",
        "entity_id": "worker_id",
        "timestamp_column": "timestamp",
        "update_frequency_minutes": 30
    },
    "market_data": {
        "name": "market_data_features",
        "description": "Cryptocurrency market data including prices, volumes, and technical indicators",
        "entity_id": "coin_id",
        "timestamp_column": "timestamp",
        "update_frequency_minutes": 15
    },
    "derived_metrics": {
        "name": "derived_mining_metrics",
        "description": "Calculated metrics combining telemetry, pool, and market data",
        "entity_id": "miner_id",
        "timestamp_column": "timestamp",
        "update_frequency_minutes": 60
    }
}

# Model configuration
MODELS = {
    "profitability_prediction": {
        "name": "coin_profitability_prediction",
        "description": "Predicts mining profitability for different cryptocurrencies",
        "algorithm": "XGBOOST",
        "problem_type": "REGRESSION",
        "target_feature": "earnings_per_th_usd",
        "prediction_horizon": "24h",
        "training_frequency": "DAILY",
        "feature_groups": ["pool_performance", "market_data", "miner_telemetry"],
        "hyperparameters": {
            "objective": "reg:squarederror",
            "learning_rate": 0.05,
            "max_depth": 6,
            "min_child_weight": 1,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "gamma": 0,
            "alpha": 0.1,
            "lambda": 1,
            "n_estimators": 200
        }
    },
    "power_optimization": {
        "name": "power_optimization",
        "description": "Determines optimal power settings for miners",
        "algorithm": "BAYESIAN_OPTIMIZATION",
        "problem_type": "REGRESSION",
        "target_feature": "efficiency_j_th",
        "prediction_horizon": "1h",
        "training_frequency": "WEEKLY",
        "feature_groups": ["miner_telemetry", "pool_performance", "market_data"],
        "hyperparameters": {
            "acquisition_function": "expected_improvement",
            "alpha": 0.0001,
            "n_initial_points": 10,
            "noise": "gaussian",
            "normalize_y": True
        }
    },
    "anomaly_detection": {
        "name": "hardware_anomaly_detection",
        "description": "Identifies abnormal behavior in mining operations",
        "algorithm": "ISOLATION_FOREST",
        "problem_type": "ANOMALY_DETECTION",
        "training_frequency": "WEEKLY",
        "feature_groups": ["miner_telemetry", "derived_metrics"],
        "hyperparameters": {
            "n_estimators": 100,
            "max_samples": "auto",
            "contamination": 0.05,
            "max_features": 1.0,
            "bootstrap": False
        }
    },
    "hardware_lifecycle": {
        "name": "hardware_lifecycle_prediction",
        "description": "Predicts hardware longevity and maintenance needs",
        "algorithm": "SURVIVAL_ANALYSIS",
        "problem_type": "SURVIVAL_ANALYSIS",
        "target_feature": "time_to_failure",
        "event_feature": "failure_observed",
        "training_frequency": "MONTHLY",
        "feature_groups": ["miner_telemetry", "derived_metrics"],
        "hyperparameters": {
            "alpha": 0.05,
            "ties": "efron",
            "penalizer": 0.1,
            "l1_ratio": 0.0
        }
    }
}

# Deployment configuration
DEPLOYMENT_CONFIG = {
    "min_workers": 1,
    "max_workers": 5,
    "per_worker": 10,  # Requests per worker
    "timeout": 30,  # Seconds
    "enable_monitoring": True,
    "enable_logging": True,
    "enable_explanation": True
}

# Recommendation types mapping to models
RECOMMENDATION_TYPES = {
    "coin_switching": ["profitability_prediction"],
    "power_optimization": ["power_optimization"],
    "hardware_configuration": ["power_optimization", "profitability_prediction"],
    "maintenance": ["anomaly_detection", "hardware_lifecycle"],
    "hardware_upgrade": ["hardware_lifecycle", "profitability_prediction"]
}

# Feature definitions
FEATURE_DEFINITIONS = {
    "miner_telemetry": [
        {"name": "miner_id", "dataType": "STRING", "tags": ["entity_id"]},
        {"name": "timestamp", "dataType": "TIMESTAMP", "tags": ["timestamp"]},
        {"name": "hashrate_th_s", "dataType": "FLOAT"},
        {"name": "power_consumption_w", "dataType": "FLOAT"},
        {"name": "efficiency_j_th", "dataType": "FLOAT"},
        {"name": "avg_chip_temp_c", "dataType": "FLOAT"},
        {"name": "max_chip_temp_c", "dataType": "FLOAT"},
        {"name": "fan_speed_percent", "dataType": "FLOAT"},
        {"name": "accepted_shares", "dataType": "INTEGER"},
        {"name": "rejected_shares", "dataType": "INTEGER"},
        {"name": "hashrate_stability", "dataType": "FLOAT"},
        {"name": "power_efficiency_trend", "dataType": "FLOAT"},
        {"name": "thermal_efficiency", "dataType": "FLOAT"},
        {"name": "overclock_profile", "dataType": "STRING"},
        {"name": "uptime_hours", "dataType": "FLOAT"},
        {"name": "error_rate", "dataType": "FLOAT"},
        {"name": "hashboard_variance", "dataType": "FLOAT"}
    ],
    "pool_performance": [
        {"name": "worker_id", "dataType": "STRING", "tags": ["entity_id"]},
        {"name": "timestamp", "dataType": "TIMESTAMP", "tags": ["timestamp"]},
        {"name": "pool_id", "dataType": "STRING"},
        {"name": "algorithm", "dataType": "STRING"},
        {"name": "reported_hashrate", "dataType": "FLOAT"},
        {"name": "effective_hashrate", "dataType": "FLOAT"},
        {"name": "hashrate_unit", "dataType": "STRING"},
        {"name": "accepted_shares", "dataType": "INTEGER"},
        {"name": "rejected_shares", "dataType": "INTEGER"},
        {"name": "earnings_amount", "dataType": "FLOAT"},
        {"name": "earnings_currency", "dataType": "STRING"},
        {"name": "earnings_per_th_usd", "dataType": "FLOAT"},
        {"name": "primary_coin", "dataType": "STRING"},
        {"name": "merge_mining_bonus_percent", "dataType": "FLOAT"},
        {"name": "difficulty", "dataType": "FLOAT"},
        {"name": "status", "dataType": "STRING"}
    ],
    "market_data": [
        {"name": "coin_id", "dataType": "STRING", "tags": ["entity_id"]},
        {"name": "timestamp", "dataType": "TIMESTAMP", "tags": ["timestamp"]},
        {"name": "symbol", "dataType": "STRING"},
        {"name": "price_usd", "dataType": "FLOAT"},
        {"name": "price_btc", "dataType": "FLOAT"},
        {"name": "market_cap_usd", "dataType": "FLOAT"},
        {"name": "volume_24h_usd", "dataType": "FLOAT"},
        {"name": "price_change_24h_percent", "dataType": "FLOAT"},
        {"name": "price_change_7d_percent", "dataType": "FLOAT"},
        {"name": "network_hashrate", "dataType": "FLOAT"},
        {"name": "network_difficulty", "dataType": "FLOAT"},
        {"name": "block_reward_usd", "dataType": "FLOAT"},
        {"name": "transaction_fees_percent", "dataType": "FLOAT"},
        {"name": "volatility_30d", "dataType": "FLOAT"},
        {"name": "halving_countdown_days", "dataType": "FLOAT"}
    ],
    "derived_metrics": [
        {"name": "miner_id", "dataType": "STRING", "tags": ["entity_id"]},
        {"name": "timestamp", "dataType": "TIMESTAMP", "tags": ["timestamp"]},
        {"name": "actual_profit_margin_percent", "dataType": "FLOAT"},
        {"name": "roi_current_hardware_days", "dataType": "FLOAT"},
        {"name": "optimal_power_limit_w", "dataType": "FLOAT"},
        {"name": "power_cost_per_dollar_earned", "dataType": "FLOAT"},
        {"name": "hardware_upgrade_benefit_score", "dataType": "FLOAT"},
        {"name": "maintenance_urgency_score", "dataType": "FLOAT"},
        {"name": "thermal_risk_score", "dataType": "FLOAT"},
        {"name": "efficiency_vs_market_percentile", "dataType": "FLOAT"},
        {"name": "optimal_coin_allocation", "dataType": "STRING"},
        {"name": "predicted_24h_profit_change", "dataType": "FLOAT"},
        {"name": "hardware_failure_probability", "dataType": "FLOAT"},
        {"name": "opportunity_cost_current_strategy", "dataType": "FLOAT"},
        {"name": "market_based_power_adjustment", "dataType": "FLOAT"}
    ]
}
