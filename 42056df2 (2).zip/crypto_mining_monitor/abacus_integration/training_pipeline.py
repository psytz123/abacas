
"""
Model training pipeline for Abacus.AI integration.

This module provides functions for setting up and executing model training
pipelines in Abacus.AI for different recommendation types.
"""

import logging
import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import abacusai
from abacusai import ApiClient

from config import (
    ABACUSAI_API_KEY,
    MODELS,
    FEATURE_STORES,
    RECOMMENDATION_TYPES
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModelTrainingManager:
    """
    Manager for setting up and executing model training pipelines in Abacus.AI.
    """
    
    def __init__(self, api_key: str = ABACUSAI_API_KEY):
        """
        Initialize the model training manager.
        
        Args:
            api_key: Abacus.AI API key
        """
        self.client = ApiClient(api_key=api_key)
        self.feature_group_ids = {}
        self.model_versions = {}
        self.training_jobs = {}
        
    def initialize(self):
        """
        Initialize the manager by fetching existing feature groups.
        """
        # Get existing feature groups
        feature_groups = self.client.list_feature_groups()
        
        for store_key, store_config in FEATURE_STORES.items():
            feature_group = next(
                (g for g in feature_groups if g.name == store_config['name']),
                None
            )
            
            if feature_group:
                self.feature_group_ids[store_key] = feature_group.id
                logger.info(f"Found feature group {store_config['name']} with ID: {feature_group.id}")
            else:
                logger.warning(f"Feature group {store_config['name']} not found")
    
    def create_training_datasets(self) -> Dict[str, str]:
        """
        Create training datasets for each model.
        
        Returns:
            Dict mapping model keys to dataset IDs
        """
        dataset_ids = {}
        
        for model_key, model_config in MODELS.items():
            logger.info(f"Creating training dataset for model: {model_config['name']}")
            
            # Get feature group IDs for this model
            feature_groups = model_config['feature_groups']
            feature_group_ids = [self.feature_group_ids[fg] for fg in feature_groups if fg in self.feature_group_ids]
            
            if not feature_group_ids:
                logger.warning(f"No feature groups found for model {model_config['name']}")
                continue
            
            # Define point-in-time feature joining
            feature_joins = []
            primary_feature_group_id = feature_group_ids[0]
            
            for i, fg_id in enumerate(feature_group_ids[1:], 1):
                feature_group = next(
                    (g for g in self.client.list_feature_groups() if g.id == fg_id),
                    None
                )
                
                if not feature_group:
                    logger.warning(f"Feature group with ID {fg_id} not found")
                    continue
                
                # Define lookback window based on feature group type
                lookback_window = "24h"
                if "market" in feature_group.name:
                    lookback_window = "24h"
                elif "pool" in feature_group.name:
                    lookback_window = "48h"
                elif "telemetry" in feature_group.name:
                    lookback_window = "72h"
                
                feature_joins.append({
                    "featureGroupId": fg_id,
                    "lookbackWindow": lookback_window
                })
            
            # Create dataset
            try:
                # For survival analysis, we need special handling
                if model_config['problem_type'] == 'SURVIVAL_ANALYSIS':
                    dataset = self.client.create_feature_group_dataset(
                        name=f"{model_config['name']}_dataset",
                        description=f"Dataset for {model_config['name']}",
                        feature_group_id=primary_feature_group_id,
                        feature_joins=feature_joins,
                        target_feature=model_config['target_feature'],
                        event_feature=model_config['event_feature']
                    )
                # For regression/classification with prediction horizon
                elif 'prediction_horizon' in model_config:
                    dataset = self.client.create_feature_group_dataset(
                        name=f"{model_config['name']}_dataset",
                        description=f"Dataset for {model_config['name']}",
                        feature_group_id=primary_feature_group_id,
                        feature_joins=feature_joins,
                        target_feature=model_config['target_feature'],
                        prediction_horizon=model_config['prediction_horizon']
                    )
                # For anomaly detection and other types
                else:
                    dataset = self.client.create_feature_group_dataset(
                        name=f"{model_config['name']}_dataset",
                        description=f"Dataset for {model_config['name']}",
                        feature_group_id=primary_feature_group_id,
                        feature_joins=feature_joins
                    )
                
                logger.info(f"Created dataset for {model_config['name']} with ID: {dataset.id}")
                dataset_ids[model_key] = dataset.id
                
            except Exception as e:
                logger.error(f"Error creating dataset for {model_config['name']}: {str(e)}")
                raise
        
        return dataset_ids
    
    def create_model_versions(self, dataset_ids: Dict[str, str]) -> Dict[str, str]:
        """
        Create model versions for each model.
        
        Args:
            dataset_ids: Dict mapping model keys to dataset IDs
        
        Returns:
            Dict mapping model keys to model version IDs
        """
        model_version_ids = {}
        
        for model_key, model_config in MODELS.items():
            if model_key not in dataset_ids:
                logger.warning(f"No dataset ID found for model {model_config['name']}")
                continue
            
            dataset_id = dataset_ids[model_key]
            logger.info(f"Creating model version for model: {model_config['name']}")
            
            # Check if model version already exists
            existing_models = self.client.list_model_versions()
            existing_model = next(
                (m for m in existing_models if m.name == model_config['name']),
                None
            )
            
            if existing_model:
                logger.info(f"Model version for {model_config['name']} already exists with ID: {existing_model.id}")
                model_version_ids[model_key] = existing_model.id
                self.model_versions[model_key] = existing_model
                continue
            
            # Create new model version
            try:
                # For survival analysis
                if model_config['problem_type'] == 'SURVIVAL_ANALYSIS':
                    model_version = self.client.create_model_version(
                        name=model_config['name'],
                        description=model_config['description'],
                        problem_type=model_config['problem_type'],
                        dataset_id=dataset_id,
                        target=model_config['target_feature'],
                        event=model_config['event_feature'],
                        training_config={
                            "algorithm": model_config['algorithm'],
                            "hyperparameters": model_config['hyperparameters'],
                            "evaluation_metric": "C_INDEX",
                            "validation_strategy": "TIME_SERIES_SPLIT",
                            "validation_percent": 20
                        }
                    )
                # For anomaly detection
                elif model_config['problem_type'] == 'ANOMALY_DETECTION':
                    model_version = self.client.create_model_version(
                        name=model_config['name'],
                        description=model_config['description'],
                        problem_type=model_config['problem_type'],
                        dataset_id=dataset_id,
                        training_config={
                            "algorithm": model_config['algorithm'],
                            "hyperparameters": model_config['hyperparameters'],
                            "contamination": model_config['hyperparameters'].get('contamination', 0.05),
                            "validation_strategy": "TIME_SERIES_SPLIT",
                            "validation_percent": 20
                        }
                    )
                # For regression/classification
                else:
                    model_version = self.client.create_model_version(
                        name=model_config['name'],
                        description=model_config['description'],
                        problem_type=model_config['problem_type'],
                        dataset_id=dataset_id,
                        target=model_config['target_feature'],
                        training_config={
                            "algorithm": model_config['algorithm'],
                            "hyperparameters": model_config['hyperparameters'],
                            "evaluation_metric": "RMSE" if model_config['problem_type'] == 'REGRESSION' else "F1",
                            "validation_strategy": "TIME_SERIES_SPLIT",
                            "validation_percent": 20
                        }
                    )
                
                logger.info(f"Created model version for {model_config['name']} with ID: {model_version.id}")
                model_version_ids[model_key] = model_version.id
                self.model_versions[model_key] = model_version
                
            except Exception as e:
                logger.error(f"Error creating model version for {model_config['name']}: {str(e)}")
                raise
        
        return model_version_ids
    
    def train_models(self) -> Dict[str, str]:
        """
        Train all models.
        
        Returns:
            Dict mapping model keys to training job IDs
        """
        training_job_ids = {}
        
        for model_key, model_version in self.model_versions.items():
            logger.info(f"Training model: {model_version.name}")
            
            # Start training
            try:
                training_job = self.client.create_training_job(
                    model_version_id=model_version.id
                )
                
                logger.info(f"Started training job for {model_version.name} with ID: {training_job.id}")
                training_job_ids[model_key] = training_job.id
                self.training_jobs[model_key] = training_job
                
            except Exception as e:
                logger.error(f"Error training model {model_version.name}: {str(e)}")
                raise
        
        return training_job_ids
    
    def wait_for_training_completion(self, timeout_minutes: int = 60) -> Dict[str, str]:
        """
        Wait for all training jobs to complete.
        
        Args:
            timeout_minutes: Maximum time to wait in minutes
        
        Returns:
            Dict mapping model keys to training status
        """
        start_time = time.time()
        timeout_seconds = timeout_minutes * 60
        training_status = {}
        
        # Initialize status for all jobs
        for model_key, job in self.training_jobs.items():
            training_status[model_key] = "RUNNING"
        
        # Wait for all jobs to complete
        while any(status == "RUNNING" for status in training_status.values()):
            # Check timeout
            if time.time() - start_time > timeout_seconds:
                logger.warning(f"Timeout waiting for training jobs to complete after {timeout_minutes} minutes")
                break
            
            # Check status of each job
            for model_key, job in self.training_jobs.items():
                if training_status[model_key] == "RUNNING":
                    try:
                        updated_job = self.client.get_training_job(job.id)
                        
                        if updated_job.status in ["COMPLETED", "FAILED", "CANCELLED"]:
                            training_status[model_key] = updated_job.status
                            logger.info(f"Training job for {self.model_versions[model_key].name} {updated_job.status}")
                    except Exception as e:
                        logger.error(f"Error checking training job status: {str(e)}")
            
            # Wait before checking again
            time.sleep(30)
        
        return training_status
    
    def schedule_model_retraining(self) -> Dict[str, str]:
        """
        Schedule regular retraining for all models.
        
        Returns:
            Dict mapping model keys to schedule IDs
        """
        schedule_ids = {}
        
        for model_key, model_config in MODELS.items():
            if model_key not in self.model_versions:
                logger.warning(f"No model version found for {model_config['name']}")
                continue
            
            model_version = self.model_versions[model_key]
            logger.info(f"Scheduling retraining for model: {model_version.name}")
            
            # Define CRON expression based on training frequency
            cron_expression = "0 0 * * *"  # Default: daily at midnight
            
            if model_config['training_frequency'] == 'DAILY':
                cron_expression = "0 0 * * *"  # Daily at midnight
            elif model_config['training_frequency'] == 'WEEKLY':
                cron_expression = "0 0 * * 0"  # Weekly on Sunday
            elif model_config['training_frequency'] == 'MONTHLY':
                cron_expression = "0 0 1 * *"  # Monthly on the 1st
            
            # Schedule retraining
            try:
                schedule = self.client.create_training_schedule(
                    model_version_id=model_version.id,
                    cron_expression=cron_expression,
                    description=f"Regular {model_config['training_frequency'].lower()} retraining for {model_version.name}"
                )
                
                logger.info(f"Scheduled retraining for {model_version.name} with ID: {schedule.id}")
                schedule_ids[model_key] = schedule.id
                
            except Exception as e:
                logger.error(f"Error scheduling retraining for {model_version.name}: {str(e)}")
                raise
        
        return schedule_ids

def setup_training_pipeline():
    """
    Set up the model training pipeline in Abacus.AI.
    
    Returns:
        Model training manager instance
    """
    manager = ModelTrainingManager()
    
    # Initialize manager
    manager.initialize()
    
    # Create training datasets
    dataset_ids = manager.create_training_datasets()
    logger.info(f"Created training datasets: {dataset_ids}")
    
    # Create model versions
    model_version_ids = manager.create_model_versions(dataset_ids)
    logger.info(f"Created model versions: {model_version_ids}")
    
    # Train models
    training_job_ids = manager.train_models()
    logger.info(f"Started training jobs: {training_job_ids}")
    
    # Wait for training to complete
    training_status = manager.wait_for_training_completion()
    logger.info(f"Training status: {training_status}")
    
    # Schedule model retraining
    schedule_ids = manager.schedule_model_retraining()
    logger.info(f"Scheduled model retraining: {schedule_ids}")
    
    return manager

if __name__ == "__main__":
    setup_training_pipeline()
