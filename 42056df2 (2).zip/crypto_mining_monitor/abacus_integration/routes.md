
# API Routes for Abacus.AI Integration

This document provides examples of how to integrate the Abacus.AI recommendation engine with the NextJS web application's API routes.

## Table of Contents

1. [Overview](#overview)
2. [Recommendation API](#recommendation-api)
3. [Feedback API](#feedback-api)
4. [History API](#history-api)
5. [Data Ingestion API](#data-ingestion-api)

## Overview

The integration between our NextJS web application and the Abacus.AI recommendation engine is handled through several API routes:

- `/api/recommendations` - Fetches recommendations from the Abacus.AI models
- `/api/recommendations/feedback` - Sends user feedback to improve the models
- `/api/recommendations/history` - Retrieves historical recommendations and their outcomes
- `/api/data/ingest` - Streams mining data to the Abacus.AI feature stores

## Recommendation API

### GET /api/recommendations

Fetches all recommendations for the user's miners.

#### Implementation Example

```typescript
// app/api/recommendations/route.ts
import { NextResponse } from "next/server";
import { RecommendationClient } from "@/lib/abacus/serving_client";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // Initialize the recommendation client
    const client = new RecommendationClient();
    await client.initialize();
    
    // Get miner IDs for the current user
    const minerIds = await getMinerIdsForCurrentUser();
    
    // Fetch features from feature stores
    const minerFeatures = await client.getMinerFeatures(minerIds);
    const poolFeatures = await client.getPoolFeatures(minerIds);
    const marketFeatures = await client.getMarketFeatures();
    const derivedMetrics = await client.getDerivedMetrics(minerIds);
    
    // Generate recommendations
    const recommendations = await client.getAllRecommendations(
      minerIds,
      minerFeatures,
      poolFeatures,
      marketFeatures,
      derivedMetrics
    );
    
    // Format response
    const response = {
      recommendations,
      timestamp: new Date().toISOString(),
      request_id: generateRequestId()
    };
    
    return NextResponse.json(response);
  } catch (error) {
    console.error("Error fetching recommendations:", error);
    return NextResponse.json(
      { error: "Failed to fetch recommendations" },
      { status: 500 }
    );
  }
}

// Helper functions
async function getMinerIdsForCurrentUser() {
  // In a real implementation, this would fetch miner IDs from the database
  return ["miner_001", "miner_007", "miner_010", "miner_011", "miner_012"];
}

function generateRequestId() {
  return `req_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}
```

### POST /api/recommendations

Fetches recommendations with specific filters or constraints.

#### Implementation Example

```typescript
// app/api/recommendations/route.ts (continued)
export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json();
    
    // Initialize the recommendation client
    const client = new RecommendationClient();
    await client.initialize();
    
    // Get miner IDs from request or default to all user miners
    const minerIds = body.miner_ids || await getMinerIdsForCurrentUser();
    
    // Get recommendation types from request or default to all types
    const recommendationTypes = body.recommendation_types || [
      "coin_switching",
      "power_optimization",
      "hardware_configuration",
      "maintenance",
      "hardware_upgrade"
    ];
    
    // Fetch features from feature stores
    const minerFeatures = await client.getMinerFeatures(minerIds);
    const poolFeatures = await client.getPoolFeatures(minerIds);
    const marketFeatures = await client.getMarketFeatures();
    const derivedMetrics = await client.getDerivedMetrics(minerIds);
    
    // Generate recommendations
    const allRecommendations = await client.getAllRecommendations(
      minerIds,
      minerFeatures,
      poolFeatures,
      marketFeatures,
      derivedMetrics
    );
    
    // Filter recommendations by type
    const filteredRecommendations = {};
    for (const type of recommendationTypes) {
      if (allRecommendations[type]) {
        filteredRecommendations[type] = allRecommendations[type];
      }
    }
    
    // Format response
    const response = {
      recommendations: filteredRecommendations,
      timestamp: new Date().toISOString(),
      request_id: generateRequestId()
    };
    
    return NextResponse.json(response);
  } catch (error) {
    console.error("Error processing recommendation request:", error);
    return NextResponse.json(
      { error: "Failed to process recommendation request" },
      { status: 500 }
    );
  }
}
```

## Feedback API

### POST /api/recommendations/feedback

Submits user feedback for a recommendation.

#### Implementation Example

```typescript
// app/api/recommendations/feedback/route.ts
import { NextResponse } from "next/server";
import { RecommendationClient } from "@/lib/abacus/serving_client";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json();
    
    // Validate the request
    if (!body.recommendation_id || !body.feedback_type) {
      return NextResponse.json(
        { error: "Missing required fields: recommendation_id and feedback_type" },
        { status: 400 }
      );
    }
    
    // Initialize the recommendation client
    const client = new RecommendationClient();
    await client.initialize();
    
    // Submit feedback
    const result = await client.submitRecommendationFeedback(
      body.recommendation_id,
      body.feedback_type,
      body.details
    );
    
    // Store feedback in database for tracking
    await storeFeedbackInDatabase(body);
    
    return NextResponse.json({ 
      success: true, 
      message: "Feedback submitted successfully" 
    });
  } catch (error) {
    console.error("Error processing feedback:", error);
    return NextResponse.json(
      { error: "Failed to process feedback" },
      { status: 500 }
    );
  }
}

// Helper function
async function storeFeedbackInDatabase(feedback) {
  // In a real implementation, this would store the feedback in a database
  console.log("Storing feedback in database:", feedback);
}
```

## History API

### GET /api/recommendations/history

Retrieves historical recommendations and their outcomes.

#### Implementation Example

```typescript
// app/api/recommendations/history/route.ts
import { NextResponse } from "next/server";
import { RecommendationClient } from "@/lib/abacus/serving_client";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    // Get query parameters
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "10");
    const type = searchParams.get("type");
    const status = searchParams.get("status");
    
    // Fetch recommendation history from database
    const history = await fetchRecommendationHistory(page, pageSize, type, status);
    
    return NextResponse.json({
      history: history.items,
      total_count: history.totalCount,
      page,
      page_size: pageSize
    });
  } catch (error) {
    console.error("Error fetching recommendation history:", error);
    return NextResponse.json(
      { error: "Failed to fetch recommendation history" },
      { status: 500 }
    );
  }
}

// Helper function
async function fetchRecommendationHistory(page, pageSize, type, status) {
  // In a real implementation, this would fetch history from a database
  // For now, we'll return mock data
  const mockHistory = {
    items: [
      {
        id: "123e4567-e89b-12d3-a456-426614174000",
        type: "coin_switching",
        miner_id: "miner_001",
        current_coin: "BTC",
        recommended_coin: "LTC+DOGE",
        improvement_percent: 12.3,
        confidence: 0.85,
        reasoning: "Recent Dogecoin price surge combined with stable Litecoin difficulty makes merge mining these coins more profitable than Bitcoin mining currently.",
        status: "implemented",
        actual_improvement_percent: 10.8,
        timestamp: "2025-05-15T10:15:30.123456",
        implementation_date: "2025-05-15T11:30:45.123456"
      },
      // More history items...
    ],
    totalCount: 5
  };
  
  // Filter by type if specified
  if (type) {
    mockHistory.items = mockHistory.items.filter(item => item.type === type);
    mockHistory.totalCount = mockHistory.items.length;
  }
  
  // Filter by status if specified
  if (status) {
    mockHistory.items = mockHistory.items.filter(item => item.status === status);
    mockHistory.totalCount = mockHistory.items.length;
  }
  
  return mockHistory;
}
```

## Data Ingestion API

### POST /api/data/ingest

Streams mining data to the Abacus.AI feature stores.

#### Implementation Example

```typescript
// app/api/data/ingest/route.ts
import { NextResponse } from "next/server";
import { FeatureStoreManager } from "@/lib/abacus/feature_store_setup";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json();
    
    // Validate the request
    if (!body.data_type || !body.data) {
      return NextResponse.json(
        { error: "Missing required fields: data_type and data" },
        { status: 400 }
      );
    }
    
    // Initialize the feature store manager
    const manager = new FeatureStoreManager();
    await manager.initialize();
    
    // Upload data to the appropriate feature store
    let uploadJobId;
    
    switch (body.data_type) {
      case "miner_telemetry":
        uploadJobId = await manager.uploadMinerTelemetryData(body.data);
        break;
      case "pool_performance":
        uploadJobId = await manager.uploadPoolPerformanceData(body.data);
        break;
      case "market_data":
        uploadJobId = await manager.uploadMarketData(body.data);
        break;
      case "derived_metrics":
        uploadJobId = await manager.uploadDerivedMetrics(body.data);
        break;
      default:
        return NextResponse.json(
          { error: `Invalid data_type: ${body.data_type}` },
          { status: 400 }
        );
    }
    
    return NextResponse.json({ 
      success: true, 
      message: "Data ingested successfully",
      upload_job_id: uploadJobId
    });
  } catch (error) {
    console.error("Error ingesting data:", error);
    return NextResponse.json(
      { error: "Failed to ingest data" },
      { status: 500 }
    );
  }
}
```

## Client-Side Integration

### Example: Fetching Recommendations in a React Component

```tsx
// app/dashboard/recommendations/page.tsx
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RecommendationItem } from "@/components/recommendations/recommendation-item";

export default function RecommendationsPage() {
  const [recommendations, setRecommendations] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    fetchRecommendations();
  }, []);
  
  async function fetchRecommendations() {
    try {
      setLoading(true);
      const response = await fetch("/api/recommendations");
      
      if (!response.ok) {
        throw new Error(`Error fetching recommendations: ${response.statusText}`);
      }
      
      const data = await response.json();
      setRecommendations(data.recommendations);
      setError(null);
    } catch (err) {
      console.error("Failed to fetch recommendations:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }
  
  async function handleFeedback(recommendationId, feedbackType, details = {}) {
    try {
      const response = await fetch("/api/recommendations/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          recommendation_id: recommendationId,
          feedback_type: feedbackType,
          details
        }),
      });
      
      if (!response.ok) {
        throw new Error(`Error submitting feedback: ${response.statusText}`);
      }
      
      // Refresh recommendations after feedback
      fetchRecommendations();
    } catch (err) {
      console.error("Failed to submit feedback:", err);
      // Show error notification
    }
  }
  
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Mining Recommendations</h1>
      
      {loading ? (
        <p>Loading recommendations...</p>
      ) : error ? (
        <div className="bg-red-100 p-4 rounded-md">
          <p className="text-red-700">{error}</p>
          <Button onClick={fetchRecommendations} className="mt-2">Retry</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {Object.entries(recommendations).map(([type, typeRecommendations]) => (
            <Card key={type}>
              <CardHeader>
                <CardTitle>{formatRecommendationType(type)}</CardTitle>
              </CardHeader>
              <CardContent>
                {typeRecommendations.length > 0 ? (
                  typeRecommendations.map((recommendation) => (
                    <RecommendationItem
                      key={recommendation.id}
                      recommendation={recommendation}
                      onAccept={() => handleFeedback(recommendation.id, "accepted")}
                      onReject={() => handleFeedback(recommendation.id, "rejected")}
                      onImplement={() => handleFeedback(recommendation.id, "implemented")}
                    />
                  ))
                ) : (
                  <p>No {formatRecommendationType(type).toLowerCase()} recommendations at this time.</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function formatRecommendationType(type) {
  return type
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}
```
