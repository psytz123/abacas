
"""
Data ingestion for Abacus.AI integration.

This module provides functions for ingesting data from Vnish firmware and
Prohashing.com APIs into Abacus.AI feature stores.
"""

import logging
import time
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from api_clients.vnish_client import VnishClient
from api_clients.prohash_client import ProhashingClient
from feature_store_setup import FeatureStoreManager

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataIngestionManager:
    """
    Manager for ingesting data from API clients into Abacus.AI feature stores.
    """
    
    def __init__(
        self,
        feature_store_manager: FeatureStoreManager,
        vnish_clients: Dict[str, VnishClient],
        prohashing_client: ProhashingClient
    ):
        """
        Initialize the data ingestion manager.
        
        Args:
            feature_store_manager: Feature store manager instance
            vnish_clients: Dict mapping miner IDs to Vnish client instances
            prohashing_client: Prohashing client instance
        """
        self.feature_store_manager = feature_store_manager
        self.vnish_clients = vnish_clients
        self.prohashing_client = prohashing_client
    
    async def ingest_miner_telemetry(self) -> str:
        """
        Ingest miner telemetry data from Vnish clients.
        
        Returns:
            Upload job ID
        """
        logger.info(f"Ingesting telemetry data from {len(self.vnish_clients)} miners")
        
        telemetry_data = []
        
        # Collect telemetry data from all miners
        for miner_id, client in self.vnish_clients.items():
            try:
                telemetry = client.get_telemetry()
                telemetry_data.append(telemetry)
                logger.debug(f"Collected telemetry from miner {miner_id}")
            except Exception as e:
                logger.error(f"Error collecting telemetry from miner {miner_id}: {str(e)}")
        
        if not telemetry_data:
            logger.warning("No telemetry data collected")
            return None
        
        # Upload to feature store
        try:
            upload_job_id = self.feature_store_manager.upload_miner_telemetry_data(telemetry_data)
            logger.info(f"Uploaded {len(telemetry_data)} telemetry records with job ID: {upload_job_id}")
            return upload_job_id
        except Exception as e:
            logger.error(f"Error uploading telemetry data: {str(e)}")
            raise
    
    async def ingest_pool_performance(self) -> str:
        """
        Ingest pool performance data from Prohashing client.
        
        Returns:
            Upload job ID
        """
        logger.info("Ingesting pool performance data")
        
        pool_data = []
        
        # Get worker IDs from Vnish clients
        worker_ids = [client.miner_id for client in self.vnish_clients.values() if client.miner_id]
        
        # Collect pool performance data for all workers
        for worker_id in worker_ids:
            try:
                performance = self.prohashing_client.get_worker_pool_performance(worker_id)
                pool_data.append(performance)
                logger.debug(f"Collected pool performance for worker {worker_id}")
            except Exception as e:
                logger.error(f"Error collecting pool performance for worker {worker_id}: {str(e)}")
        
        if not pool_data:
            logger.warning("No pool performance data collected")
            return None
        
        # Upload to feature store
        try:
            upload_job_id = self.feature_store_manager.upload_pool_performance_data(pool_data)
            logger.info(f"Uploaded {len(pool_data)} pool performance records with job ID: {upload_job_id}")
            return upload_job_id
        except Exception as e:
            logger.error(f"Error uploading pool performance data: {str(e)}")
            raise
    
    async def ingest_market_data(self) -> str:
        """
        Ingest cryptocurrency market data.
        
        Returns:
            Upload job ID
        """
        logger.info("Ingesting market data")
        
        # Get algorithm profitability data
        try:
            algorithm_data = self.prohashing_client.get_all_algorithm_profitability()
            logger.debug(f"Collected profitability data for {len(algorithm_data)} algorithms")
            
            # Transform to market data format
            market_data = self._transform_to_market_data(algorithm_data)
            
            # Upload to feature store
            upload_job_id = self.feature_store_manager.upload_market_data(market_data)
            logger.info(f"Uploaded {len(market_data)} market data records with job ID: {upload_job_id}")
            return upload_job_id
        except Exception as e:
            logger.error(f"Error ingesting market data: {str(e)}")
            raise
    
    async def ingest_derived_metrics(self) -> str:
        """
        Calculate and ingest derived mining metrics.
        
        Returns:
            Upload job ID
        """
        logger.info("Calculating and ingesting derived metrics")
        
        # Get miner IDs
        miner_ids = [client.miner_id for client in self.vnish_clients.values() if client.miner_id]
        
        # Get online features for calculation
        try:
            miner_features = self.feature_store_manager.get_online_features("miner_telemetry", miner_ids)
            pool_features = self.feature_store_manager.get_online_features("pool_performance", miner_ids)
            
            # Calculate derived metrics
            derived_metrics = self._calculate_derived_metrics(miner_ids, miner_features, pool_features)
            
            # Upload to feature store
            upload_job_id = self.feature_store_manager.upload_derived_metrics(derived_metrics)
            logger.info(f"Uploaded {len(derived_metrics)} derived metrics records with job ID: {upload_job_id}")
            return upload_job_id
        except Exception as e:
            logger.error(f"Error ingesting derived metrics: {str(e)}")
            raise
    
    async def run_ingestion_cycle(self):
        """
        Run a complete data ingestion cycle.
        """
        logger.info("Starting data ingestion cycle")
        
        # Ingest miner telemetry
        telemetry_job_id = await self.ingest_miner_telemetry()
        
        # Ingest pool performance
        pool_job_id = await self.ingest_pool_performance()
        
        # Ingest market data
        market_job_id = await self.ingest_market_data()
        
        # Ingest derived metrics
        derived_job_id = await self.ingest_derived_metrics()
        
        logger.info("Data ingestion cycle completed")
        
        return {
            "telemetry_job_id": telemetry_job_id,
            "pool_job_id": pool_job_id,
            "market_job_id": market_job_id,
            "derived_job_id": derived_job_id
        }
    
    def _transform_to_market_data(self, algorithm_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Transform algorithm profitability data to market data format.
        
        Args:
            algorithm_data: List of algorithm profitability data
        
        Returns:
            List of market data records
        """
        market_data = []
        timestamp = int(time.time())
        
        # Map of algorithm names to coin IDs
        algorithm_to_coin = {
            "SHA-256": "btc",
            "Scrypt": "ltc",
            "X11": "dash",
            "Ethash": "eth",
            "Equihash": "zec"
        }
        
        for algorithm in algorithm_data:
            coin_id = algorithm_to_coin.get(algorithm["algorithm"], f"unknown_{algorithm['algorithm'].lower()}")
            
            market_record = {
                "coin_id": coin_id,
                "timestamp": timestamp,
                "symbol": coin_id.upper(),
                "price_usd": 0.0,  # Would be fetched from a price API in a real implementation
                "price_btc": algorithm["profitability"]["current_btc"],
                "market_cap_usd": 0.0,  # Would be fetched from a market data API
                "volume_24h_usd": 0.0,  # Would be fetched from a market data API
                "price_change_24h_percent": 0.0,  # Would be calculated from historical data
                "price_change_7d_percent": 0.0,  # Would be calculated from historical data
                "network_hashrate": 0.0,  # Would be fetched from a network stats API
                "network_difficulty": 0.0,  # Would be fetched from a network stats API
                "block_reward_usd": algorithm["profitability"]["current_usd"],
                "transaction_fees_percent": 0.0,  # Would be calculated from network data
                "volatility_30d": 0.0,  # Would be calculated from historical data
                "halving_countdown_days": 0.0  # Would be calculated from network data
            }
            
            market_data.append(market_record)
        
        return market_data
    
    def _calculate_derived_metrics(
        self,
        miner_ids: List[str],
        miner_features: Dict[str, Any],
        pool_features: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Calculate derived mining metrics.
        
        Args:
            miner_ids: List of miner IDs
            miner_features: Miner telemetry features
            pool_features: Pool performance features
        
        Returns:
            List of derived metrics records
        """
        derived_metrics = []
        timestamp = int(time.time())
        
        for miner_id in miner_ids:
            # Extract features for this miner
            miner_feature = miner_features.get(miner_id, {})
            pool_feature = pool_features.get(miner_id, {})
            
            if not miner_feature or not pool_feature:
                logger.warning(f"Missing features for miner {miner_id}")
                continue
            
            # Calculate derived metrics
            power_consumption = miner_feature.get("power_consumption_w", 0.0)
            hashrate = miner_feature.get("hashrate_th_s", 0.0)
            earnings = pool_feature.get("earnings_amount", 0.0)
            
            # Placeholder calculations - would be more sophisticated in a real implementation
            profit_margin = 0.0
            if power_consumption > 0 and earnings > 0:
                # Assuming $0.10 per kWh electricity cost
                electricity_cost = power_consumption * 24 / 1000 * 0.1
                profit_margin = (earnings - electricity_cost) / earnings * 100 if earnings > 0 else 0.0
            
            roi_days = 0.0
            if earnings > 0:
                # Assuming $10,000 hardware cost
                hardware_cost = 10000
                daily_profit = earnings - (power_consumption * 24 / 1000 * 0.1)
                roi_days = hardware_cost / daily_profit if daily_profit > 0 else 0.0
            
            optimal_power = 0.0
            if power_consumption > 0 and hashrate > 0:
                # Simple heuristic - 90% of current power often improves efficiency
                optimal_power = power_consumption * 0.9
            
            derived_record = {
                "miner_id": miner_id,
                "timestamp": timestamp,
                "actual_profit_margin_percent": profit_margin,
                "roi_current_hardware_days": roi_days,
                "optimal_power_limit_w": optimal_power,
                "power_cost_per_dollar_earned": (power_consumption * 24 / 1000 * 0.1) / earnings if earnings > 0 else 0.0,
                "hardware_upgrade_benefit_score": 0.5,  # Placeholder
                "maintenance_urgency_score": 0.2,  # Placeholder
                "thermal_risk_score": 0.3,  # Placeholder
                "efficiency_vs_market_percentile": 0.6,  # Placeholder
                "optimal_coin_allocation": "BTC:80,LTC:20",  # Placeholder
                "predicted_24h_profit_change": 0.0,  # Placeholder
                "hardware_failure_probability": 0.05,  # Placeholder
                "opportunity_cost_current_strategy": 0.0,  # Placeholder
                "market_based_power_adjustment": 0.0  # Placeholder
            }
            
            derived_metrics.append(derived_record)
        
        return derived_metrics

async def run_data_ingestion(
    vnish_configs: List[Dict[str, Any]],
    prohashing_api_key: str,
    ingestion_interval_minutes: int = 15
):
    """
    Run continuous data ingestion.
    
    Args:
        vnish_configs: List of Vnish client configurations
        prohashing_api_key: Prohashing API key
        ingestion_interval_minutes: Interval between ingestion cycles in minutes
    """
    # Initialize feature store manager
    feature_store_manager = FeatureStoreManager()
    feature_group_ids = feature_store_manager.create_feature_stores()
    deployment_ids = feature_store_manager.deploy_feature_stores()
    
    # Initialize Vnish clients
    vnish_clients = {}
    for config in vnish_configs:
        client = VnishClient(
            miner_ip=config["miner_ip"],
            username=config["username"],
            password=config["password"]
        )
        vnish_clients[config["miner_id"]] = client
    
    # Initialize Prohashing client
    prohashing_client = ProhashingClient(api_key=prohashing_api_key)
    
    # Initialize data ingestion manager
    ingestion_manager = DataIngestionManager(
        feature_store_manager=feature_store_manager,
        vnish_clients=vnish_clients,
        prohashing_client=prohashing_client
    )
    
    # Run continuous ingestion
    while True:
        try:
            await ingestion_manager.run_ingestion_cycle()
        except Exception as e:
            logger.error(f"Error in ingestion cycle: {str(e)}")
        
        # Wait for next cycle
        logger.info(f"Waiting {ingestion_interval_minutes} minutes until next ingestion cycle")
        await asyncio.sleep(ingestion_interval_minutes * 60)

if __name__ == "__main__":
    # Example configuration
    vnish_configs = [
        {
            "miner_id": "miner_001",
            "miner_ip": "192.168.1.101",
            "username": "admin",
            "password": "password"
        },
        {
            "miner_id": "miner_002",
            "miner_ip": "192.168.1.102",
            "username": "admin",
            "password": "password"
        }
    ]
    
    prohashing_api_key = "your_prohashing_api_key"
    
    # Run data ingestion
    asyncio.run(run_data_ingestion(vnish_configs, prohashing_api_key))
