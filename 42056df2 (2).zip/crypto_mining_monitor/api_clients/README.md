
# Cryptocurrency Mining API Clients

This package provides API clients for interacting with Vnish firmware and Prohashing.com to fetch mining telemetry data, pool performance, and profitability metrics.

## Overview

The API clients in this package are designed to:

1. Fetch data from Vnish firmware and Prohashing.com APIs
2. Transform the data into a consistent format that matches the expected schema
3. Handle authentication, rate limiting, error handling, and data validation
4. Provide a simple interface for integrating with the cryptocurrency mining monitoring system

## Installation

The API clients require the following Python packages:

- `requests`: For making HTTP requests
- `pydantic`: For data validation and transformation
- `tenacity`: For retry logic

These dependencies should already be installed in the environment.

## Usage

### Vnish Firmware API Client

The `VnishClient` provides methods for fetching telemetry data from ASIC miners running Vnish firmware.

```python
from api_clients import VnishClient

# Initialize the client
client = VnishClient(
    miner_ip="192.168.1.100",
    username="admin",
    password="password"
)

# Fetch telemetry data
telemetry = client.get_telemetry()

# Access specific metrics
hashrate = telemetry["hashrate"]["total"]
temperature = telemetry["temperature"]["avg_chip"]
power = telemetry["power"]["consumption"]
```

### Prohashing API Client

The `ProhashingClient` provides methods for fetching mining pool data, profitability metrics, and worker performance from Prohashing.com.

```python
from api_clients import ProhashingClient

# Initialize the client
client = ProhashingClient(api_key="your_api_key")

# Fetch profitability data for all algorithms
profitability = client.get_all_algorithm_profitability()

# Fetch worker performance data
worker_performance = client.get_worker_pool_performance(
    worker_id="your_worker_id",
    algorithm="Scrypt"
)
```

## Example Scripts

The `examples` directory contains example scripts that demonstrate how to use the API clients:

- `fetch_vnish.py`: Fetches telemetry data from a Vnish firmware miner
- `fetch_prohash.py`: Fetches profitability data and worker performance from Prohashing.com

### Running the Example Scripts

```bash
# Fetch data from a Vnish firmware miner
python examples/fetch_vnish.py --ip 192.168.1.100 --username admin --password password --output miner_data.json

# Fetch profitability data from Prohashing.com
python examples/fetch_prohash.py --api-key your_api_key --type profitability --output profitability_data.json

# Fetch worker performance data from Prohashing.com
python examples/fetch_prohash.py --api-key your_api_key --worker-id your_worker_id --algorithm Scrypt --type worker --output worker_data.json
```

## Data Schemas

The API clients use Pydantic models to validate and transform data. The transformed data matches the expected schema as defined in the data pipeline design.

### Miner Telemetry Schema

The `VnishMinerTelemetry` model transforms data into the following schema:

```json
{
  "timestamp": 1621234567,
  "miner_id": "ANTMINER_S19_001",
  "ip_address": "192.168.1.100",
  "model": "ANTMINER_S19",
  "firmware_version": "Vnish Firmware",
  "hashrate": {
    "total": 95.5,
    "unit": "TH/s",
    "per_hashboard": [
      {
        "board_id": 1,
        "hashrate": 31.8,
        "status": "active"
      },
      ...
    ]
  },
  "temperature": {
    "ambient": 25.0,
    "avg_chip": 65.0,
    "max_chip": 68.0,
    "per_hashboard": [
      {
        "board_id": 1,
        "pcb_temp": 65.0,
        "chip_temp": 67.0
      },
      ...
    ]
  },
  "power": {
    "consumption": 3400.0,
    "efficiency": 35.6,
    "voltage": 12.0
  },
  "fans": [
    {
      "fan_id": 1,
      "speed": 4800.0,
      "speed_percent": 80.0,
      "status": "active"
    },
    ...
  ],
  "pool": {
    "url": "stratum+tcp://pool.example.com:3333",
    "user": "worker1",
    "status": "connected"
  },
  "shares": {
    "accepted": 12450,
    "rejected": 23,
    "stale": 0,
    "last_share_time": 1621234560
  },
  "status": {
    "mining_status": "mining",
    "uptime": 259200,
    "errors": []
  },
  "config": {
    "frequency": 900.0,
    "overclock_profile": "efficiency",
    "power_limit": 3500.0
  }
}
```

### Mining Pool Schema

The `ProhashingPoolPerformance` model transforms data into the following schema:

```json
{
  "timestamp": 1621234567,
  "pool_id": "prohashing",
  "worker_id": "worker1",
  "algorithm": "Scrypt",
  "hashrate": {
    "reported": 100.0,
    "effective": 95.5,
    "unit": "MH/s"
  },
  "shares": {
    "accepted": 12450,
    "rejected": 23,
    "stale": 0,
    "last_share_time": 1621234560
  },
  "earnings": {
    "amount": 0.05,
    "currency": "USD",
    "time_period": "24h"
  },
  "coins_mined": [
    {
      "coin_id": "ltc",
      "symbol": "LTC",
      "amount": 0.01,
      "usd_value": 0.03,
      "mining_type": "primary"
    },
    {
      "coin_id": "doge",
      "symbol": "DOGE",
      "amount": 5.0,
      "usd_value": 0.02,
      "mining_type": "merge-mined"
    }
  ],
  "profitability": {
    "per_hash_rate": 0.0025,
    "unit": "USD/TH/day",
    "time_period": "24h"
  },
  "difficulty": 12345.67,
  "status": "active"
}
```

## Error Handling

The API clients include comprehensive error handling:

- Automatic retries for transient errors using exponential backoff
- Validation of API responses to ensure data integrity
- Detailed error messages for debugging
- Logging of all API interactions

## Rate Limiting

The API clients implement rate limiting compliance:

- Configurable retry logic with exponential backoff
- Automatic handling of rate limit responses (HTTP 429)
- Session management to minimize connection overhead

## Authentication

The API clients handle authentication securely:

- Vnish Firmware: Basic HTTP authentication
- Prohashing.com: API key-based authentication

## License

This package is part of the cryptocurrency mining monitoring system and is subject to the same license terms.
