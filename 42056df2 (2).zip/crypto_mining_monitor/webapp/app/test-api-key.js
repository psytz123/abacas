// Simple test script for API key generation and validation
const crypto = require('crypto');

// Copy of the functions from lib/api-key.ts
function generateApiKey() {
  // Generate a 32-byte random key and encode it as hex
  const randomBytes = crypto.randomBytes(32);
  const timestamp = Date.now().toString(36);
  
  // Format: mk_<timestamp>_<random_hex>
  return `mk_${timestamp}_${randomBytes.toString('hex')}`;
}

function validateApiKeyFormat(apiKey) {
  // API key format: mk_<timestamp>_<64_char_hex>
  if (!apiKey || typeof apiKey !== 'string') {
    return false;
  }
  const apiKeyRegex = /^mk_[a-z0-9]+_[a-f0-9]{64}$/i;
  return apiKeyRegex.test(apiKey);
}

function parseApiKey(apiKey) {
  if (!validateApiKeyFormat(apiKey)) {
    return null;
  }
  
  const parts = apiKey.split('_');
  if (parts.length !== 3) {
    return null;
  }
  
  return {
    prefix: parts[0],    // Should be 'mk'
    timestamp: parts[1], // Base36 timestamp
    key: parts[2]        // 64-character hex string
  };
}

// Test API key generation
console.log('Testing API key generation and validation...');

// Generate 5 API keys and validate them
for (let i = 0; i < 5; i++) {
  const apiKey = generateApiKey();
  const isValid = validateApiKeyFormat(apiKey);
  const parsed = parseApiKey(apiKey);
  
  console.log(`\nAPI Key ${i + 1}: ${apiKey}`);
  console.log(`Valid format: ${isValid}`);
  console.log('Parsed components:', parsed);
  
  // Verify key length
  console.log(`Total length: ${apiKey.length}`);
  console.log(`Hex part length: ${parsed?.key.length}`);
  
  // Verify parts
  if (parsed) {
    console.log(`Prefix: ${parsed.prefix === 'mk' ? 'Correct ✓' : 'Incorrect ✗'}`);
    console.log(`Timestamp: ${parsed.timestamp.length > 0 ? 'Present ✓' : 'Missing ✗'}`);
    console.log(`Hex key: ${parsed.key.length === 64 ? 'Correct length ✓' : 'Incorrect length ✗'}`);
  }
}

// Test invalid API keys
console.log('\n\nTesting invalid API keys:');
const invalidKeys = [
  '',
  'invalid',
  'mk_timestamp_tooshort',
  'xx_timestamp_' + '0'.repeat(64),
  'mk_' + 'toolong_' + '0'.repeat(65),
  'mk_no_underscore',
  'mk__' + '0'.repeat(64)
];

for (const key of invalidKeys) {
  try {
    const isValid = validateApiKeyFormat(key);
    console.log(`Key: ${key} - Valid: ${isValid}`);
  } catch (error) {
    console.log(`Key: ${key} - Error: ${error?.message || 'Unknown error'}`);
  }
}

console.log('\nAPI key testing complete!');
