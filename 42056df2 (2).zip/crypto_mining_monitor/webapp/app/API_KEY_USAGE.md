# API Key System Documentation

This document provides information about the API key system in the cryptocurrency mining monitoring application.

## API Key Format

API keys follow this format: `mk_<timestamp>_<64_char_hex>`

Example: `mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012`

Where:
- `mk_` is the prefix indicating a mining key
- `<timestamp>` is a base36-encoded timestamp (e.g., `mb615v23`)
- `<64_char_hex>` is a 64-character hexadecimal string generated from 32 random bytes

## API Endpoints

### Create API Key

```
POST /api/api-keys
```

**Headers:**
- `Content-Type: application/json`
- `Authorization: Bearer <jwt_token>`

**Request Body:**
```json
{
  "name": "My API Key"
}
```

**Response:**
```json
{
  "id": "cuid123456",
  "key": "mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012",
  "name": "My API Key",
  "userId": "user123",
  "active": true,
  "createdAt": "2025-05-27T12:34:56.789Z",
  "updatedAt": "2025-05-27T12:34:56.789Z"
}
```

### Validate API Key

```
POST /api/api-keys/validate
```

**Headers:**
- `Content-Type: application/json`

**Request Body:**
```json
{
  "apiKey": "mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012"
}
```

**Success Response:**
```json
{
  "valid": true,
  "apiKey": {
    "id": "cuid123456",
    "name": "My API Key",
    "userId": "user123",
    "lastUsed": "2025-05-27T12:34:56.789Z"
  }
}
```

**Error Response (Invalid Format):**
```json
{
  "error": "Wrong apikey format. Expected format: mk_<timestamp>_<64_char_hex>",
  "valid": false,
  "details": {
    "expected": "mk_<timestamp>_<64_char_hex>",
    "received": "invalid-key",
    "length": 11
  }
}
```

**Error Response (Not Found):**
```json
{
  "error": "API key not found",
  "valid": false
}
```

### Get All API Keys

```
GET /api/api-keys
```

**Headers:**
- `Authorization: Bearer <jwt_token>`

**Response:**
```json
[
  {
    "id": "cuid123456",
    "key": "mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012",
    "name": "My API Key",
    "userId": "user123",
    "active": true,
    "lastUsed": "2025-05-27T12:34:56.789Z",
    "createdAt": "2025-05-27T12:34:56.789Z",
    "updatedAt": "2025-05-27T12:34:56.789Z"
  },
  // More API keys...
]
```

## Testing the API Key System

1. Start the development server:
   ```
   npm run dev
   ```

2. Run the API key test script:
   ```
   node scripts/api-key-test-endpoints.js
   ```
   
   Note: You'll need to update the `TEST_USER_TOKEN` in the script with a valid JWT token.

## API Key Utility Functions

The application provides several utility functions for working with API keys:

### Generate API Key

```typescript
import { generateApiKey } from '@/lib/api-key';

const apiKey = generateApiKey();
console.log(apiKey); // mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012
```

### Validate API Key Format

```typescript
import { validateApiKeyFormat } from '@/lib/api-key';

const isValid = validateApiKeyFormat('mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012');
console.log(isValid); // true

const isInvalid = validateApiKeyFormat('invalid-key');
console.log(isInvalid); // false
```

### Parse API Key

```typescript
import { parseApiKey } from '@/lib/api-key';

const parsed = parseApiKey('mk_mb615v23_c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012');
console.log(parsed);
// {
//   prefix: 'mk',
//   timestamp: 'mb615v23',
//   key: 'c063e4a2649efef78c0357ce42fa0ba5f26b5531d03ceb91f9a13defd0441012'
// }
```

## Security Considerations

- API keys should be treated as sensitive information and not exposed in client-side code
- Use HTTPS for all API requests to prevent key interception
- Implement rate limiting to prevent abuse
- Consider implementing key rotation policies for enhanced security
