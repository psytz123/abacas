
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyToken } from './lib/auth'

// Paths that require authentication
const PROTECTED_PATHS = [
  '/dashboard',
  '/api/miners',
  '/api/workers',
  '/api/api-keys',
  '/api/recommendations',
  '/api/mining-stats',
  '/api/pool'
]

// Paths that are exempt from authentication
const PUBLIC_PATHS = [
  '/api/auth/login',
  '/api/auth/register',
  '/api/auth/logout',
  '/api/auth/refresh',
  '/',
  '/login',
  '/register',
  '/favicon.ico',
  '/_next'
]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Check if the path is public
  if (PUBLIC_PATHS.some(path => pathname.startsWith(path))) {
    return NextResponse.next()
  }

  // Check if the path requires authentication
  if (PROTECTED_PATHS.some(path => pathname.startsWith(path))) {
    // Get the token from cookies
    const token = request.cookies.get('auth-token')?.value

    // If no token, redirect to login
    if (!token) {
      const url = new URL('/login', request.url)
      url.searchParams.set('from', pathname)
      return NextResponse.redirect(url)
    }

    // Verify the token
    const decoded = verifyToken(token)
    if (!decoded) {
      // Token is invalid, redirect to login
      const url = new URL('/login', request.url)
      url.searchParams.set('from', pathname)
      return NextResponse.redirect(url)
    }

    // Token is valid, continue
    return NextResponse.next()
  }

  // For all other paths, continue
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}
