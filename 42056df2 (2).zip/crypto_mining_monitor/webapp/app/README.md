# CryptoMiner Pro - Mining Monitoring System

A professional cryptocurrency mining monitoring and management platform built with Next.js 14, React 18, and Prisma.

## Features

- **Real-time Mining Monitoring**: Track hash rates, power consumption, temperature, and uptime
- **API Key Management**: Generate, validate, and manage API keys with proper format validation
- **User Authentication**: Secure login and registration system
- **Mining Rig Management**: Add and monitor multiple mining rigs
- **Dashboard Analytics**: Comprehensive overview of mining operations
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Dark/Light Mode**: Theme switching with system preference support

## API Key Format

The system uses a specific API key format for validation:
- Format: `mk_<timestamp>_<64_char_hex>`
- Example: `mk_abc123_1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef`

## Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd cryptominer-pro
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Create a `.env` file in the root directory:
```env
DATABASE_URL="postgresql://username:password@localhost:5432/cryptominer"
JWT_SECRET="your-secret-key-here"
```

4. Set up the database:
```bash
npx prisma generate
npx prisma db push
```

5. Run the development server:
```bash
npm run dev
```

6. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Usage

### Getting Started
1. Create an account or sign in on the homepage
2. Access the dashboard to view mining statistics
3. Generate API keys for external integrations
4. Add mining rigs to monitor their performance

### API Key Management
- Create new API keys with custom names
- Test API key format validation
- View usage statistics and last used timestamps
- Delete unused API keys

### Mining Monitoring
- Add mining rigs to track their performance
- Monitor real-time hash rates, power consumption, and temperature
- View uptime statistics and operational status

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login

### API Keys
- `GET /api/api-keys` - List user's API keys
- `POST /api/api-keys` - Create new API key
- `DELETE /api/api-keys/[id]` - Delete API key
- `PATCH /api/api-keys/[id]` - Update API key status
- `POST /api/api-keys/validate` - Validate API key format

### Mining
- `GET /api/miners` - List user's miners
- `POST /api/miners` - Add new miner
- `GET /api/mining-stats` - Get mining statistics

## Technology Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS, Framer Motion
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: JWT tokens
- **UI Components**: Radix UI, Lucide React icons

## Project Structure

```
├── app/
│   ├── api/           # API routes
│   ├── dashboard/     # Dashboard page
│   ├── globals.css    # Global styles
│   ├── layout.tsx     # Root layout
│   └── page.tsx       # Homepage
├── components/
│   └── ui/            # Reusable UI components
├── lib/
│   ├── auth.ts        # Authentication utilities
│   ├── api-key.ts     # API key generation and validation
│   ├── prisma.ts      # Prisma client
│   └── utils.ts       # Utility functions
├── prisma/
│   └── schema.prisma  # Database schema
└── README.md
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.