
'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  email: string
  name?: string
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [csrfToken, setCsrfToken] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
    
    // Set up token refresh interval
    const refreshInterval = setInterval(refreshToken, 1000 * 60 * 60) // Refresh every hour
    
    return () => clearInterval(refreshInterval)
  }, [])

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/me')
      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        setCsrfToken(data.csrfToken)
      } else {
        setUser(null)
        setCsrfToken(null)
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      setUser(null)
      setCsrfToken(null)
    } finally {
      setLoading(false)
    }
  }

  const refreshToken = async () => {
    try {
      const response = await fetch('/api/auth/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      })
      
      if (!response.ok) {
        // If refresh fails, log out the user
        setUser(null)
        setCsrfToken(null)
        router.push('/login')
      }
    } catch (error) {
      console.error('Token refresh failed:', error)
    }
  }

  const login = async (email: string, password: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (response.ok) {
        setUser(data.user)
        setCsrfToken(data.csrfToken)
        router.push('/dashboard')
        return { success: true }
      } else {
        return { success: false, error: data.error }
      }
    } catch (error) {
      console.error('Login failed:', error)
      return { success: false, error: 'Login failed. Please try again.' }
    }
  }

  const register = async (email: string, password: string, name?: string) => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, name }),
      })

      const data = await response.json()

      if (response.ok) {
        setUser(data.user)
        setCsrfToken(data.csrfToken)
        router.push('/dashboard')
        return { success: true }
      } else {
        return { success: false, error: data.error }
      }
    } catch (error) {
      console.error('Registration failed:', error)
      return { success: false, error: 'Registration failed. Please try again.' }
    }
  }

  const logout = async () => {
    try {
      // Include CSRF token in the request header
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      }
      
      if (csrfToken) {
        headers['X-CSRF-Token'] = csrfToken
      }
      
      await fetch('/api/auth/logout', { 
        method: 'POST',
        headers
      })
      
      setUser(null)
      setCsrfToken(null)
      router.push('/')
    } catch (error) {
      console.error('Logout failed:', error)
    }
  }

  return {
    user,
    loading,
    login,
    register,
    logout,
    checkAuth,
    csrfToken
  }
}
