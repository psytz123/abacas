'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Server, 
  Activity, 
  Thermometer, 
  Zap, 
  Clock, 
  Edit, 
  Trash2, 
  Wifi, 
  WifiOff,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'react-hot-toast';

interface Worker {
  id: string;
  name: string;
  ipAddress: string;
  port: number;
  status: string;
  hashrate: number;
  temperature: number;
  power: number;
  uptime: number;
  createdAt: string;
}

export function WorkersTab() {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    ipAddress: '',
    port: '4028'
  });

  useEffect(() => {
    fetchWorkers();
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(fetchWorkers, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchWorkers = async () => {
    try {
      const response = await fetch('/api/workers');
      if (response.ok) {
        const workersData = await response.json();
        setWorkers(workersData);
      }
    } catch (error) {
      console.error('Error fetching workers:', error);
      toast.error('Failed to fetch workers');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      ipAddress: '',
      port: '4028'
    });
  };

  const handleAddWorker = async () => {
    if (!formData.name.trim() || !formData.ipAddress.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/workers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          ipAddress: formData.ipAddress.trim(),
          port: parseInt(formData.port) || 4028
        }),
      });

      if (response.ok) {
        const newWorker = await response.json();
        setWorkers([newWorker, ...workers]);
        setIsAddDialogOpen(false);
        resetForm();
        toast.success('Worker added successfully');
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to add worker');
      }
    } catch (error) {
      console.error('Error adding worker:', error);
      toast.error('Failed to add worker');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditWorker = async () => {
    if (!editingWorker || !formData.name.trim() || !formData.ipAddress.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/workers/${editingWorker.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          ipAddress: formData.ipAddress.trim(),
          port: parseInt(formData.port) || 4028
        }),
      });

      if (response.ok) {
        const updatedWorker = await response.json();
        setWorkers(workers.map(w => w.id === editingWorker.id ? updatedWorker : w));
        setIsEditDialogOpen(false);
        setEditingWorker(null);
        resetForm();
        toast.success('Worker updated successfully');
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to update worker');
      }
    } catch (error) {
      console.error('Error updating worker:', error);
      toast.error('Failed to update worker');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteWorker = async (id: string) => {
    if (!confirm('Are you sure you want to delete this worker?')) {
      return;
    }

    try {
      const response = await fetch(`/api/workers?id=${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setWorkers(workers.filter(w => w.id !== id));
        toast.success('Worker deleted successfully');
      } else {
        toast.error('Failed to delete worker');
      }
    } catch (error) {
      console.error('Error deleting worker:', error);
      toast.error('Failed to delete worker');
    }
  };

  const openEditDialog = (worker: Worker) => {
    setEditingWorker(worker);
    setFormData({
      name: worker.name,
      ipAddress: worker.ipAddress,
      port: worker.port.toString()
    });
    setIsEditDialogOpen(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <Wifi className="h-4 w-4 text-green-500" />;
      case 'offline':
        return <WifiOff className="h-4 w-4 text-red-500" />;
      case 'connecting':
        return <Activity className="h-4 w-4 text-yellow-500 animate-pulse" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'offline':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'connecting':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const formatHashrate = (hashrate: number) => {
    if (hashrate >= 1000) {
      return `${(hashrate / 1000).toFixed(1)} TH/s`;
    }
    return `${hashrate.toFixed(1)} GH/s`;
  };

  const formatUptime = (uptime: number) => {
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      {/* Header with Add Worker Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Mining Workers</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Monitor and manage your cryptocurrency mining workers
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Worker
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Worker</DialogTitle>
              <DialogDescription>
                Add a new mining worker to monitor its performance and status.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="workerName">Worker Name</Label>
                <Input
                  id="workerName"
                  placeholder="e.g., Antminer S19 Pro #1"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="ipAddress">IP Address</Label>
                <Input
                  id="ipAddress"
                  placeholder="e.g., 192.168.1.100"
                  value={formData.ipAddress}
                  onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="port">Port</Label>
                <Input
                  id="port"
                  type="number"
                  placeholder="4028"
                  value={formData.port}
                  onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleAddWorker}
                  disabled={isLoading}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isLoading ? 'Adding...' : 'Add Worker'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Worker Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Worker</DialogTitle>
            <DialogDescription>
              Update the worker configuration and settings.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editWorkerName">Worker Name</Label>
              <Input
                id="editWorkerName"
                placeholder="e.g., Antminer S19 Pro #1"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="editIpAddress">IP Address</Label>
              <Input
                id="editIpAddress"
                placeholder="e.g., 192.168.1.100"
                value={formData.ipAddress}
                onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="editPort">Port</Label>
              <Input
                id="editPort"
                type="number"
                placeholder="4028"
                value={formData.port}
                onChange={(e) => setFormData({ ...formData, port: e.target.value })}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setEditingWorker(null);
                  resetForm();
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleEditWorker}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isLoading ? 'Updating...' : 'Update Worker'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Workers Grid */}
      {workers.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-12"
        >
          <Server className="h-16 w-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No Workers Added
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Add your first mining worker to start monitoring its performance
          </p>
          <Button
            onClick={() => setIsAddDialogOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Your First Worker
          </Button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workers.map((worker, index) => (
            <motion.div
              key={worker.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border-gray-200/50 dark:border-gray-700/50 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Server className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      <CardTitle className="text-lg">{worker.name}</CardTitle>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(worker)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteWorker(worker.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(worker.status)}>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(worker.status)}
                        {worker.status}
                      </div>
                    </Badge>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {worker.ipAddress}:{worker.port}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4 text-green-600 dark:text-green-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Hashrate</p>
                        <p className="font-semibold text-gray-900 dark:text-white">
                          {formatHashrate(worker.hashrate)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Thermometer className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Temperature</p>
                        <p className="font-semibold text-gray-900 dark:text-white">
                          {worker.temperature.toFixed(1)}°C
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Power</p>
                        <p className="font-semibold text-gray-900 dark:text-white">
                          {worker.power.toFixed(0)}W
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Uptime</p>
                        <p className="font-semibold text-gray-900 dark:text-white">
                          {formatUptime(worker.uptime)}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}