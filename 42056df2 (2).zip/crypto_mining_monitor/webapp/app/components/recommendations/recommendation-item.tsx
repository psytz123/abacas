'use client'

import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { CheckCircle, X, Clock, AlertTriangle } from 'lucide-react'

interface RecommendationItemProps {
  recommendation: {
    id: string
    title: string
    description: string
    urgency: 'low' | 'medium' | 'high'
    category: string
    status: 'pending' | 'accepted' | 'rejected' | 'implemented'
    impact: string
    created_at: string
  }
  onAccept?: (id: string) => void
  onReject?: (id: string) => void
  onImplement?: (id: string) => void
}

export default function RecommendationItem({ 
  recommendation, 
  onAccept, 
  onReject, 
  onImplement 
}: RecommendationItemProps) {
  
  const getUrgencyIcon = () => {
    switch (recommendation.urgency) {
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-red-400" />
      case 'medium':
        return <Clock className="h-4 w-4 text-yellow-400" />
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-400" />
      default:
        return <Clock className="h-4 w-4 text-blue-400" />
    }
  }

  const getUrgencyColor = () => {
    switch (recommendation.urgency) {
      case 'high':
        return 'border-red-500/30 bg-red-500/10'
      case 'medium':
        return 'border-yellow-500/30 bg-yellow-500/10'
      case 'low':
        return 'border-green-500/30 bg-green-500/10'
      default:
        return 'border-blue-500/30 bg-blue-500/10'
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "accepted":
        return <Badge variant="secondary">Accepted</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "implemented":
        return <Badge variant="secondary">Implemented</Badge>;
      case "pending":
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const getCategoryBadge = (category: string) => {
    return <Badge variant="outline">{category}</Badge>
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      className="w-full"
    >
      <Card className={`bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 ${getUrgencyColor()}`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3">
              {getUrgencyIcon()}
              <div>
                <CardTitle className="text-white text-lg">{recommendation.title}</CardTitle>
                <div className="flex items-center space-x-2 mt-1">
                  {getCategoryBadge(recommendation.category)}
                  {getStatusBadge(recommendation.status)}
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-white/70 mb-4">
            {recommendation.description}
          </CardDescription>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-white/60 text-sm">Impact:</span>
                <span className="text-white text-sm font-medium">{recommendation.impact}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/60 text-sm">Created:</span>
                <span className="text-white text-sm">
                  {new Date(recommendation.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-white/60 text-sm">Category:</span>
                <span className="text-white text-sm font-medium">{recommendation.category}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">Urgency:</span>
                  <Badge 
                    variant="secondary"
                  >
                    {recommendation.urgency}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {recommendation.status === 'pending' && (
            <div className="flex flex-wrap gap-2">
              {onAccept && (
                <Button
                  onClick={() => onAccept(recommendation.id)}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Accept
                </Button>
              )}
              {onReject && (
                <Button
                  onClick={() => onReject(recommendation.id)}
                  variant="destructive"
                  size="sm"
                >
                  <X className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              )}
            </div>
          )}

          {recommendation.status === 'accepted' && onImplement && (
            <Button
              onClick={() => onImplement(recommendation.id)}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              Mark as Implemented
            </Button>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}