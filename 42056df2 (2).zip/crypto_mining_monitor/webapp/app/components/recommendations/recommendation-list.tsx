'use client'

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RecommendationItem from "@/components/recommendations/recommendation-item";
import { AlertCircle, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  urgency: 'low' | 'medium' | 'high';
  category: string;
  status: 'pending' | 'accepted' | 'rejected' | 'implemented';
  impact: string;
  created_at: string;
}

const mockRecommendations: Recommendation[] = [
  {
    id: '1',
    title: 'Optimize GPU Memory Clock',
    description: 'Increase memory clock speed by 200MHz to improve hash rate by approximately 5-8%',
    urgency: 'medium',
    category: 'Performance',
    status: 'pending',
    impact: '+7% hash rate',
    created_at: '2024-01-15T10:30:00Z'
  },
  {
    id: '2',
    title: 'Reduce Power Consumption',
    description: 'Lower power limit to 80% to improve efficiency without significant performance loss',
    urgency: 'low',
    category: 'Efficiency',
    status: 'pending',
    impact: '+12% efficiency',
    created_at: '2024-01-14T14:20:00Z'
  },
  {
    id: '3',
    title: 'Update Mining Software',
    description: 'New version available with 3% performance improvement and bug fixes',
    urgency: 'high',
    category: 'Software',
    status: 'implemented',
    impact: '+3% performance',
    created_at: '2024-01-13T09:15:00Z'
  }
];

export default function RecommendationList() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    // Simulate loading recommendations
    const timer = setTimeout(() => {
      setRecommendations(mockRecommendations);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleAccept = (id: string) => {
    setRecommendations(prev => 
      prev.map(rec => 
        rec.id === id ? { ...rec, status: 'accepted' as const } : rec
      )
    );
  };

  const handleReject = (id: string) => {
    setRecommendations(prev => 
      prev.map(rec => 
        rec.id === id ? { ...rec, status: 'rejected' as const } : rec
      )
    );
  };

  const handleImplement = (id: string) => {
    setRecommendations(prev => 
      prev.map(rec => 
        rec.id === id ? { ...rec, status: 'implemented' as const } : rec
      )
    );
  };

  const filterRecommendations = (status: string) => {
    if (status === 'all') return recommendations;
    return recommendations.filter(rec => rec.status === status);
  };

  const getStatusCount = (status: string) => {
    if (status === 'all') return recommendations.length;
    return recommendations.filter(rec => rec.status === status).length;
  };

  if (loading) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 text-white animate-spin mr-2" />
            <span className="text-white">Loading recommendations...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            AI Recommendations
          </CardTitle>
          <CardDescription className="text-white/70">
            Smart suggestions to optimize your mining operations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white/10">
              <TabsTrigger value="all" className="data-[state=active]:bg-white/20">
                All ({getStatusCount('all')})
              </TabsTrigger>
              <TabsTrigger value="pending" className="data-[state=active]:bg-white/20">
                Pending ({getStatusCount('pending')})
              </TabsTrigger>
              <TabsTrigger value="accepted" className="data-[state=active]:bg-white/20">
                Accepted ({getStatusCount('accepted')})
              </TabsTrigger>
              <TabsTrigger value="implemented" className="data-[state=active]:bg-white/20">
                Implemented ({getStatusCount('implemented')})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="space-y-4">
                {filterRecommendations('all').map((recommendation) => (
                  <RecommendationItem
                    key={recommendation.id}
                    recommendation={recommendation}
                    onAccept={handleAccept}
                    onReject={handleReject}
                    onImplement={handleImplement}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="pending" className="mt-6">
              <div className="space-y-4">
                {filterRecommendations('pending').map((recommendation) => (
                  <RecommendationItem
                    key={recommendation.id}
                    recommendation={recommendation}
                    onAccept={handleAccept}
                    onReject={handleReject}
                    onImplement={handleImplement}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="accepted" className="mt-6">
              <div className="space-y-4">
                {filterRecommendations('accepted').map((recommendation) => (
                  <RecommendationItem
                    key={recommendation.id}
                    recommendation={recommendation}
                    onAccept={handleAccept}
                    onReject={handleReject}
                    onImplement={handleImplement}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="implemented" className="mt-6">
              <div className="space-y-4">
                {filterRecommendations('implemented').map((recommendation) => (
                  <RecommendationItem
                    key={recommendation.id}
                    recommendation={recommendation}
                    onAccept={handleAccept}
                    onReject={handleReject}
                    onImplement={handleImplement}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>

          {recommendations.length === 0 && (
            <div className="text-center py-8 text-white/60">
              No recommendations available at the moment.
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}