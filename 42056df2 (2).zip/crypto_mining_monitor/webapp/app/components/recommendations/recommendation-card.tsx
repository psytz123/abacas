import React, { memo } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, Info, Settings, TrendingUp, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export interface Recommendation {
  id: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  type: 'optimization' | 'security' | 'maintenance' | 'performance' | 'cost';
  actionUrl?: string;
  actionText?: string;
  dismissed?: boolean;
  confidence?: number;
  metadata?: Record<string, any>;
}

interface RecommendationCardProps {
  recommendation: Recommendation;
  onDismiss?: (id: string) => void;
  onApply?: (id: string) => void;
  onFeedback?: (id: string, type: string, details?: string) => Promise<void>;
}

// Use React.memo to prevent unnecessary re-renders
const RecommendationCard = memo(function RecommendationCard({ recommendation, onDismiss, onApply, onFeedback }: RecommendationCardProps) {
  const getIconForType = (type: string) => {
    switch (type) {
      case 'optimization':
        return <TrendingUp className="h-5 w-5" />;
      case 'security':
        return <AlertTriangle className="h-5 w-5" />;
      case 'maintenance':
        return <Settings className="h-5 w-5" />;
      case 'performance':
        return <Zap className="h-5 w-5" />;
      case 'cost':
        return <Info className="h-5 w-5" />;
      default:
        return <Info className="h-5 w-5" />;
    }
  };

  const getIconForImpact = (impact: 'high' | 'medium' | 'low') => {
    switch (impact) {
      case 'high':
        return <Zap className="h-4 w-4 text-amber-500" />;
      case 'medium':
        return <Info className="h-4 w-4 text-blue-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-500" />;
    }
  };

  const handleFeedback = async (helpful: boolean) => {
    if (onFeedback) {
      await onFeedback(recommendation.id, helpful ? 'helpful' : 'not-helpful');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex justify-between items-start">
        <div className="flex items-start">
          <div className="mr-3 mt-0.5">
            {getIconForImpact(recommendation.impact)}
          </div>
          <div>
            <h3 className="font-medium text-gray-900 dark:text-white">{recommendation.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{recommendation.description}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="outline" className="flex items-center gap-1">
                {getIconForType(recommendation.type)}
                <span className="capitalize">{recommendation.type}</span>
              </Badge>
              <Badge 
                variant="outline" 
                className={`${
                  recommendation.impact === 'high' 
                    ? 'border-amber-500 text-amber-700 dark:text-amber-300' 
                    : recommendation.impact === 'medium'
                    ? 'border-blue-500 text-blue-700 dark:text-blue-300'
                    : 'border-green-500 text-green-700 dark:text-green-300'
                }`}
              >
                {recommendation.impact === 'high' ? 'High Impact' : recommendation.impact === 'medium' ? 'Medium Impact' : 'Low Impact'}
              </Badge>
              
              {recommendation.confidence !== undefined && (
                <Badge variant="outline" className="border-purple-500 text-purple-700 dark:text-purple-300">
                  {Math.round(recommendation.confidence * 100)}% Confidence
                </Badge>
              )}
            </div>
            
            {recommendation.actionUrl && recommendation.actionText && (
              <div className="mt-4 flex gap-2">
                <Button 
                  size="sm" 
                  onClick={() => onApply && onApply(recommendation.id)}
                >
                  {recommendation.actionText}
                </Button>
                {onDismiss && (
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => onDismiss(recommendation.id)}
                  >
                    Dismiss
                  </Button>
                )}
              </div>
            )}
            
            {onFeedback && (
              <div className="mt-4 flex items-center gap-2">
                <span className="text-xs text-gray-500 dark:text-gray-400">Was this helpful?</span>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="h-7 px-2 py-1"
                  onClick={() => handleFeedback(true)}
                >
                  Yes
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="h-7 px-2 py-1"
                  onClick={() => handleFeedback(false)}
                >
                  No
                </Button>
              </div>
            )}
          </div>
        </div>
        {onDismiss && !recommendation.actionUrl && (
          <button
            onClick={() => onDismiss(recommendation.id)}
            className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
            aria-label="Dismiss"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
    </motion.div>
  );
});

// Export RecommendationCard as a named export as well
export { RecommendationCard };

export default RecommendationCard;