'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { History, Filter, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

interface Recommendation {
  id: string
  title: string
  description: string
  urgency: 'Low' | 'Medium' | 'High'
  issue_type: string
  status: string
  created_at: string
  implemented_at?: string
}

const mockRecommendations: Recommendation[] = [
  {
    id: '1',
    title: 'Optimize GPU Memory Clock',
    description: 'Increase memory clock speed for better hash rates',
    urgency: 'Medium',
    issue_type: 'Performance',
    status: 'implemented',
    created_at: '2024-01-15T10:30:00Z',
    implemented_at: '2024-01-16T14:20:00Z'
  },
  {
    id: '2',
    title: 'Reduce Power Consumption',
    description: 'Lower power limit to improve efficiency',
    urgency: 'Low',
    issue_type: 'Efficiency',
    status: 'pending',
    created_at: '2024-01-14T08:15:00Z'
  },
  {
    id: '3',
    title: 'Critical Temperature Alert',
    description: 'GPU temperature exceeding safe limits',
    urgency: 'High',
    issue_type: 'Safety',
    status: 'resolved',
    created_at: '2024-01-13T16:45:00Z'
  },
  {
    id: '4',
    title: 'Pool Connection Optimization',
    description: 'Switch to more stable mining pool',
    urgency: 'Medium',
    issue_type: 'Network',
    status: 'implemented',
    created_at: '2024-01-12T09:30:00Z',
    implemented_at: '2024-01-13T11:45:00Z'
  },
  {
    id: '5',
    title: 'Firmware Update Available',
    description: 'New firmware version with performance improvements',
    urgency: 'Low',
    issue_type: 'Software',
    status: 'dismissed',
    created_at: '2024-01-11T14:20:00Z'
  }
]

export default function RecommendationHistory() {
  const [recommendations] = useState<Recommendation[]>(mockRecommendations)
  const [filter, setFilter] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')

  const filteredRecommendations = recommendations.filter(rec => {
    const matchesFilter = filter === 'all' || rec.status === filter
    const matchesSearch = rec.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         rec.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesFilter && matchesSearch
  })

  const getRecommendationStatusColor = (status: string) => {
    switch (status) {
      case 'implemented':
        return 'success'
      case 'resolved':
        return 'success'
      case 'pending':
        return 'warning'
      case 'dismissed':
        return 'secondary'
      default:
        return 'default'
    }
  }

  const getRecommendationStatusLabel = (status: string) => {
    switch (status) {
      case 'implemented':
        return 'Implemented'
      case 'resolved':
        return 'Resolved'
      case 'pending':
        return 'Pending'
      case 'dismissed':
        return 'Dismissed'
      default:
        return status
    }
  }

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case 'High':
        return <Badge variant="destructive">{urgency}</Badge>
      case 'Medium':
        return <Badge variant="secondary">{urgency}</Badge>
      case 'Low':
        return <Badge variant="secondary">{urgency}</Badge>
      default:
        return <Badge variant="secondary">{urgency}</Badge>
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <History className="h-5 w-5 mr-2" />
            Recommendation History
          </CardTitle>
          <CardDescription className="text-white/70">
            View and manage past recommendations and their implementation status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters and Search */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-white/60" />
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="implemented">Implemented</option>
                <option value="resolved">Resolved</option>
                <option value="dismissed">Dismissed</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2 flex-1">
              <Search className="h-4 w-4 text-white/60" />
              <Input
                placeholder="Search recommendations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder-white/50"
              />
            </div>
          </div>

          {/* Recommendations Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/20">
                  <th className="text-left py-3 px-4 text-white/80 font-medium">Recommendation</th>
                  <th className="text-left py-3 px-4 text-white/80 font-medium">Type</th>
                  <th className="text-left py-3 px-4 text-white/80 font-medium">Status</th>
                  <th className="text-left py-3 px-4 text-white/80 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {filteredRecommendations.map((recommendation) => (
                  <tr key={recommendation.id} className="border-b border-white/10 hover:bg-white/5">
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        {getUrgencyBadge(recommendation.urgency)}
                        <span className="ml-2 font-medium text-white">{recommendation.issue_type}</span>
                      </div>
                      <div className="text-white font-medium mt-1">{recommendation.title}</div>
                      <div className="text-white/60 text-sm">{recommendation.description}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-white">{recommendation.issue_type}</span>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="secondary">
                        {getRecommendationStatusLabel(recommendation.status)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-white text-sm">
                        {new Date(recommendation.created_at).toLocaleDateString()}
                      </div>
                      {recommendation.implemented_at && (
                        <div className="text-white/60 text-xs">
                          Implemented: {new Date(recommendation.implemented_at).toLocaleDateString()}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredRecommendations.length === 0 && (
            <div className="text-center py-8 text-white/60">
              No recommendations found matching your criteria.
            </div>
          )}

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            {filteredRecommendations.slice(0, 3).map((recommendation) => (
              <motion.div
                key={recommendation.id}
                whileHover={{ scale: 1.02 }}
                className="p-4 bg-white/5 rounded-lg border border-white/10"
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-white text-sm">{recommendation.title}</h3>
                  <Badge variant="secondary">
                    {getRecommendationStatusLabel(recommendation.status)}
                  </Badge>
                </div>
                <p className="text-white/60 text-xs mb-3">{recommendation.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-white/50 text-xs">
                      {new Date(recommendation.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <Badge variant="secondary">
                    {getRecommendationStatusLabel(recommendation.status)}
                  </Badge>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}