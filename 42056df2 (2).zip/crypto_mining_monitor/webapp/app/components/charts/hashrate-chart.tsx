"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/skeleton";

const Chart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Line),
  {
    ssr: false,
    loading: () => (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    ),
  }
);

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface HashRateChartProps {
  loading?: boolean;
  timeRange?: string;
}

export default function HashRateChart({ loading = false, timeRange = "24h" }: HashRateChartProps) {
  const [chartData, setChartData] = useState<{
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      borderColor: string;
      backgroundColor: string;
      borderWidth: number;
      pointBackgroundColor: string;
      pointBorderColor: string;
      pointBorderWidth: number;
      pointRadius: number;
      pointHoverRadius: number;
      tension: number;
      fill: boolean;
    }[];
  }>({
    labels: [],
    datasets: [],
  });

  useEffect(() => {
    // This would be replaced with actual API data
    const generateData = () => {
      let labels: string[] = [];
      let data: number[] = [];
      
      if (timeRange === "24h") {
        // Generate hourly data for 24 hours
        for (let i = 0; i < 24; i++) {
          const hour = i.toString().padStart(2, "0") + ":00";
          labels.push(hour);
          // Generate a realistic hashrate pattern with some variance
          const baseValue = 450 + Math.random() * 50;
          const timeOfDayFactor = Math.sin((i / 24) * Math.PI * 2) * 20; // Daily cycle
          data.push(baseValue + timeOfDayFactor);
        }
      } else if (timeRange === "7d") {
        // Generate daily data for 7 days
        const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
        labels = days;
        for (let i = 0; i < 7; i++) {
          const baseValue = 460 + Math.random() * 40;
          const weekdayFactor = i < 5 ? 10 : -10; // Weekday vs weekend pattern
          data.push(baseValue + weekdayFactor);
        }
      } else if (timeRange === "30d") {
        // Generate data for 30 days
        for (let i = 1; i <= 30; i++) {
          labels.push(`Day ${i}`);
          const baseValue = 450 + Math.random() * 60;
          const trendFactor = (i / 30) * 20; // Slight upward trend
          data.push(baseValue + trendFactor);
        }
      } else if (timeRange === "90d") {
        // Generate data for 90 days (by weeks)
        for (let i = 1; i <= 13; i++) {
          labels.push(`Week ${i}`);
          const baseValue = 430 + Math.random() * 70;
          const trendFactor = (i / 13) * 40; // Stronger upward trend
          data.push(baseValue + trendFactor);
        }
      }

      return {
        labels,
        datasets: [
          {
            label: "Hashrate (MH/s)",
            data,
            borderColor: "rgba(59, 130, 246, 1)",
            backgroundColor: "rgba(59, 130, 246, 0.1)",
            borderWidth: 2,
            pointBackgroundColor: "rgba(59, 130, 246, 1)",
            pointBorderColor: "#fff",
            pointBorderWidth: 1,
            pointRadius: 3,
            pointHoverRadius: 5,
            tension: 0.4,
            fill: true,
          },
        ],
      };
    };

    if (!loading) {
      setChartData(generateData());
    }
  }, [loading, timeRange]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
        backgroundColor: "rgba(17, 24, 39, 0.8)",
        titleFont: {
          size: 13,
        },
        bodyFont: {
          size: 12,
        },
        padding: 10,
        cornerRadius: 4,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          display: true,
          drawBorder: false,
        },
        ticks: {
          font: {
            size: 11,
          },
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 11,
          },
        },
      },
    },
    interaction: {
      mode: "nearest" as const,
      axis: "x" as const,
      intersect: false,
    },
  };

  if (loading) {
    return (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    );
  }

  return (
    <div className="h-[300px] w-full">
      <Chart data={chartData} options={options} />
    </div>
  );
}