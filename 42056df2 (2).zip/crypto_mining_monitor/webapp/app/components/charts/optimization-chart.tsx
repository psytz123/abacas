"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/skeleton";

const Chart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Bar),
  {
    ssr: false,
    loading: () => (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    ),
  }
);

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface OptimizationChartProps {
  loading?: boolean;
}

export default function OptimizationChart({ loading = false }: OptimizationChartProps) {
  const [chartData, setChartData] = useState<{
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      backgroundColor: string;
      borderColor: string;
      borderWidth: number;
      borderRadius: number;
    }[];
  }>({
    labels: [],
    datasets: [],
  });

  useEffect(() => {
    // This would be replaced with actual API data
    const generateData = () => {
      const labels = ["Hashrate (MH/s)", "Power (W/10)", "Efficiency (MH/W × 100)", "Temperature (°C)"];
      
      return {
        labels,
        datasets: [
          {
            label: "Before Optimization",
            data: [450, 340, 13.2, 68],
            backgroundColor: "rgba(148, 163, 184, 0.7)",
            borderColor: "rgba(148, 163, 184, 1)",
            borderWidth: 1,
            borderRadius: 4,
          },
          {
            label: "After Optimization",
            data: [485, 320, 15.2, 62],
            backgroundColor: "rgba(59, 130, 246, 0.7)",
            borderColor: "rgba(59, 130, 246, 1)",
            borderWidth: 1,
            borderRadius: 4,
          },
        ],
      };
    };

    if (!loading) {
      setChartData(generateData());
    }
  }, [loading]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
        backgroundColor: "rgba(17, 24, 39, 0.8)",
        titleFont: {
          size: 13,
        },
        bodyFont: {
          size: 12,
        },
        padding: 10,
        cornerRadius: 4,
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            
            let value = context.parsed.y;
            const metric = context.label;
            
            if (metric.includes("Hashrate")) {
              label += value.toFixed(1) + " MH/s";
            } else if (metric.includes("Power")) {
              label += (value * 10).toFixed(0) + " W";
            } else if (metric.includes("Efficiency")) {
              label += (value / 100).toFixed(2) + " MH/W";
            } else if (metric.includes("Temperature")) {
              label += value.toFixed(1) + " °C";
            } else {
              label += value;
            }
            
            return label;
          }
        }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          display: true,
          drawBorder: false,
        },
        ticks: {
          font: {
            size: 11,
          },
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 11,
          },
        },
      },
    },
    interaction: {
      mode: "index" as const,
      intersect: false,
    },
  };

  if (loading) {
    return (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    );
  }

  return (
    <div className="h-[300px] w-full">
      <Chart data={chartData} options={options} />
    </div>
  );
}