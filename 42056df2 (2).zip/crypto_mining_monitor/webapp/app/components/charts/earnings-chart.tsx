"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/skeleton";

const Chart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Bar),
  {
    ssr: false,
    loading: () => (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    ),
  }
);

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface EarningsChartProps {
  loading?: boolean;
  timeRange?: string;
}

export default function EarningsChart({ loading = false, timeRange = "7d" }: EarningsChartProps) {
  const [chartData, setChartData] = useState<{
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      backgroundColor: string;
      borderColor: string;
      borderWidth: number;
      borderRadius: number;
      hoverBackgroundColor: string;
    }[];
  }>({
    labels: [],
    datasets: [],
  });

  useEffect(() => {
    // This would be replaced with actual API data
    const generateData = () => {
      let labels: string[] = [];
      let data: number[] = [];
      
      if (timeRange === "24h") {
        // Generate hourly data for 24 hours
        for (let i = 0; i < 24; i++) {
          const hour = i.toString().padStart(2, "0") + ":00";
          labels.push(hour);
          // Generate earnings with some variance
          data.push(2.5 + Math.random() * 1.5);
        }
      } else if (timeRange === "7d") {
        // Generate daily data for 7 days
        const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
        labels = days;
        for (let i = 0; i < 7; i++) {
          data.push(55 + Math.random() * 15);
        }
      } else if (timeRange === "30d") {
        // Generate weekly data for a month
        for (let i = 1; i <= 4; i++) {
          labels.push(`Week ${i}`);
          data.push(380 + Math.random() * 80);
        }
      } else if (timeRange === "90d") {
        // Generate monthly data for 3 months
        labels = ["Month 1", "Month 2", "Month 3"];
        for (let i = 0; i < 3; i++) {
          data.push(1500 + Math.random() * 300);
        }
      }

      return {
        labels,
        datasets: [
          {
            label: "Earnings ($)",
            data,
            backgroundColor: "rgba(16, 185, 129, 0.7)",
            borderColor: "rgba(16, 185, 129, 1)",
            borderWidth: 1,
            borderRadius: 4,
            hoverBackgroundColor: "rgba(16, 185, 129, 0.9)",
          },
        ],
      };
    };

    if (!loading) {
      setChartData(generateData());
    }
  }, [loading, timeRange]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
        backgroundColor: "rgba(17, 24, 39, 0.8)",
        titleFont: {
          size: 13,
        },
        bodyFont: {
          size: 12,
        },
        padding: 10,
        cornerRadius: 4,
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(context.parsed.y);
            }
            return label;
          }
        }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          display: true,
          drawBorder: false,
        },
        ticks: {
          font: {
            size: 11,
          },
          callback: function(value: any) {
            return '$' + value;
          }
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 11,
          },
        },
      },
    },
  };

  if (loading) {
    return (
      <div className="h-[300px] w-full flex items-center justify-center">
        <Skeleton className="h-full w-full rounded-md" />
      </div>
    );
  }

  return (
    <div className="h-[300px] w-full">
      <Chart data={chartData} options={options} />
    </div>
  );
}