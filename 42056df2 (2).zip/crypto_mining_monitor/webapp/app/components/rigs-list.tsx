'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Cpu, 
  Zap, 
  Thermometer, 
  Clock,
  MoreVertical,
  Play,
  Pause,
  Settings
} from 'lucide-react'
import { Button } from '@/components/ui/button'

interface RigsListProps {
  filters: any
}

export default function RigsList({ filters }: RigsListProps) {
  const [rigs, setRigs] = useState<any[]>([])

  useEffect(() => {
    // Generate sample rigs data based on filters
    const generateRigs = () => {
      const sampleRigs = [
        {
          id: '1',
          name: 'Antminer S19 Pro #001',
          status: 'active',
          hashrate: 110.5,
          power: 3250,
          temperature: 68,
          uptime: 99.8,
          efficiency: 29.4
        },
        {
          id: '2',
          name: 'Antminer S19 Pro #002',
          status: 'active',
          hashrate: 108.2,
          power: 3280,
          temperature: 71,
          uptime: 98.5,
          efficiency: 33.0
        },
        {
          id: '3',
          name: 'Whatsminer M30S #001',
          status: 'maintenance',
          hashrate: 0,
          power: 0,
          temperature: 25,
          uptime: 0,
          efficiency: 0
        },
        {
          id: '4',
          name: 'Antminer S19 Pro #003',
          status: 'active',
          hashrate: 112.8,
          power: 3200,
          temperature: 65,
          uptime: 99.9,
          efficiency: 28.4
        },
        {
          id: '5',
          name: 'Whatsminer M30S #002',
          status: 'active',
          hashrate: 86.5,
          power: 3400,
          temperature: 73,
          uptime: 97.2,
          efficiency: 39.3
        }
      ]

      // Apply filters
      let filteredRigs = sampleRigs

      if (filters.rigStatus !== 'all') {
        filteredRigs = filteredRigs.filter(rig => rig.status === filters.rigStatus)
      }

      filteredRigs = filteredRigs.filter(rig => 
        rig.hashrate >= filters.minHashrate && 
        rig.hashrate <= filters.maxHashrate &&
        rig.temperature >= filters.minTemperature &&
        rig.temperature <= filters.maxTemperature
      )

      setRigs(filteredRigs)
    }

    generateRigs()
  }, [filters])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
      case 'maintenance':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400'
      case 'inactive':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400'
    }
  }

  if (rigs.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
        <div className="text-center">
          <Cpu className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No Mining Rigs Found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            No rigs match the selected filters. Try adjusting your filter criteria.
          </p>
        </div>
      </div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700"
    >
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Mining Rigs ({rigs.length})
        </h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-gray-900/50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Rig Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Hashrate
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Power
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Temperature
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Uptime
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {rigs.map((rig, index) => (
              <motion.tr
                key={rig.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Cpu className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {rig.name}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        ID: {rig.id}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(rig.status)}`}>
                    {rig.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Zap className="h-4 w-4 text-blue-500 mr-2" />
                    <span className="text-sm text-gray-900 dark:text-white">
                      {rig.hashrate.toFixed(1)} TH/s
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-900 dark:text-white">
                    {rig.power}W
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Thermometer className="h-4 w-4 text-red-500 mr-2" />
                    <span className="text-sm text-gray-900 dark:text-white">
                      {rig.temperature}°C
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm text-gray-900 dark:text-white">
                      {rig.uptime.toFixed(1)}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      {rig.status === 'active' ? (
                        <Pause className="h-4 w-4" />
                      ) : (
                        <Play className="h-4 w-4" />
                      )}
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Settings className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  )
}