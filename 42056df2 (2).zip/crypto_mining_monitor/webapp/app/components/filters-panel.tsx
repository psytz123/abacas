'use client'

import { motion } from 'framer-motion'
import { Filter, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface FiltersPanelProps {
  filters: any
  onFiltersChange: (filters: any) => void
}

export default function FiltersPanel({ filters, onFiltersChange }: FiltersPanelProps) {
  const updateFilter = (key: string, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    })
  }

  const resetFilters = () => {
    onFiltersChange({
      timeRange: '24h',
      rigStatus: 'all',
      minHashrate: 0,
      maxHashrate: 1000,
      minTemperature: 0,
      maxTemperature: 100
    })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Filters
          </h3>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={resetFilters}
          className="flex items-center space-x-2"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Reset</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Time Range
          </label>
          <Select value={filters.timeRange} onValueChange={(value) => updateFilter('timeRange', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last Hour</SelectItem>
              <SelectItem value="6h">Last 6 Hours</SelectItem>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Rig Status
          </label>
          <Select value={filters.rigStatus} onValueChange={(value) => updateFilter('rigStatus', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Hashrate Range (TH/s)
          </label>
          <div className="px-2">
            <Slider
              value={[filters.minHashrate, filters.maxHashrate]}
              onValueChange={(value) => {
                updateFilter('minHashrate', value[0])
                updateFilter('maxHashrate', value[1])
              }}
              max={1000}
              min={0}
              step={10}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>{filters.minHashrate}</span>
              <span>{filters.maxHashrate}</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Temperature Range (°C)
          </label>
          <div className="px-2">
            <Slider
              value={[filters.minTemperature, filters.maxTemperature]}
              onValueChange={(value) => {
                updateFilter('minTemperature', value[0])
                updateFilter('maxTemperature', value[1])
              }}
              max={100}
              min={0}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>{filters.minTemperature}°C</span>
              <span>{filters.maxTemperature}°C</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}