'use client'

import { motion } from 'framer-motion'
import { Zap, Thermometer, DollarSign, Activity } from 'lucide-react'
import { useInView } from 'react-intersection-observer'
import { useEffect, useState } from 'react'

interface MiningStatsProps {
  miners: any[]
}

export function MiningStats({ miners }: MiningStatsProps) {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 })
  const [animatedValues, setAnimatedValues] = useState({
    totalHash: 0,
    totalPower: 0,
    totalEarnings: 0,
    activeMiners: 0
  })

  const stats = {
    totalHash: miners.reduce((sum, miner) => sum + miner.hashRate, 0),
    totalPower: miners.reduce((sum, miner) => sum + miner.power, 0),
    totalEarnings: miners.reduce((sum, miner) => sum + miner.earnings, 0),
    activeMiners: miners.filter(miner => miner.status === 'online').length
  }

  useEffect(() => {
    if (inView) {
      const duration = 2000
      const steps = 60
      const stepDuration = duration / steps

      let currentStep = 0
      const interval = setInterval(() => {
        currentStep++
        const progress = currentStep / steps

        setAnimatedValues({
          totalHash: Math.floor(stats.totalHash * progress),
          totalPower: Math.floor(stats.totalPower * progress),
          totalEarnings: parseFloat((stats.totalEarnings * progress).toFixed(2)),
          activeMiners: Math.floor(stats.activeMiners * progress)
        })

        if (currentStep >= steps) {
          clearInterval(interval)
          setAnimatedValues(stats)
        }
      }, stepDuration)

      return () => clearInterval(interval)
    }
  }, [inView, stats.totalHash, stats.totalPower, stats.totalEarnings, stats.activeMiners])

  const statCards = [
    {
      title: 'Total Hash Rate',
      value: `${animatedValues.totalHash.toFixed(1)} TH/s`,
      icon: Zap,
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20'
    },
    {
      title: 'Total Power',
      value: `${animatedValues.totalPower.toFixed(0)} W`,
      icon: Activity,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50 dark:bg-green-900/20'
    },
    {
      title: 'Daily Earnings',
      value: `$${animatedValues.totalEarnings.toFixed(2)}`,
      icon: DollarSign,
      color: 'from-yellow-500 to-orange-500',
      bgColor: 'bg-yellow-50 dark:bg-yellow-900/20'
    },
    {
      title: 'Active Miners',
      value: animatedValues.activeMiners.toString(),
      icon: Thermometer,
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20'
    }
  ]

  return (
    <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ delay: index * 0.1, duration: 0.5 }}
          whileHover={{ scale: 1.05, y: -5 }}
          className={`${stat.bgColor} rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700`}
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-xl bg-gradient-to-r ${stat.color}`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
            {stat.title}
          </h3>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {stat.value}
          </p>
        </motion.div>
      ))}
    </div>
  )
}