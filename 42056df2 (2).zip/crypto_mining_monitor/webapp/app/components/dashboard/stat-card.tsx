"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { LucideIcon } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface StatCardProps {
  title: string
  value: string | number
  icon: LucideIcon
  description?: string
  trend?: number
  trendLabel?: string
  className?: string
  valuePrefix?: string
  valueSuffix?: string
}

export function StatCard({
  title,
  value,
  icon: Icon,
  description,
  trend,
  trendLabel,
  className,
  valuePrefix = "",
  valueSuffix = "",
}: StatCardProps) {
  const [displayValue, setDisplayValue] = useState(0)
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  // Animate the number when in view
  useEffect(() => {
    if (inView) {
      const numericValue = typeof value === "string" ? parseFloat(value) : value
      let startValue = 0
      const duration = 1500
      const startTime = Date.now()

      const updateValue = () => {
        const currentTime = Date.now()
        const elapsedTime = currentTime - startTime
        
        if (elapsedTime < duration) {
          const progress = elapsedTime / duration
          // Easing function for smoother animation
          const easedProgress = 1 - Math.pow(1 - progress, 3)
          setDisplayValue(Math.floor(easedProgress * numericValue))
          requestAnimationFrame(updateValue)
        } else {
          setDisplayValue(numericValue)
        }
      }

      requestAnimationFrame(updateValue)
    }
  }, [inView, value])

  const formattedValue = typeof value === "string" 
    ? value 
    : `${valuePrefix}${displayValue.toLocaleString()}${valueSuffix}`

  const trendColor = trend 
    ? trend > 0 
      ? "text-green-500" 
      : "text-red-500" 
    : ""

  const trendIcon = trend 
    ? trend > 0 
      ? "↑" 
      : "↓" 
    : ""

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5 }}
      className={className}
    >
      <Card className="overflow-hidden h-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {typeof value === "string" ? value : formattedValue}
          </div>
          {(description || trend !== undefined) && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              {description}
              {trend !== undefined && (
                <span className={cn("ml-1 flex items-center", trendColor)}>
                  {trendIcon} {Math.abs(trend)}% {trendLabel}
                </span>
              )}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}