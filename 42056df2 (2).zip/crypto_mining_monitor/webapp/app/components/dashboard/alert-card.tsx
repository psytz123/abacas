'use client'

import { motion } from 'framer-motion'
import { AlertTriangle, CheckCircle, XCircle, Info } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface Alert {
  id: string
  title: string
  message: string
  severity: 'critical' | 'warning' | 'info'
  status: 'active' | 'resolved' | 'dismissed'
  timestamp: string
}

interface AlertCardProps {
  alert: Alert
  onDismiss?: (id: string) => void
  onResolve?: (id: string) => void
}

export default function AlertCard({ alert, onDismiss, onResolve }: AlertCardProps) {
  const getSeverityIcon = () => {
    switch (alert.severity) {
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-500" />
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case 'info':
        return <Info className="h-5 w-5 text-blue-500" />
      default:
        return <Info className="h-5 w-5 text-blue-500" />
    }
  }

  const getSeverityBadge = () => {
    switch (alert.severity) {
      case 'critical':
        return <Badge variant="destructive">{alert.severity}</Badge>
      case 'warning':
        return <Badge variant="secondary">{alert.severity}</Badge>
      case 'info':
        return <Badge variant="secondary">{alert.severity}</Badge>
      default:
        return <Badge>{alert.severity}</Badge>
    }
  }

  const getStatusBadge = () => {
    switch (alert.status) {
      case 'active':
        return <Badge variant="destructive">Active</Badge>
      case 'resolved':
        return <Badge variant="secondary">Resolved</Badge>
      case 'dismissed':
        return <Badge variant="secondary">Dismissed</Badge>
      default:
        return <Badge>{alert.status}</Badge>
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {getSeverityIcon()}
              <CardTitle className="text-white text-lg">{alert.title}</CardTitle>
            </div>
            <div className="flex space-x-2">
              {getSeverityBadge()}
              {getStatusBadge()}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-white/70 mb-3">
            {alert.message}
          </CardDescription>
          <div className="flex justify-between items-center">
            <span className="text-white/50 text-sm">
              {new Date(alert.timestamp).toLocaleString()}
            </span>
            <div className="flex space-x-2">
              {alert.status === 'active' && onResolve && (
                <button
                  onClick={() => onResolve(alert.id)}
                  className="text-green-400 hover:text-green-300 text-sm"
                >
                  Resolve
                </button>
              )}
              {onDismiss && (
                <button
                  onClick={() => onDismiss(alert.id)}
                  className="text-red-400 hover:text-red-300 text-sm"
                >
                  Dismiss
                </button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}