"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCw, Cpu, Thermometer, Zap, Gauge, Fan, Clock, Activity } from "lucide-react";
import { motion } from "framer-motion";

interface MinerStatsProps {
  minerId?: string;
}

export function MinerStats({ minerId }: MinerStatsProps) {
  const [miners, setMiners] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedMinerId, setSelectedMinerId] = useState<string | null>(minerId || null);

  useEffect(() => {
    fetchMiners();
  }, []);

  async function fetchMiners() {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch("/api/miners");
      
      if (!response.ok) {
        throw new Error(`Error fetching miners: ${response.statusText}`);
      }
      
      const data = await response.json();
      setMiners(data.miners || []);
      
      // If no miner is selected and we have miners, select the first one
      if (!selectedMinerId && data.miners && data.miners.length > 0) {
        setSelectedMinerId(data.miners[0].miner_id);
      }
    } catch (err) {
      console.error("Failed to fetch miners:", err);
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  }

  const getSelectedMiner = () => {
    return miners.find(miner => miner.miner_id === selectedMinerId) || null;
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "online":
        return "bg-green-100 text-green-800";
      case "offline":
        return "bg-red-100 text-red-800";
      case "warning":
        return "bg-yellow-100 text-yellow-800";
      case "maintenance":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  const selectedMiner = getSelectedMiner();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Miner Statistics</h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={fetchMiners}
          disabled={loading}
          className="flex items-center gap-1"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? "Refreshing..." : "Refresh"}</span>
        </Button>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center gap-2">
            <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Loading miner data...</p>
          </div>
        </div>
      ) : error ? (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-50 p-4 rounded-md flex items-start gap-3"
        >
          <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
          <div>
            <h3 className="font-medium text-red-800">Error loading miner data</h3>
            <p className="text-red-700 text-sm mt-1">{error}</p>
            <Button 
              onClick={fetchMiners} 
              variant="outline" 
              size="sm" 
              className="mt-3 bg-white"
            >
              Try Again
            </Button>
          </div>
        </motion.div>
      ) : miners.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-50 p-6 rounded-md text-center"
        >
          <h3 className="font-medium text-blue-800 mb-2">No Miners Found</h3>
          <p className="text-blue-700 text-sm">
            No miners are currently connected to your account.
          </p>
        </motion.div>
      ) : (
        <>
          <Tabs 
            defaultValue={selectedMinerId || miners[0].miner_id} 
            onValueChange={setSelectedMinerId}
            className="w-full"
          >
            <TabsList className="mb-4">
              {miners.map((miner) => (
                <TabsTrigger key={miner.miner_id} value={miner.miner_id}>
                  Miner {miner.miner_id}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value={selectedMinerId || ""} className="mt-0">
              {selectedMiner && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
                >
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Cpu className="h-4 w-4 text-blue-500" />
                        Hashrate
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedMiner.hashrate.toFixed(2)} TH/s</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Thermometer className="h-4 w-4 text-red-500" />
                        Temperature
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedMiner.temperature}°C</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Zap className="h-4 w-4 text-yellow-500" />
                        Power
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedMiner.power_consumption}W</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Gauge className="h-4 w-4 text-green-500" />
                        Efficiency
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedMiner.efficiency.toFixed(2)} J/TH</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Fan className="h-4 w-4 text-purple-500" />
                        Fan Speed
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedMiner.fan_speed}%</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Clock className="h-4 w-4 text-indigo-500" />
                        Uptime
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{formatUptime(selectedMiner.uptime)}</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Activity className="h-4 w-4 text-blue-500" />
                        Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Badge className={getStatusColor(selectedMiner.status)}>
                        {selectedMiner.status.charAt(0).toUpperCase() + selectedMiner.status.slice(1)}
                      </Badge>
                      <div className="text-xs text-gray-500 mt-2">
                        Last updated: {new Date(selectedMiner.last_updated).toLocaleString()}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}