"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  Clock, 
  Database, 
  DollarSign, 
  Globe, 
  RefreshCw, 
  Server, 
  Users, 
  Zap 
} from 'lucide-react';

interface PoolStats {
  name: string;
  hashrate: number;
  miners: number;
  workers: number;
  fee: number;
  lastBlockFound: string;
  currentDifficulty: number;
  networkHashrate: number;
  blockReward: number;
  coin: string;
}

interface PoolStatsCardProps {
  initialData?: PoolStats;
}

const PoolStatsCard: React.FC<PoolStatsCardProps> = ({ initialData }) => {
  const [stats, setStats] = useState<PoolStats | null>(initialData || null);
  const [loading, setLoading] = useState<boolean>(!initialData);
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // Fetch stats if not provided
  useEffect(() => {
    if (!initialData) {
      const fetchStats = async () => {
        try {
          setLoading(true);
          // In a real app, this would be an API call
          // For now, we'll simulate with mock data
          const mockData: PoolStats = {
            name: 'ProHashing',
            hashrate: 5600000000000000, // 5.6 EH/s
            miners: 12543,
            workers: 45678,
            fee: 0.9, // 0.9%
            lastBlockFound: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15 minutes ago
            currentDifficulty: 35364532674357.8,
            networkHashrate: 325000000000000000, // 325 EH/s
            blockReward: 6.25,
            coin: 'BTC'
          };
          
          setTimeout(() => {
            setStats(mockData);
            setLoading(false);
          }, 1000);
        } catch (error) {
          console.error('Failed to fetch pool stats:', error);
          setLoading(false);
        }
      };
      
      fetchStats();
    }
  }, [initialData]);

  // Format hashrate
  const formatHashrate = (hashrate: number): string => {
    if (hashrate >= 1000000000000000) {
      return `${(hashrate / 1000000000000000).toFixed(2)} EH/s`;
    } else if (hashrate >= 1000000000000) {
      return `${(hashrate / 1000000000000).toFixed(2)} PH/s`;
    } else if (hashrate >= 1000000000) {
      return `${(hashrate / 1000000000).toFixed(2)} TH/s`;
    } else if (hashrate >= 1000000) {
      return `${(hashrate / 1000000).toFixed(2)} GH/s`;
    } else if (hashrate >= 1000) {
      return `${(hashrate / 1000).toFixed(2)} MH/s`;
    } else {
      return `${hashrate.toFixed(2)} H/s`;
    }
  };

  // Format time ago
  const formatTimeAgo = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    
    if (diffSec < 60) {
      return `${diffSec} sec ago`;
    } else if (diffMin < 60) {
      return `${diffMin} min ago`;
    } else if (diffHour < 24) {
      return `${diffHour} hr ago`;
    } else {
      return `${diffDay} day ago`;
    }
  };

  // Function to animate numbers
  const AnimatedNumber = ({ value, decimals = 0 }: { value: number, decimals?: number }) => {
    const [displayValue, setDisplayValue] = useState(0);
    
    useEffect(() => {
      if (inView) {
        let start = 0;
        const end = value;
        const duration = 1500;
        const startTime = Date.now();
        
        const timer = setInterval(() => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          setDisplayValue(progress * end);
          
          if (progress === 1) {
            clearInterval(timer);
          }
        }, 16);
        
        return () => clearInterval(timer);
      }
    }, [value, inView]);
    
    return <>{displayValue.toFixed(decimals)}</>;
  };

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
    >
      <div className="p-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold flex items-center">
              <Globe className="mr-2 h-5 w-5" />
              Pool Statistics
            </h2>
            <p className="text-sm opacity-80">
              {stats?.name || 'Mining Pool'} - {stats?.coin || 'BTC'}
            </p>
          </div>
          <button 
            onClick={() => {
              setLoading(true);
              setTimeout(() => setLoading(false), 1000);
            }}
            className="p-2 rounded-md text-white/70 hover:text-white hover:bg-white/10"
            title="Refresh stats"
          >
            <RefreshCw className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="p-6 flex justify-center items-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
        </div>
      ) : stats ? (
        <div className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg"
            >
              <div className="flex items-center mb-2">
                <Zap className="h-5 w-5 text-amber-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Pool Hashrate</h3>
              </div>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">
                {formatHashrate(stats.hashrate)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {((stats.hashrate / stats.networkHashrate) * 100).toFixed(2)}% of network
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
              transition={{ duration: 0.3, delay: 0.2 }}
              className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg"
            >
              <div className="flex items-center mb-2">
                <Users className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Miners</h3>
              </div>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">
                <AnimatedNumber value={stats.miners} />
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                <AnimatedNumber value={stats.workers} /> workers
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
              transition={{ duration: 0.3, delay: 0.3 }}
              className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg"
            >
              <div className="flex items-center mb-2">
                <Database className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Last Block</h3>
              </div>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">
                {formatTimeAgo(stats.lastBlockFound)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {new Date(stats.lastBlockFound).toLocaleTimeString()}
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
              transition={{ duration: 0.3, delay: 0.4 }}
              className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg"
            >
              <div className="flex items-center mb-2">
                <DollarSign className="h-5 w-5 text-purple-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Pool Fee</h3>
              </div>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">
                {stats.fee}%
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Block reward: {stats.blockReward} {stats.coin}
              </p>
            </motion.div>
          </div>
          
          <div className="mt-6 bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Network Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Network Hashrate:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{formatHashrate(stats.networkHashrate)}</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Current Difficulty:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{stats.currentDifficulty.toExponential(2)}</span>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Your Hashrate:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">45.7 TH/s</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400">Est. Time to Find Block:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">~152 days</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-6 text-center">
          <Server className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">No pool data available</h3>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
            Unable to fetch pool statistics at this time.
          </p>
          <button 
            onClick={() => {
              setLoading(true);
              setTimeout(() => setLoading(false), 1000);
            }}
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </button>
        </div>
      )}
      
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right">
        <a href="/pool/stats" className="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">
          View detailed pool statistics →
        </a>
      </div>
    </motion.div>
  );
};

export default PoolStatsCard;