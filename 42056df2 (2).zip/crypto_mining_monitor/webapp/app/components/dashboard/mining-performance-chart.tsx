"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import dynamic from 'next/dynamic';
import { ArrowDown, ArrowUp, Calendar, ChevronDown, Clock, RefreshCw } from 'lucide-react';

// Dynamically import Chart component with SSR disabled
const Chart = dynamic(
  () => import('react-chartjs-2').then(mod => mod.Line),
  { ssr: false, loading: () => <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div></div> }
);

// Import Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface MiningPerformanceData {
  timestamp: string;
  hashrate: number;
  power: number;
  temperature: number;
  efficiency: number;
}

interface MiningPerformanceChartProps {
  initialData?: MiningPerformanceData[];
}

const MiningPerformanceChart: React.FC<MiningPerformanceChartProps> = ({ initialData }) => {
  const [data, setData] = useState<MiningPerformanceData[]>(initialData || []);
  const [loading, setLoading] = useState<boolean>(!initialData);
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d' | '90d'>('24h');
  const [metric, setMetric] = useState<'hashrate' | 'power' | 'temperature' | 'efficiency'>('hashrate');
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // Generate mock data if not provided
  useEffect(() => {
    if (!initialData) {
      const fetchData = async () => {
        try {
          setLoading(true);
          // In a real app, this would be an API call
          // For now, we'll generate mock data
          const mockData: MiningPerformanceData[] = [];
          const now = new Date();
          
          // Generate data points based on selected time range
          const dataPoints = timeRange === '24h' ? 24 : timeRange === '7d' ? 7 * 24 : timeRange === '30d' ? 30 : 90;
          const interval = timeRange === '24h' ? 60 : timeRange === '7d' ? 180 : 24 * 60;
          
          for (let i = dataPoints; i >= 0; i--) {
            const timestamp = new Date(now.getTime() - i * interval * 60 * 1000);
            
            // Add some randomness to make the chart interesting
            const baseHashrate = 45.5; // TH/s
            const basePower = 1250; // Watts
            const baseTemp = 65; // Celsius
            
            // Add daily patterns and some randomness
            const hourFactor = (timestamp.getHours() % 24) / 24;
            const randomFactor = Math.random() * 0.1 - 0.05; // -5% to +5%
            
            const hashrate = baseHashrate * (1 + Math.sin(hourFactor * Math.PI * 2) * 0.05 + randomFactor);
            const power = basePower * (1 + Math.sin(hourFactor * Math.PI * 2) * 0.03 + randomFactor);
            const temperature = baseTemp * (1 + Math.sin(hourFactor * Math.PI * 2) * 0.04 + randomFactor);
            const efficiency = hashrate / (power / 1000); // TH/s per kW
            
            mockData.push({
              timestamp: timestamp.toISOString(),
              hashrate,
              power,
              temperature,
              efficiency
            });
          }
          
          setTimeout(() => {
            setData(mockData);
            setLoading(false);
          }, 1000);
        } catch (error) {
          console.error('Failed to fetch mining performance data:', error);
          setLoading(false);
        }
      };
      
      fetchData();
    }
  }, [initialData, timeRange]);

  // Format data for Chart.js
  const chartData = {
    labels: data.map(d => {
      const date = new Date(d.timestamp);
      return timeRange === '24h' 
        ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }),
    datasets: [
      {
        label: getMetricLabel(metric),
        data: data.map(d => d[metric]),
        borderColor: getMetricColor(metric),
        backgroundColor: `${getMetricColor(metric)}33`, // Add transparency
        borderWidth: 2,
        pointRadius: timeRange === '24h' ? 2 : 0,
        pointHoverRadius: 5,
        tension: 0.4,
        fill: true,
      }
    ]
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += formatMetricValue(metric, context.parsed.y);
            }
            return label;
          }
        }
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          maxRotation: 0,
          autoSkip: true,
          maxTicksLimit: 8,
        }
      },
      y: {
        beginAtZero: false,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          callback: function(value: any) {
            return formatMetricValue(metric, value);
          }
        }
      }
    },
    interaction: {
      mode: 'nearest' as const,
      axis: 'x' as const,
      intersect: false
    },
    elements: {
      line: {
        cubicInterpolationMode: 'monotone' as const,
      }
    }
  };

  // Helper functions
  function getMetricLabel(metric: string): string {
    switch (metric) {
      case 'hashrate': return 'Hash Rate';
      case 'power': return 'Power Consumption';
      case 'temperature': return 'Temperature';
      case 'efficiency': return 'Efficiency';
      default: return '';
    }
  }

  function getMetricColor(metric: string): string {
    switch (metric) {
      case 'hashrate': return '#4f46e5'; // indigo-600
      case 'power': return '#dc2626'; // red-600
      case 'temperature': return '#ea580c'; // orange-600
      case 'efficiency': return '#16a34a'; // green-600
      default: return '#6b7280'; // gray-500
    }
  }

  function formatMetricValue(metric: string, value: number): string {
    switch (metric) {
      case 'hashrate': return `${value.toFixed(2)} TH/s`;
      case 'power': return `${value.toFixed(0)} W`;
      case 'temperature': return `${value.toFixed(1)} °C`;
      case 'efficiency': return `${value.toFixed(3)} TH/kW`;
      default: return value.toString();
    }
  }

  // Calculate performance change
  const calculateChange = (): { value: number; percentage: number } => {
    if (data.length < 2) return { value: 0, percentage: 0 };
    
    const latest = data[data.length - 1][metric];
    const previous = data[0][metric];
    const change = latest - previous;
    const percentage = (change / previous) * 100;
    
    return { value: change, percentage };
  };

  const change = calculateChange();

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
    >
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Mining Performance</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Track your mining metrics over time
          </p>
        </div>
        <div className="flex space-x-2">
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none"
            >
              {getMetricLabel(metric)}
              <ChevronDown className="ml-2 h-4 w-4" />
            </button>
            {isDropdownOpen && (
              <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white dark:bg-gray-700 ring-1 ring-black ring-opacity-5 z-10">
                <div className="py-1" role="menu" aria-orientation="vertical">
                  {['hashrate', 'power', 'temperature', 'efficiency'].map((m) => (
                    <button
                      key={m}
                      onClick={() => {
                        setMetric(m as any);
                        setIsDropdownOpen(false);
                      }}
                      className={`block px-4 py-2 text-sm w-full text-left ${
                        metric === m 
                          ? 'bg-gray-100 dark:bg-gray-600 text-gray-900 dark:text-white' 
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600'
                      }`}
                      role="menuitem"
                    >
                      {getMetricLabel(m)}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center">
              <span className="text-3xl font-bold text-gray-900 dark:text-white">
                {data.length > 0 ? formatMetricValue(metric, data[data.length - 1][metric]) : '-'}
              </span>
              {change.percentage !== 0 && (
                <span className={`ml-2 flex items-center text-sm font-medium ${
                  change.percentage > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {change.percentage > 0 ? (
                    <ArrowUp className="h-4 w-4 mr-1" />
                  ) : (
                    <ArrowDown className="h-4 w-4 mr-1" />
                  )}
                  {Math.abs(change.percentage).toFixed(2)}%
                </span>
              )}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center mt-1">
              <Clock className="h-4 w-4 mr-1" />
              Last updated: {data.length > 0 ? new Date(data[data.length - 1].timestamp).toLocaleString() : '-'}
            </p>
          </div>
          
          <div className="flex space-x-1">
            {(['24h', '7d', '30d', '90d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1 text-xs font-medium rounded-md ${
                  timeRange === range
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                {range}
              </button>
            ))}
            <button 
              onClick={() => {
                setLoading(true);
                setTimeout(() => setLoading(false), 1000);
              }}
              className="p-1 rounded-md text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              title="Refresh data"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        <div className="h-64">
          {loading ? (
            <div className="flex justify-center items-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
            </div>
          ) : data.length > 0 ? (
            <Chart data={chartData} options={chartOptions} />
          ) : (
            <div className="flex justify-center items-center h-full">
              <p className="text-gray-500 dark:text-gray-400">No data available</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 flex justify-between items-center">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <Calendar className="h-4 w-4 mr-1" />
          <span>
            {timeRange === '24h' ? 'Last 24 hours' : 
             timeRange === '7d' ? 'Last 7 days' : 
             timeRange === '30d' ? 'Last 30 days' : 'Last 90 days'}
          </span>
        </div>
        <a href="/analytics" className="text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300">
          View detailed analytics →
        </a>
      </div>
    </motion.div>
  );
};

export default MiningPerformanceChart;