"use client";

import { useState, useEffect, useCallback, memo } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  Activity, 
  AlertTriangle, 
  Battery, 
  Bolt, 
  CreditCard, 
  DollarSign, 
  Droplets, 
  Gauge, 
  RefreshCw, 
  Server, 
  Thermometer, 
  Zap 
} from 'lucide-react';

interface MiningStats {
  hashrate: {
    current: number;
    unit: string;
    change: number;
  };
  workers: {
    total: number;
    active: number;
  };
  earnings: {
    daily: number;
    weekly: number;
    monthly: number;
    currency: string;
  };
  power: {
    consumption: number;
    unit: string;
    cost: number;
  };
  temperature: {
    average: number;
    max: number;
    unit: string;
  };
  efficiency: {
    value: number;
    unit: string;
  };
  uptime: {
    percentage: number;
    lastRestart: string;
  };
  shares: {
    accepted: number;
    rejected: number;
    stale: number;
  };
}

interface MiningStatsGridProps {
  initialData?: MiningStats;
}

const MiningStatsGrid = memo(function MiningStatsGrid({ initialData }: MiningStatsGridProps) {
  const [stats, setStats] = useState<MiningStats | null>(initialData || null);
  const [loading, setLoading] = useState<boolean>(!initialData);
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // Fetch stats if not provided
  useEffect(() => {
    if (!initialData) {
      const fetchStats = async () => {
        try {
          setLoading(true);
          // In a real app, this would be an API call
          // For now, we'll simulate with mock data
          const mockData: MiningStats = {
            hashrate: {
              current: 45.7,
              unit: 'TH/s',
              change: 2.3,
            },
            workers: {
              total: 5,
              active: 4,
            },
            earnings: {
              daily: 0.00245,
              weekly: 0.01876,
              monthly: 0.07543,
              currency: 'BTC',
            },
            power: {
              consumption: 1250,
              unit: 'W',
              cost: 3.75, // daily cost in USD
            },
            temperature: {
              average: 65,
              max: 72,
              unit: '°C',
            },
            efficiency: {
              value: 0.0366,
              unit: 'TH/W',
            },
            uptime: {
              percentage: 99.7,
              lastRestart: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(), // 15 days ago
            },
            shares: {
              accepted: 12543,
              rejected: 23,
              stale: 7,
            },
          };
          
          setTimeout(() => {
            setStats(mockData);
            setLoading(false);
          }, 1000);
        } catch (error) {
          console.error('Failed to fetch mining stats:', error);
          setLoading(false);
        }
      };
      
      fetchStats();
    }
  }, [initialData]);

  // Function to animate numbers
  const AnimatedNumber = ({ value, decimals = 0 }: { value: number, decimals?: number }) => {
    const [displayValue, setDisplayValue] = useState(0);
    
    useEffect(() => {
      if (inView) {
        let start = 0;
        const end = value;
        const duration = 1500;
        const startTime = Date.now();
        
        const timer = setInterval(() => {
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          setDisplayValue(progress * end);
          
          if (progress === 1) {
            clearInterval(timer);
          }
        }, 16);
        
        return () => clearInterval(timer);
      }
    }, [value, inView]);
    
    return <>{displayValue.toFixed(decimals)}</>;
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 animate-pulse">
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-4"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 text-center">
        <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">Unable to load mining statistics</h3>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          There was an error loading your mining statistics. Please try again later.
        </p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </button>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Hash Rate',
      value: stats.hashrate.current,
      unit: stats.hashrate.unit,
      change: stats.hashrate.change,
      icon: <Activity className="h-5 w-5 text-indigo-500" />,
      color: 'bg-indigo-50 dark:bg-indigo-900/30',
      decimals: 1
    },
    {
      title: 'Workers',
      value: stats.workers.active,
      unit: `/ ${stats.workers.total} online`,
      icon: <Server className="h-5 w-5 text-blue-500" />,
      color: 'bg-blue-50 dark:bg-blue-900/30',
      decimals: 0
    },
    {
      title: 'Daily Earnings',
      value: stats.earnings.daily,
      unit: stats.earnings.currency,
      icon: <DollarSign className="h-5 w-5 text-green-500" />,
      color: 'bg-green-50 dark:bg-green-900/30',
      decimals: 5
    },
    {
      title: 'Power Consumption',
      value: stats.power.consumption,
      unit: stats.power.unit,
      subtext: `$${stats.power.cost.toFixed(2)}/day`,
      icon: <Bolt className="h-5 w-5 text-amber-500" />,
      color: 'bg-amber-50 dark:bg-amber-900/30',
      decimals: 0
    },
    {
      title: 'Temperature',
      value: stats.temperature.average,
      unit: stats.temperature.unit,
      subtext: `Max: ${stats.temperature.max}${stats.temperature.unit}`,
      icon: <Thermometer className="h-5 w-5 text-red-500" />,
      color: 'bg-red-50 dark:bg-red-900/30',
      decimals: 1
    },
    {
      title: 'Efficiency',
      value: stats.efficiency.value,
      unit: stats.efficiency.unit,
      icon: <Gauge className="h-5 w-5 text-purple-500" />,
      color: 'bg-purple-50 dark:bg-purple-900/30',
      decimals: 4
    },
    {
      title: 'Uptime',
      value: stats.uptime.percentage,
      unit: '%',
      subtext: `Last restart: ${new Date(stats.uptime.lastRestart).toLocaleDateString()}`,
      icon: <Battery className="h-5 w-5 text-teal-500" />,
      color: 'bg-teal-50 dark:bg-teal-900/30',
      decimals: 1
    },
    {
      title: 'Shares',
      value: stats.shares.accepted,
      unit: 'accepted',
      subtext: `${stats.shares.rejected} rejected, ${stats.shares.stale} stale`,
      icon: <CreditCard className="h-5 w-5 text-cyan-500" />,
      color: 'bg-cyan-50 dark:bg-cyan-900/30',
      decimals: 0
    }
  ];

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0 }}
      animate={inView ? { opacity: 1 } : { opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
    >
      {statCards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
        >
          <div className="p-4">
            <div className="flex items-center">
              <div className={`p-2 rounded-lg ${card.color}`}>
                {card.icon}
              </div>
              <h3 className="ml-3 text-sm font-medium text-gray-500 dark:text-gray-400">{card.title}</h3>
            </div>
            <div className="mt-4 flex items-baseline">
              <p className="text-2xl font-semibold text-gray-900 dark:text-white">
                <AnimatedNumber value={card.value} decimals={card.decimals} />
              </p>
              <p className="ml-2 text-sm text-gray-600 dark:text-gray-300">{card.unit}</p>
              
              {card.change !== undefined && (
                <span className={`ml-2 flex items-center text-sm font-medium ${
                  card.change > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {card.change > 0 ? (
                    <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                    </svg>
                  ) : (
                    <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  )}
                  {Math.abs(card.change).toFixed(1)}%
                </span>
              )}
            </div>
            {card.subtext && (
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{card.subtext}</p>
            )}
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
});

export default MiningStatsGrid;