'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { AlertTriangle, CheckCircle, Info, X } from 'lucide-react'

interface Alert {
  id: string
  title: string
  message: string
  severity: 'critical' | 'warning' | 'info'
  timestamp: string
  resolved: boolean
}

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching alerts
    const timer = setTimeout(() => {
      setAlerts([
        {
          id: '1',
          title: 'High Temperature Alert',
          message: 'Mining Rig 03 temperature has exceeded 80°C',
          severity: 'critical',
          timestamp: new Date(Date.now() - 300000).toISOString(),
          resolved: false
        },
        {
          id: '2',
          title: 'Pool Connection Issue',
          message: 'Intermittent connection to mining pool detected',
          severity: 'warning',
          timestamp: new Date(Date.now() - 900000).toISOString(),
          resolved: false
        },
        {
          id: '3',
          title: 'Efficiency Optimization',
          message: 'New optimization profile available for better efficiency',
          severity: 'info',
          timestamp: new Date(Date.now() - 1800000).toISOString(),
          resolved: false
        },
        {
          id: '4',
          title: 'Maintenance Reminder',
          message: 'Scheduled maintenance due for Mining Rig 01',
          severity: 'info',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          resolved: true
        }
      ])
      setLoading(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [])

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-400" />
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-400" />
      case 'info':
        return <Info className="h-4 w-4 text-blue-400" />
      default:
        return <Info className="h-4 w-4 text-blue-400" />
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Badge variant="destructive">Critical</Badge>
      case 'warning':
        return <Badge variant="secondary">Warning</Badge>
      case 'info':
        return <Badge variant="secondary">Info</Badge>
      default:
        return <Badge variant="secondary">{severity}</Badge>
    }
  }

  const resolveAlert = (id: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === id ? { ...alert, resolved: true } : alert
      )
    )
  }

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id))
  }

  const activeAlerts = alerts.filter(alert => !alert.resolved)
  const resolvedAlerts = alerts.filter(alert => alert.resolved)

  if (loading) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-white/20 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                System Alerts
              </CardTitle>
              <CardDescription className="text-white/70">
                {activeAlerts.length} active alerts, {resolvedAlerts.length} resolved
              </CardDescription>
            </div>
            {activeAlerts.length > 0 && (
              <Badge variant="destructive">{activeAlerts.length}</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Active Alerts */}
            {activeAlerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-200"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    {getSeverityIcon(alert.severity)}
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-medium text-white">{alert.title}</h3>
                        {getSeverityBadge(alert.severity)}
                      </div>
                      <p className="text-white/70 text-sm mb-2">{alert.message}</p>
                      <p className="text-white/50 text-xs">
                        {new Date(alert.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => resolveAlert(alert.id)}
                      className="text-green-400 border-green-400/30 hover:bg-green-400/10"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Resolve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => dismissAlert(alert.id)}
                      className="text-red-400 border-red-400/30 hover:bg-red-400/10"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Resolved Alerts */}
            {resolvedAlerts.length > 0 && (
              <div className="border-t border-white/10 pt-4">
                <h4 className="text-white/70 text-sm font-medium mb-3">Recently Resolved</h4>
                {resolvedAlerts.slice(0, 2).map((alert) => (
                  <div
                    key={alert.id}
                    className="p-3 bg-white/5 rounded-lg border border-white/10 opacity-60 mb-2"
                  >
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <div className="flex-1">
                        <h3 className="font-medium text-white text-sm">{alert.title}</h3>
                        <p className="text-white/60 text-xs">
                          Resolved • {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {alerts.length === 0 && (
              <div className="text-center py-8 text-white/60">
                <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-400" />
                <p>No alerts at the moment</p>
                <p className="text-sm">Your mining operation is running smoothly</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}