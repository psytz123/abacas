'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, RefreshCw, DollarSign, Hash, Share2, Coins } from "lucide-react"
import { formatCurrency } from "@/lib/utils"

interface PoolStatsProps {
  workerId?: string
}

export default function PoolStats({ workerId }: PoolStatsProps) {
  const [loading, setLoading] = useState(true)
  const [poolData, setPoolData] = useState({
    poolName: 'Mining Pool Pro',
    hashRate: 1250.5,
    shares: 2847,
    earnings: 0.00234,
    efficiency: 98.2,
    status: 'connected'
  })

  useEffect(() => {
    // Simulate loading pool data
    const timer = setTimeout(() => setLoading(false), 1000)
    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 text-white animate-spin" />
            <span className="text-white ml-2">Loading pool stats...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Share2 className="h-5 w-5 mr-2" />
              Pool Statistics
            </CardTitle>
            <Badge variant={poolData.status === 'connected' ? 'secondary' : 'destructive'}>
              {poolData.status}
            </Badge>
          </div>
          <CardDescription className="text-white/70">
            {poolData.poolName} - Real-time mining pool data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Hash className="h-4 w-4 text-blue-400" />
              <div>
                <p className="text-white/70 text-sm">Pool Hash Rate</p>
                <p className="text-white font-medium">{poolData.hashRate} TH/s</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Coins className="h-4 w-4 text-yellow-400" />
              <div>
                <p className="text-white/70 text-sm">Shares</p>
                <p className="text-white font-medium">{poolData.shares.toLocaleString()}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-green-400" />
              <div>
                <p className="text-white/70 text-sm">Earnings</p>
                <p className="text-white font-medium">{formatCurrency(poolData.earnings)}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <AlertCircle className="h-4 w-4 text-purple-400" />
              <div>
                <p className="text-white/70 text-sm">Efficiency</p>
                <p className="text-white font-medium">{poolData.efficiency}%</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}