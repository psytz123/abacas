'use client'

import { motion } from 'framer-motion'
import { Cpu, Thermometer, Zap, DollarSign, Circle } from 'lucide-react'

interface MinerCardProps {
  miner: {
    id: string
    name: string
    status: string
    hashRate: number
    temperature: number
    power: number
    earnings: number
  }
  index: number
}

export function MinerCard({ miner, index }: MinerCardProps) {
  const isOnline = miner.status === 'online'

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ scale: 1.02, y: -5 }}
      className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${isOnline ? 'bg-green-100 dark:bg-green-900/20' : 'bg-red-100 dark:bg-red-900/20'}`}>
            <Cpu className={`w-5 h-5 ${isOnline ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`} />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white">{miner.name}</h3>
            <div className="flex items-center space-x-1">
              <Circle className={`w-2 h-2 ${isOnline ? 'text-green-500 fill-current' : 'text-red-500 fill-current'}`} />
              <span className={`text-xs ${isOnline ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                {isOnline ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Zap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span className="text-xs text-blue-600 dark:text-blue-400 font-medium">Hash Rate</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {miner.hashRate.toFixed(1)} TH/s
          </p>
        </div>

        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Thermometer className="w-4 h-4 text-orange-600 dark:text-orange-400" />
            <span className="text-xs text-orange-600 dark:text-orange-400 font-medium">Temp</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {miner.temperature.toFixed(0)}°C
          </p>
        </div>

        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Zap className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span className="text-xs text-purple-600 dark:text-purple-400 font-medium">Power</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {miner.power.toFixed(0)} W
          </p>
        </div>

        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3">
          <div className="flex items-center space-x-2 mb-1">
            <DollarSign className="w-4 h-4 text-green-600 dark:text-green-400" />
            <span className="text-xs text-green-600 dark:text-green-400 font-medium">Earnings</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            ${miner.earnings.toFixed(2)}
          </p>
        </div>
      </div>
    </motion.div>
  )
}