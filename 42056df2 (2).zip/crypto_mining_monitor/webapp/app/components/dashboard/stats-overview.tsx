'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Activity, 
  Zap, 
  DollarSign, 
  Cpu, 
  TrendingUp, 
  TrendingDown,
  Thermometer,
  Clock
} from 'lucide-react'

interface StatsData {
  totalHashRate: number
  totalPower: number
  totalEarnings: number
  activeMiners: number
  efficiency: number
  avgTemperature: number
  uptime: number
  trends: {
    hashRate: number
    power: number
    earnings: number
    efficiency: number
  }
}

export default function StatsOverview() {
  const [stats, setStats] = useState<StatsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching stats
    const timer = setTimeout(() => {
      setStats({
        totalHashRate: 1250.5,
        totalPower: 8500,
        totalEarnings: 2847.32,
        activeMiners: 12,
        efficiency: 92.3,
        avgTemperature: 65.2,
        uptime: 99.2,
        trends: {
          hashRate: 3.2,
          power: -1.5,
          earnings: 12.5,
          efficiency: 2.1
        }
      })
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const formatHashRate = (value: number) => {
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)} TH/s`
    }
    return `${value.toFixed(1)} GH/s`
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value)
  }

  const getTrendIcon = (trend: number) => {
    if (trend > 0) {
      return <TrendingUp className="h-4 w-4 text-green-400" />
    } else if (trend < 0) {
      return <TrendingDown className="h-4 w-4 text-red-400" />
    }
    return null
  }

  const getTrendColor = (trend: number) => {
    if (trend > 0) return 'text-green-400'
    if (trend < 0) return 'text-red-400'
    return 'text-white/70'
  }

  if (loading || !stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(8)].map((_, i) => (
          <Card key={i} className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-white/20 rounded mb-2"></div>
                <div className="h-8 bg-white/20 rounded mb-2"></div>
                <div className="h-3 bg-white/20 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const statCards = [
    {
      title: 'Total Hash Rate',
      value: formatHashRate(stats.totalHashRate),
      trend: stats.trends.hashRate,
      icon: Activity,
      color: 'text-blue-400'
    },
    {
      title: 'Total Power',
      value: `${stats.totalPower.toLocaleString()} W`,
      trend: stats.trends.power,
      icon: Zap,
      color: 'text-yellow-400'
    },
    {
      title: 'Total Earnings',
      value: formatCurrency(stats.totalEarnings),
      trend: stats.trends.earnings,
      icon: DollarSign,
      color: 'text-green-400'
    },
    {
      title: 'Active Miners',
      value: stats.activeMiners.toString(),
      trend: 0,
      icon: Cpu,
      color: 'text-purple-400'
    },
    {
      title: 'Efficiency',
      value: `${stats.efficiency.toFixed(1)}%`,
      trend: stats.trends.efficiency,
      icon: TrendingUp,
      color: 'text-emerald-400'
    },
    {
      title: 'Avg Temperature',
      value: `${stats.avgTemperature.toFixed(1)}°C`,
      trend: 0,
      icon: Thermometer,
      color: 'text-red-400'
    },
    {
      title: 'Uptime',
      value: `${stats.uptime.toFixed(1)}%`,
      trend: 0,
      icon: Clock,
      color: 'text-indigo-400'
    },
    {
      title: 'Performance Score',
      value: '95/100',
      trend: 1.2,
      icon: TrendingUp,
      color: 'text-cyan-400'
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          whileHover={{ scale: 1.02 }}
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-white/70 text-sm font-medium">{stat.title}</p>
                  <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
                  {stat.trend !== 0 && (
                    <div className={`flex items-center space-x-1 mt-2 ${getTrendColor(stat.trend)}`}>
                      {getTrendIcon(stat.trend)}
                      <span className="text-sm">
                        {stat.trend > 0 ? '+' : ''}{stat.trend.toFixed(1)}%
                      </span>
                    </div>
                  )}
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}