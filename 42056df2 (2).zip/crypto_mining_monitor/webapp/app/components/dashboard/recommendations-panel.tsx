"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, Info, Settings, TrendingUp, Zap } from 'lucide-react';
import { useInView } from 'react-intersection-observer';

// Define proper types for recommendations
export interface Recommendation {
  id: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  type: 'optimization' | 'security' | 'maintenance';
  actionUrl?: string;
  actionText?: string;
  dismissed?: boolean;
}

export interface RecommendationsData {
  recommendations: {
    optimization?: Recommendation[];
    security?: Recommendation[];
    maintenance?: Recommendation[];
  };
  lastUpdated: string;
}

interface RecommendationsPanelProps {
  initialData?: RecommendationsData;
}

const RecommendationsPanel: React.FC<RecommendationsPanelProps> = ({ initialData }) => {
  const [recommendations, setRecommendations] = useState<RecommendationsData>(initialData || {
    recommendations: {},
    lastUpdated: new Date().toISOString()
  });
  const [activeType, setActiveType] = useState<'optimization' | 'security' | 'maintenance'>('optimization');
  const [loading, setLoading] = useState<boolean>(!initialData);
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // Safely get the count of recommendations by type
  const getRecommendationCount = (type: 'optimization' | 'security' | 'maintenance'): number => {
    return Array.isArray(recommendations.recommendations[type]) 
      ? recommendations.recommendations[type]?.length || 0 
      : 0;
  };

  // Fetch recommendations if not provided
  useEffect(() => {
    if (!initialData) {
      const fetchRecommendations = async () => {
        try {
          setLoading(true);
          // In a real app, this would be an API call
          // For now, we'll simulate with mock data
          const mockData: RecommendationsData = {
            recommendations: {
              optimization: [
                {
                  id: 'opt-1',
                  title: 'Increase mining efficiency',
                  description: 'Adjust your overclocking settings to improve hash rate while maintaining power efficiency.',
                  impact: 'high',
                  type: 'optimization',
                  actionUrl: '/settings/overclocking',
                  actionText: 'Adjust Settings'
                },
                {
                  id: 'opt-2',
                  title: 'Update mining software',
                  description: 'A new version of mining software is available with 5% performance improvements.',
                  impact: 'medium',
                  type: 'optimization',
                  actionUrl: '/settings/software',
                  actionText: 'Update Now'
                }
              ],
              security: [
                {
                  id: 'sec-1',
                  title: 'Enable 2FA authentication',
                  description: 'Protect your mining account with two-factor authentication.',
                  impact: 'high',
                  type: 'security',
                  actionUrl: '/settings/security',
                  actionText: 'Enable 2FA'
                }
              ],
              maintenance: [
                {
                  id: 'maint-1',
                  title: 'Clean cooling system',
                  description: 'Your mining rigs are running hot. Consider cleaning the cooling system.',
                  impact: 'medium',
                  type: 'maintenance',
                  actionUrl: '/maintenance/cooling',
                  actionText: 'View Guide'
                },
                {
                  id: 'maint-2',
                  title: 'Replace thermal paste',
                  description: 'It\'s been 6 months since your last thermal paste replacement.',
                  impact: 'low',
                  type: 'maintenance',
                  actionUrl: '/maintenance/thermal',
                  actionText: 'View Guide'
                }
              ]
            },
            lastUpdated: new Date().toISOString()
          };
          
          setTimeout(() => {
            setRecommendations(mockData);
            setLoading(false);
          }, 1000);
        } catch (error) {
          console.error('Failed to fetch recommendations:', error);
          setLoading(false);
        }
      };
      
      fetchRecommendations();
    }
  }, [initialData]);

  const dismissRecommendation = (id: string) => {
    setRecommendations(prev => {
      const newRecommendations = { ...prev };
      
      // Find and update the recommendation in all categories
      Object.keys(newRecommendations.recommendations).forEach(key => {
        const type = key as 'optimization' | 'security' | 'maintenance';
        if (Array.isArray(newRecommendations.recommendations[type])) {
          newRecommendations.recommendations[type] = newRecommendations.recommendations[type]?.map(rec => 
            rec.id === id ? { ...rec, dismissed: true } : rec
          );
        }
      });
      
      return newRecommendations;
    });
  };

  const getIconForType = (type: 'optimization' | 'security' | 'maintenance') => {
    switch (type) {
      case 'optimization':
        return <TrendingUp className="h-5 w-5" />;
      case 'security':
        return <AlertTriangle className="h-5 w-5" />;
      case 'maintenance':
        return <Settings className="h-5 w-5" />;
      default:
        return <Info className="h-5 w-5" />;
    }
  };

  const getIconForImpact = (impact: 'high' | 'medium' | 'low') => {
    switch (impact) {
      case 'high':
        return <Zap className="h-4 w-4 text-amber-500" />;
      case 'medium':
        return <Info className="h-4 w-4 text-blue-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
    >
      <div className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <h2 className="text-xl font-bold flex items-center">
          <Zap className="mr-2 h-5 w-5" />
          Mining Recommendations
        </h2>
        <p className="text-sm opacity-80">
          Optimize your mining operation with these personalized recommendations
        </p>
      </div>
      
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex -mb-px">
          {['optimization', 'security', 'maintenance'].map((type) => (
            <button
              key={type}
              onClick={() => setActiveType(type as 'optimization' | 'security' | 'maintenance')}
              className={`flex-1 py-4 px-1 text-center border-b-2 font-medium text-sm ${
                activeType === type
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              <div className="flex items-center justify-center">
                {getIconForType(type as 'optimization' | 'security' | 'maintenance')}
                <span className="ml-2 capitalize">{type}</span>
                {getRecommendationCount(type as 'optimization' | 'security' | 'maintenance') > 0 && (
                  <span className="ml-2 bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300 text-xs rounded-full px-2 py-0.5">
                    {getRecommendationCount(type as 'optimization' | 'security' | 'maintenance')}
                  </span>
                )}
              </div>
            </button>
          ))}
        </nav>
      </div>
      
      <div className="p-4">
        {loading ? (
          <div className="flex justify-center items-center h-48">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <>
            {Array.isArray(recommendations.recommendations[activeType]) && 
             recommendations.recommendations[activeType]?.length ? (
              <div className="space-y-4">
                {recommendations.recommendations[activeType]
                  ?.filter(rec => !rec.dismissed)
                  .map((recommendation, index) => (
                    <motion.div
                      key={recommendation.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-start">
                          <div className="mr-3 mt-0.5">
                            {getIconForImpact(recommendation.impact)}
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900 dark:text-white">{recommendation.title}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{recommendation.description}</p>
                            {recommendation.actionUrl && recommendation.actionText && (
                              <a
                                href={recommendation.actionUrl}
                                className="inline-flex items-center mt-3 px-3 py-1.5 text-xs font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 transition-colors"
                              >
                                {recommendation.actionText}
                              </a>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => dismissRecommendation(recommendation.id)}
                          className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
                          aria-label="Dismiss"
                        >
                          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    </motion.div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="mx-auto h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">All caught up!</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  No {activeType} recommendations at this time.
                </p>
              </div>
            )}
          </>
        )}
      </div>
      
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right">
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Last updated: {new Date(recommendations.lastUpdated).toLocaleString()}
        </p>
      </div>
    </motion.div>
  );
};

export default RecommendationsPanel;