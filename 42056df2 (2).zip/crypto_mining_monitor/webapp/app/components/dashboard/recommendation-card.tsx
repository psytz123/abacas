'use client'

import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Lightbulb, CheckCircle, X } from 'lucide-react'

interface RecommendationCardProps {
  recommendation: {
    id: string
    title: string
    description: string
    type: string
    status: string
    urgency: string
    impact: string
  }
  onAccept?: (id: string) => void
  onDismiss?: (id: string) => void
}

export default function RecommendationCard({ recommendation, onAccept, onDismiss }: RecommendationCardProps) {
  const getTypeBadge = (type: string) => {
    switch (type.toLowerCase()) {
      case "hardware":
        return <Badge variant="secondary">Hardware</Badge>
      case "software":
        return <Badge variant="secondary">Software</Badge>
      case "pool":
        return <Badge variant="secondary">Pool</Badge>
      case "thermal":
        return <Badge variant="secondary">Thermal</Badge>
      default:
        return <Badge>{type}</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "new":
        return <Badge variant="secondary">New</Badge>
      case "implemented":
        return <Badge variant="secondary">Implemented</Badge>
      case "dismissed":
        return <Badge variant="secondary">Dismissed</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency.toLowerCase()) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge variant="secondary">Medium</Badge>;
      case 'low':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge>{urgency}</Badge>;
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white text-lg flex items-center">
              <Lightbulb className="h-5 w-5 mr-2" />
              {recommendation.title}
            </CardTitle>
            <div className="flex space-x-2">
              {getTypeBadge(recommendation.type)}
              {getStatusBadge(recommendation.status)}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-white/70 mb-4">
            {recommendation.description}
          </CardDescription>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex space-x-4">
              <div>
                <span className="text-white/60 text-sm">Urgency:</span>
                {getUrgencyBadge(recommendation.urgency)}
              </div>
              <div>
                <span className="text-white/60 text-sm">Impact:</span>
                <span className="text-white ml-2">{recommendation.impact}</span>
              </div>
            </div>
          </div>

          {recommendation.status === 'new' && (
            <div className="flex space-x-2">
              {onAccept && (
                <Button
                  onClick={() => onAccept(recommendation.id)}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Accept
                </Button>
              )}
              {onDismiss && (
                <Button
                  onClick={() => onDismiss(recommendation.id)}
                  variant="destructive"
                  size="sm"
                >
                  <X className="h-4 w-4 mr-1" />
                  Dismiss
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}