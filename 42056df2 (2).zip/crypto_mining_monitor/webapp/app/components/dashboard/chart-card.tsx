'use client'

import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { TrendingUp, TrendingDown } from 'lucide-react'

interface ChartCardProps {
  title: string
  description?: string
  value: string
  change?: string
  trend?: 'up' | 'down' | 'neutral'
  icon?: React.ReactNode
  children?: React.ReactNode
}

export function ChartCard({ 
  title, 
  description, 
  value, 
  change, 
  trend = 'neutral', 
  icon,
  children 
}: ChartCardProps) {
  const getTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-green-400" />
      case 'down':
        return <TrendingDown className="h-4 w-4 text-red-400" />
      default:
        return null
    }
  }

  const getTrendColor = () => {
    switch (trend) {
      case 'up':
        return 'text-green-400'
      case 'down':
        return 'text-red-400'
      default:
        return 'text-white/70'
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {icon}
              <CardTitle className="text-white text-lg">{title}</CardTitle>
            </div>
            {getTrendIcon()}
          </div>
          {description && (
            <CardDescription className="text-white/70">
              {description}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="text-2xl font-bold text-white">{value}</div>
            {change && (
              <div className={`text-sm flex items-center space-x-1 ${getTrendColor()}`}>
                <span>{change}</span>
              </div>
            )}
          </div>
          {children && (
            <div className="mt-4">
              {children}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}