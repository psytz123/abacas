'use client'

import { motion } from 'framer-motion'
import { Cpu, Zap, Thermometer, Clock } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatHashRate, formatPower, formatUptime } from '@/lib/utils'

interface MinerStatusCardProps {
  miner: {
    id: string
    name: string
    status: string
    hashRate: number
    temperature: number
    power: number
    uptime: number
  }
}

export default function MinerStatusCard({ miner }: MinerStatusCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "online":
        return <Badge variant="secondary">Online</Badge>
      case "offline":
        return <Badge variant="destructive">Offline</Badge>
      case "warning":
        return <Badge variant="secondary">Warning</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="w-full"
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white text-lg flex items-center">
              <Cpu className="h-5 w-5 mr-2" />
              {miner.name}
            </CardTitle>
            {getStatusBadge(miner.status)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Cpu className="h-4 w-4 text-blue-400" />
              <div>
                <p className="text-white/70 text-sm">Hash Rate</p>
                <p className="text-white font-medium">{formatHashRate(miner.hashRate)}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Thermometer className="h-4 w-4 text-red-400" />
              <div>
                <p className="text-white/70 text-sm">Temperature</p>
                <p className="text-white font-medium">{miner.temperature.toFixed(1)}°C</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-yellow-400" />
              <div>
                <p className="text-white/70 text-sm">Power</p>
                <p className="text-white font-medium">{formatPower(miner.power)}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-green-400" />
              <div>
                <p className="text-white/70 text-sm">Uptime</p>
                <p className="text-white font-medium">{formatUptime(miner.uptime)}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}