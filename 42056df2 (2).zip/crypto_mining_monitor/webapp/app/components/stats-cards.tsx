'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Zap, 
  Cpu, 
  DollarSign, 
  Thermometer,
  TrendingUp,
  Activity
} from 'lucide-react'

interface StatsCardsProps {
  filters: any
}

export default function StatsCards({ filters }: StatsCardsProps) {
  const [stats, setStats] = useState({
    totalHashrate: 0,
    activeRigs: 0,
    totalRevenue: 0,
    avgTemperature: 0,
    efficiency: 0,
    uptime: 0
  })

  const [animatedStats, setAnimatedStats] = useState({
    totalHashrate: 0,
    activeRigs: 0,
    totalRevenue: 0,
    avgTemperature: 0,
    efficiency: 0,
    uptime: 0
  })

  useEffect(() => {
    // Simulate fetching stats based on filters
    const fetchStats = () => {
      const newStats = {
        totalHashrate: 1247.5,
        activeRigs: 24,
        totalRevenue: 15420.75,
        avgTemperature: 68.5,
        efficiency: 95.2,
        uptime: 99.8
      }
      setStats(newStats)
    }

    fetchStats()
  }, [filters])

  useEffect(() => {
    // Animate numbers
    const duration = 2000
    const steps = 60
    const stepDuration = duration / steps

    Object.keys(stats).forEach((key) => {
      const start = animatedStats[key as keyof typeof stats]
      const end = stats[key as keyof typeof stats]
      const increment = (end - start) / steps

      let currentStep = 0
      const timer = setInterval(() => {
        currentStep++
        setAnimatedStats(prev => ({
          ...prev,
          [key]: start + (increment * currentStep)
        }))

        if (currentStep >= steps) {
          clearInterval(timer)
          setAnimatedStats(prev => ({
            ...prev,
            [key]: end
          }))
        }
      }, stepDuration)
    })
  }, [stats])

  const cards = [
    {
      title: 'Total Hashrate',
      value: `${animatedStats.totalHashrate.toFixed(1)} TH/s`,
      icon: Zap,
      color: 'from-blue-500 to-blue-600',
      change: '+12.5%',
      changeType: 'positive'
    },
    {
      title: 'Active Rigs',
      value: Math.round(animatedStats.activeRigs).toString(),
      icon: Cpu,
      color: 'from-green-500 to-green-600',
      change: '+2',
      changeType: 'positive'
    },
    {
      title: 'Total Revenue',
      value: `$${animatedStats.totalRevenue.toFixed(2)}`,
      icon: DollarSign,
      color: 'from-yellow-500 to-yellow-600',
      change: '+8.3%',
      changeType: 'positive'
    },
    {
      title: 'Avg Temperature',
      value: `${animatedStats.avgTemperature.toFixed(1)}°C`,
      icon: Thermometer,
      color: 'from-red-500 to-red-600',
      change: '-2.1°C',
      changeType: 'positive'
    },
    {
      title: 'Efficiency',
      value: `${animatedStats.efficiency.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600',
      change: '+1.2%',
      changeType: 'positive'
    },
    {
      title: 'Uptime',
      value: `${animatedStats.uptime.toFixed(1)}%`,
      icon: Activity,
      color: 'from-indigo-500 to-indigo-600',
      change: '+0.3%',
      changeType: 'positive'
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          whileHover={{ 
            scale: 1.02,
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
          }}
          className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 hover:shadow-xl transition-all duration-300"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-lg bg-gradient-to-r ${card.color}`}>
              <card.icon className="h-6 w-6 text-white" />
            </div>
            <div className={`text-sm font-medium ${
              card.changeType === 'positive' 
                ? 'text-green-600 dark:text-green-400' 
                : 'text-red-600 dark:text-red-400'
            }`}>
              {card.change}
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
              {card.title}
            </h3>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {card.value}
            </p>
          </div>
        </motion.div>
      ))}
    </div>
  )
}