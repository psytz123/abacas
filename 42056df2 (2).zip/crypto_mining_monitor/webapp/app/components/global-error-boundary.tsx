'use client';

import React from 'react';
import ErrorBoundary from './error-boundary';

/**
 * Global Error Boundary component to wrap the entire application
 * This ensures that errors in any part of the application are caught and handled gracefully
 */
export default function GlobalErrorBoundary({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ErrorBoundary
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
          <div className="max-w-md w-full p-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
              Application Error
            </h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6">
              We're sorry, but something went wrong. Our team has been notified and is working to fix the issue.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full px-4 py-2 text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
            >
              Reload Application
            </button>
          </div>
        </div>
      }
    >
      {children}
    </ErrorBoundary>
  );
}