'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  AlertTriangle, 
  Thermometer, 
  Zap, 
  Wifi,
  Clock,
  X
} from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    // Generate sample alerts
    const sampleAlerts = [
      {
        id: '1',
        type: 'temperature',
        severity: 'high',
        message: 'High temperature detected on Rig #002',
        rigId: '2',
        timestamp: new Date(Date.now() - 1000 * 60 * 15),
        resolved: false
      },
      {
        id: '2',
        type: 'hashrate',
        severity: 'medium',
        message: 'Hashrate drop on Rig #005',
        rigId: '5',
        timestamp: new Date(Date.now() - 1000 * 60 * 45),
        resolved: false
      },
      {
        id: '3',
        type: 'offline',
        severity: 'critical',
        message: 'Rig #003 went offline',
        rigId: '3',
        timestamp: new Date(Date.now() - 1000 * 60 * 120),
        resolved: false
      },
      {
        id: '4',
        type: 'power',
        severity: 'low',
        message: 'Power consumption spike on Rig #001',
        rigId: '1',
        timestamp: new Date(Date.now() - 1000 * 60 * 180),
        resolved: true
      }
    ]

    setAlerts(sampleAlerts)
  }, [])

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'temperature':
        return Thermometer
      case 'hashrate':
        return Zap
      case 'offline':
        return Wifi
      case 'power':
        return Zap
      default:
        return AlertTriangle
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400'
      case 'high':
        return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20 dark:text-orange-400'
      case 'medium':
        return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400'
      case 'low':
        return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400'
      default:
        return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20 dark:text-gray-400'
    }
  }

  const resolveAlert = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, resolved: true } : alert
    ))
  }

  const dismissAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId))
  }

  const activeAlerts = alerts.filter(alert => !alert.resolved)
  const resolvedAlerts = alerts.filter(alert => alert.resolved)

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700"
    >
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Alerts
          </h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {activeAlerts.length} active
            </span>
            {activeAlerts.length > 0 && (
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            )}
          </div>
        </div>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {activeAlerts.length === 0 && resolvedAlerts.length === 0 ? (
          <div className="p-6 text-center">
            <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">No alerts</p>
          </div>
        ) : (
          <div className="space-y-1">
            {activeAlerts.map((alert, index) => {
              const IconComponent = getAlertIcon(alert.type)
              return (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="p-4 border-l-4 border-red-500 bg-red-50 dark:bg-red-900/10 hover:bg-red-100 dark:hover:bg-red-900/20 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <IconComponent className="h-5 w-5 text-red-600 dark:text-red-400 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(alert.severity)}`}>
                            {alert.severity}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {alert.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-900 dark:text-white">
                          {alert.message}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 ml-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => resolveAlert(alert.id)}
                        className="text-green-600 hover:text-green-700 hover:bg-green-100 dark:hover:bg-green-900/20"
                      >
                        Resolve
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => dismissAlert(alert.id)}
                        className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )
            })}

            {resolvedAlerts.map((alert, index) => {
              const IconComponent = getAlertIcon(alert.type)
              return (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: (activeAlerts.length + index) * 0.1 }}
                  className="p-4 border-l-4 border-green-500 bg-green-50 dark:bg-green-900/10 opacity-75"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <IconComponent className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                            resolved
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {alert.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          {alert.message}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => dismissAlert(alert.id)}
                      className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}
      </div>
    </motion.div>
  )
}