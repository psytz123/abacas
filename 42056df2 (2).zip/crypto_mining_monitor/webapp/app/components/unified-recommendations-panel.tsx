'use client';

import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Coins, 
  AlertTriangle, 
  Settings, 
  TrendingUp, 
  Zap,
  RefreshCw,
  CheckCircle,
  Info
} from 'lucide-react';
import { useRecommendations } from '@/lib/hooks/use-recommendations';
import { RecommendationCard } from '@/components/recommendations/recommendation-card';

// Define types for different recommendation types
export interface Recommendation {
  id: string;
  type: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence?: number;
  metadata?: Record<string, any>;
  createdAt?: string;
  status?: 'pending' | 'applied' | 'rejected' | 'in_progress';
  actionUrl?: string;
  actionText?: string;
  dismissed?: boolean;
}

interface UnifiedRecommendationsPanelProps {
  initialData?: {
    recommendations: Record<string, Recommendation[]>;
    lastUpdated: string;
  };
  simplified?: boolean;
}

export function UnifiedRecommendationsPanel({ initialData, simplified = false }: UnifiedRecommendationsPanelProps) {
  const [activeTab, setActiveTab] = useState<string>('optimization');
  const { recommendations, isLoading, error, refresh, recommendationCounts } = useRecommendations();
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  // Use either fetched recommendations or initial data
  const recommendationsData = useMemo(() => {
    if (recommendations) return recommendations;
    if (initialData) return initialData;
    return { recommendations: {}, lastUpdated: new Date().toISOString() };
  }, [recommendations, initialData]);
  
  const handleFeedback = async (id: string, type: string, details?: string) => {
    try {
      const response = await fetch('/api/recommendations/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recommendationId: id,
          helpful: type === 'helpful',
          comment: details,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }
      
      // Refresh recommendations after feedback
      refresh();
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };
  
  const getRecommendationsForType = (type: string) => {
    if (!recommendationsData || !recommendationsData.recommendations) {
      return [];
    }
    
    return recommendationsData.recommendations[type] || [];
  };
  
  const getIconForType = (type: string) => {
    switch (type) {
      case 'optimization':
        return <TrendingUp className="h-5 w-5" />;
      case 'security':
        return <AlertTriangle className="h-5 w-5" />;
      case 'maintenance':
        return <Settings className="h-5 w-5" />;
      case 'performance':
        return <Zap className="h-5 w-5" />;
      case 'cost':
        return <Coins className="h-5 w-5" />;
      default:
        return null;
    }
  };
  
  const getIconForImpact = (impact: 'high' | 'medium' | 'low') => {
    switch (impact) {
      case 'high':
        return <Zap className="h-4 w-4 text-amber-500" />;
      case 'medium':
        return <Info className="h-4 w-4 text-blue-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-500" />;
    }
  };
  
  // Available recommendation types
  const recommendationTypes = ['optimization', 'security', 'maintenance', 'performance', 'cost'];
  
  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
    >
      <div className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold flex items-center">
            <Zap className="mr-2 h-5 w-5" />
            Mining Recommendations
          </h2>
          <p className="text-sm opacity-80">
            Optimize your mining operation with these personalized recommendations
          </p>
        </div>
        {!simplified && (
          <button 
            onClick={refresh}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            aria-label="Refresh recommendations"
          >
            <RefreshCw className="h-5 w-5" />
          </button>
        )}
      </div>
      
      <Tabs defaultValue="optimization" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full border-b border-gray-200 dark:border-gray-700 px-4">
          {recommendationTypes.map((type) => (
            <TabsTrigger 
              key={type} 
              value={type}
              className="flex-1 py-3"
            >
              <div className="flex items-center">
                {getIconForType(type)}
                <span className="ml-2 capitalize">{type}</span>
                {getRecommendationsForType(type).length > 0 && (
                  <span className="ml-2 bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300 text-xs rounded-full px-2 py-0.5">
                    {getRecommendationsForType(type).length}
                  </span>
                )}
              </div>
            </TabsTrigger>
          ))}
        </TabsList>
        
        {recommendationTypes.map((type) => (
          <TabsContent key={type} value={type} className="p-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-48">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
              </div>
            ) : error ? (
              <div className="text-center py-8">
                <AlertTriangle className="mx-auto h-12 w-12 text-amber-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">Error loading recommendations</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  {error.message || 'Failed to load recommendations. Please try again.'}
                </p>
                <button 
                  onClick={refresh}
                  className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </button>
              </div>
            ) : getRecommendationsForType(type).length > 0 ? (
              <div className="space-y-4">
                {getRecommendationsForType(type).map((rec: Recommendation, index) => (
                  <RecommendationCard 
                    key={rec.id} 
                    recommendation={{
                      id: rec.id,
                      type: rec.type,
                      title: rec.title,
                      description: rec.description,
                      impact: rec.impact,
                      confidence: rec.confidence || 0.8,
                      metadata: rec.metadata || {},
                      actionText: rec.actionText || 'Apply Recommendation',
                      actionUrl: rec.actionUrl || `/recommendations/${rec.id}/apply`
                    }} 
                    onFeedback={!simplified ? handleFeedback : undefined} 
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="mx-auto h-12 w-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">All caught up!</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  No {type} recommendations at this time.
                </p>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
      
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right">
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Last updated: {recommendationsData?.lastUpdated ? new Date(recommendationsData.lastUpdated).toLocaleString() : 'Never'}
        </p>
      </div>
    </motion.div>
  );
}

// Export as default as well for convenience
export default UnifiedRecommendationsPanel;