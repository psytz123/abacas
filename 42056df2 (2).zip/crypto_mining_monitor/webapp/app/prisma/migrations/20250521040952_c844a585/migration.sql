-- CreateTable
CREATE TABLE "Miner" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "ipAddress" TEXT NOT NULL,
    "model" TEXT NOT NULL,
    "firmwareVersion" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'online',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Miner_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Telemetry" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hashrate" DOUBLE PRECISION NOT NULL,
    "hashrateUnit" TEXT NOT NULL DEFAULT 'TH/s',
    "temperature" DOUBLE PRECISION NOT NULL,
    "fanSpeed" DOUBLE PRECISION NOT NULL,
    "powerConsumption" DOUBLE PRECISION NOT NULL,
    "efficiency" DOUBLE PRECISION NOT NULL,
    "acceptedShares" INTEGER NOT NULL,
    "rejectedShares" INTEGER NOT NULL,
    "uptime" INTEGER NOT NULL,
    "minerId" TEXT NOT NULL,

    CONSTRAINT "Telemetry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MiningPool" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "algorithm" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MiningPool_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PoolPerformance" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reportedHashrate" DOUBLE PRECISION NOT NULL,
    "effectiveHashrate" DOUBLE PRECISION NOT NULL,
    "hashrateUnit" TEXT NOT NULL DEFAULT 'TH/s',
    "acceptedShares" INTEGER NOT NULL,
    "rejectedShares" INTEGER NOT NULL,
    "earnings" DOUBLE PRECISION NOT NULL,
    "earningsCurrency" TEXT NOT NULL DEFAULT 'USD',
    "poolId" TEXT NOT NULL,

    CONSTRAINT "PoolPerformance_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CoinMined" (
    "id" TEXT NOT NULL,
    "coinSymbol" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "usdValue" DOUBLE PRECISION NOT NULL,
    "miningType" TEXT NOT NULL,
    "performanceId" TEXT NOT NULL,

    CONSTRAINT "CoinMined_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MarketData" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "coinId" TEXT NOT NULL,
    "coinSymbol" TEXT NOT NULL,
    "coinName" TEXT NOT NULL,
    "priceUsd" DOUBLE PRECISION NOT NULL,
    "priceBtc" DOUBLE PRECISION NOT NULL,
    "marketCapUsd" DOUBLE PRECISION NOT NULL,
    "volume24h" DOUBLE PRECISION NOT NULL,
    "priceChange1h" DOUBLE PRECISION NOT NULL,
    "priceChange24h" DOUBLE PRECISION NOT NULL,
    "priceChange7d" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "MarketData_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Alert" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "severity" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "minerId" TEXT,

    CONSTRAINT "Alert_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Recommendation" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "type" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "potentialImpact" DOUBLE PRECISION NOT NULL,
    "confidence" DOUBLE PRECISION NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'new',

    CONSTRAINT "Recommendation_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "Telemetry" ADD CONSTRAINT "Telemetry_minerId_fkey" FOREIGN KEY ("minerId") REFERENCES "Miner"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PoolPerformance" ADD CONSTRAINT "PoolPerformance_poolId_fkey" FOREIGN KEY ("poolId") REFERENCES "MiningPool"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CoinMined" ADD CONSTRAINT "CoinMined_performanceId_fkey" FOREIGN KEY ("performanceId") REFERENCES "PoolPerformance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_minerId_fkey" FOREIGN KEY ("minerId") REFERENCES "Miner"("id") ON DELETE SET NULL ON UPDATE CASCADE;
