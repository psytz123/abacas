-- DropForeignKey
ALTER TABLE "Alert" DROP CONSTRAINT "Alert_minerId_fkey";

-- DropForeignKey
ALTER TABLE "ApiKey" DROP CONSTRAINT "ApiKey_userId_fkey";

-- DropForeignKey
ALTER TABLE "CoinMined" DROP CONSTRAINT "CoinMined_performanceId_fkey";

-- DropForeignKey
ALTER TABLE "PoolPerformance" DROP CONSTRAINT "PoolPerformance_poolId_fkey";

-- DropForeignKey
ALTER TABLE "Telemetry" DROP CONSTRAINT "Telemetry_minerId_fkey";

-- DropForeignKey
ALTER TABLE "Worker" DROP CONSTRAINT "Worker_userId_fkey";

-- DropTable
DROP TABLE "Alert";

-- DropTable
DROP TABLE "ApiKey";

-- DropTable
DROP TABLE "CoinMined";

-- DropTable
DROP TABLE "MarketData";

-- DropTable
DROP TABLE "Miner";

-- DropTable
DROP TABLE "MiningPool";

-- DropTable
DROP TABLE "MiningStats";

-- DropTable
DROP TABLE "PoolPerformance";

-- DropTable
DROP TABLE "Recommendation";

-- DropTable
DROP TABLE "Telemetry";

-- DropTable
DROP TABLE "User";

-- DropTable
DROP TABLE "Worker";

-- CreateTable
CREATE TABLE "workers" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "ipAddress" TEXT NOT NULL,
    "port" INTEGER NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'offline',
    "hashRate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "temperature" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "power" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "uptime" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "workers_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "workers" ADD CONSTRAINT "workers_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

