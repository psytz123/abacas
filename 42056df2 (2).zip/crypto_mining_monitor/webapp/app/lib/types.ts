/**
 * Common type definitions for the cryptocurrency mining monitoring system
 */

// Mining data types
export interface MiningData {
  timestamp: string;
  hashRate: number;
  power: number;
  temperature: number;
  earnings: number;
}

export interface ProfitabilityData {
  coin: string;
  algorithm: string;
  hashRate: number;
  power: number;
  dailyEarnings: number;
  profitability: number;
}

export interface HistoricalData {
  timestamp: string;
  value: number;
}

// Dashboard summary types
export interface DashboardSummary {
  totalHashrate: number;
  activeRigs: number;
  totalRevenue: number;
  avgTemperature: number;
  efficiency: number;
  uptime: number;
  timestamp: string;
}

// Miner types
export interface Miner {
  id: string;
  name: string;
  model: string;
  status: 'online' | 'offline' | 'error' | 'maintenance';
  hashRate: number;
  power: number;
  temperature: number;
  efficiency: number;
  earnings: number;
  lastSeen: string;
  ipAddress?: string;
  macAddress?: string;
  firmwareVersion?: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

// Worker types
export interface Worker {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'error';
  hashrate: number;
  lastSeen: string;
  acceptedShares: number;
  rejectedShares: number;
  temperature?: number;
  powerConsumption?: number;
  minerId?: string;
  userId: string;
}

// Pool statistics types
export interface PoolStats {
  hashrate: number;
  miners: number;
  workers: number;
  fee: number;
  lastBlockFound: string;
  coins: Record<string, {
    hashrate: number;
    miners: number;
    lastBlockFound: string;
    currentDifficulty: number;
  }>;
}

// Profitability types
export interface Profitability {
  daily: number;
  weekly: number;
  monthly: number;
  currency: string;
  fiatValue: {
    daily: number;
    weekly: number;
    monthly: number;
    currency: string;
  };
  coins: Record<string, {
    hashrate: number;
    workers: number;
    earnings: number;
  }>;
  estimatedAnnual: number;
  breakEvenDays: number;
  roi: number;
  powerCost: {
    daily: number;
    weekly: number;
    monthly: number;
    currency: string;
  };
}

// Recommendation types
export interface Recommendation {
  id: string;
  type: 'optimization' | 'security' | 'maintenance' | 'performance' | 'cost';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  metadata: Record<string, any>;
  createdAt: string;
  status: 'pending' | 'applied' | 'rejected' | 'in_progress';
  appliedAt?: string;
  rejectedAt?: string;
  feedback?: {
    helpful: boolean;
    comment?: string;
    submittedAt: string;
  };
  userId: string;
}

export interface RecommendationResponse {
  recommendations: Record<string, Recommendation[]>;
  lastUpdated: string;
}

export interface RecommendationHistoryResponse {
  recommendations: Recommendation[];
  totalCount: number;
  page: number;
  pageSize: number;
}

// Telemetry types
export interface MinerTelemetry {
  timestamp: number;
  miner_id: string;
  ip_address: string;
  model: string;
  firmware_version: string;
  hashrate: {
    total: number;
    unit: string;
    per_hashboard: Array<{
      board_id: number;
      hashrate: number;
      status: string;
    }>;
  };
  temperature: {
    ambient: number;
    avg_chip: number;
    max_chip: number;
    [key: string]: any;
  };
  power: {
    consumption: number;
    efficiency: number;
    voltage: number;
  };
  fans: Array<{
    fan_id: number;
    speed: number;
    speed_percent: number;
    status: string;
  }>;
  pool: {
    url: string;
    user: string;
    status: string;
  };
  shares: {
    accepted: number;
    rejected: number;
    stale: number;
    last_share_time: number;
  };
  status: {
    mining_status: string;
    uptime: number;
    errors: string[];
  };
  config: {
    frequency: number;
    overclock_profile: string;
    power_limit: number;
  };
}

// User types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
  updatedAt: string;
}

// API Key types
export interface ApiKey {
  id: string;
  name: string;
  key: string;
  userId: string;
  createdAt: string;
  expiresAt?: string;
  lastUsed?: string;
  permissions: string[];
}
