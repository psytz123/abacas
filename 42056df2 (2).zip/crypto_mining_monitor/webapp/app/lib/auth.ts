
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from './prisma'
import { cookies } from 'next/headers'
import { NextRequest } from 'next/server'

// Ensure JWT_SECRET is set in environment variables
const JWT_SECRET = process.env.JWT_SECRET
if (!JWT_SECRET) {
  console.error('JWT_SECRET environment variable is not set!')
  // In production, we should terminate the application
  // In development, we'll use a fallback but log a warning
  if (process.env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET environment variable is required in production')
  }
}

// Use environment variable with fallback only for development
const getJwtSecret = () => {
  return JWT_SECRET || 'dev-only-secret-do-not-use-in-production'
}

// JWT expiration time from environment or default
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d'
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '30d'

// Secure cookie settings
export const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 60 * 60 * 24 * 7, // 7 days in seconds
}

export const REFRESH_COOKIE_OPTIONS = {
  ...COOKIE_OPTIONS,
  maxAge: 60 * 60 * 24 * 30, // 30 days in seconds
  path: '/api/auth/refresh',
}

export interface User {
  id: string
  email: string
  name?: string
}

export interface TokenPayload {
  userId: string
  email: string
  type?: 'access' | 'refresh'
  iat?: number
  exp?: number
}

/**
 * Hash a password with bcrypt using a higher salt round for better security
 */
export async function hashPassword(password: string): Promise<string> {
  // Increased from 12 to 14 rounds for better security
  return bcrypt.hash(password, 14)
}

/**
 * Verify a password against a hashed password using a constant-time comparison
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  try {
    return await bcrypt.compare(password, hashedPassword)
  } catch (error) {
    console.error('Password verification error:', error)
    return false
  }
}

/**
 * Generate an access token for a user
 */
export function generateAccessToken(user: User): string {
  return jwt.sign(
    { 
      userId: user.id, 
      email: user.email,
      type: 'access'
    },
    getJwtSecret(),
    { expiresIn: JWT_EXPIRES_IN }
  )
}

/**
 * Generate a refresh token for a user
 */
export function generateRefreshToken(user: User): string {
  return jwt.sign(
    { 
      userId: user.id, 
      email: user.email,
      type: 'refresh'
    },
    getJwtSecret(),
    { expiresIn: JWT_REFRESH_EXPIRES_IN }
  )
}

/**
 * Verify a JWT token and return the decoded payload or null if invalid
 */
export function verifyToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, getJwtSecret()) as TokenPayload
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      // Token is invalid
      console.error('Invalid token:', error.message)
    } else if (error instanceof jwt.TokenExpiredError) {
      // Token has expired
      console.error('Token expired:', error.message)
    } else if (error instanceof jwt.NotBeforeError) {
      // Token not active yet
      console.error('Token not active:', error.message)
    } else {
      // Other errors
      console.error('Token verification error:', error)
    }
    return null
  }
}

/**
 * Get user from a token
 */
export async function getUserFromToken(token: string): Promise<User | null> {
  try {
    const decoded = verifyToken(token)
    if (!decoded) return null

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: { id: true, email: true, name: true }
    })

    return user
  } catch (error) {
    console.error('Get user from token error:', error)
    return null
  }
}

/**
 * Set authentication cookies in the response
 */
export function setAuthCookies(
  response: Response, 
  accessToken: string, 
  refreshToken: string
): Response {
  const cookieStore = cookies()
  
  // Set the cookies
  cookieStore.set('auth-token', accessToken, COOKIE_OPTIONS)
  cookieStore.set('refresh-token', refreshToken, REFRESH_COOKIE_OPTIONS)
  
  return response
}

/**
 * Clear authentication cookies
 */
export function clearAuthCookies(response: Response): Response {
  const cookieStore = cookies()
  
  // Clear the cookies by setting them to empty with immediate expiration
  cookieStore.set('auth-token', '', { ...COOKIE_OPTIONS, maxAge: 0 })
  cookieStore.set('refresh-token', '', { ...REFRESH_COOKIE_OPTIONS, maxAge: 0 })
  
  return response
}

/**
 * Get token from request
 */
export function getTokenFromRequest(request: NextRequest): string | null {
  // Try to get token from cookies first
  const token = request.cookies.get('auth-token')?.value
  if (token) return token
  
  // Then try to get from Authorization header
  const authHeader = request.headers.get('Authorization')
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7)
  }
  
  return null
}

/**
 * Generate a CSRF token
 */
export function generateCsrfToken(): string {
  return crypto.randomUUID()
}

/**
 * Verify CSRF token
 */
export function verifyCsrfToken(token: string, storedToken: string): boolean {
  // Use a constant-time comparison to prevent timing attacks
  return crypto.subtle.timingSafeEqual(
    new TextEncoder().encode(token),
    new TextEncoder().encode(storedToken)
  ) as unknown as boolean
}
