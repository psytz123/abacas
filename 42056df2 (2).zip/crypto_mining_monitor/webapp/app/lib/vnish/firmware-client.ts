/**
 * VNish Firmware Client
 * 
 * This module provides functionality to interact with mining hardware firmware,
 * allowing for firmware updates, configuration changes, and status monitoring.
 */

import { z } from 'zod';
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

export interface FirmwareConfig {
  apiEndpoint: string;
  apiKey: string;
  timeout: number; // in milliseconds
}

export interface MinerDevice {
  id: string;
  name: string;
  model: string;
  firmwareVersion: string;
  lastUpdated: Date;
  status: 'online' | 'offline' | 'updating' | 'error';
  ipAddress: string;
  macAddress: string;
}

export interface FirmwareUpdateOptions {
  version: string;
  forceUpdate?: boolean;
  scheduleTime?: Date;
  rollbackOnError?: boolean;
}

export interface FirmwareUpdateStatus {
  deviceId: string;
  updateId: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  progress: number; // 0-100
  startTime: Date;
  endTime?: Date;
  errorMessage?: string;
}

export interface MinerTelemetry {
  timestamp: number;
  miner_id: string;
  ip_address: string;
  model: string;
  firmware_version: string;
  hashrate: {
    total: number;
    unit: string;
    per_hashboard: Array<{
      board_id: number;
      hashrate: number;
      status: string;
    }>;
  };
  temperature: {
    ambient: number;
    avg_chip: number;
    max_chip: number;
    [key: string]: any;
  };
  power: {
    consumption: number;
    efficiency: number;
    voltage: number;
  };
  fans: Array<{
    fan_id: number;
    speed: number;
    speed_percent: number;
    status: string;
  }>;
  pool: {
    url: string;
    user: string;
    status: string;
  };
  shares: {
    accepted: number;
    rejected: number;
    stale: number;
    last_share_time: number;
  };
  status: {
    mining_status: string;
    uptime: number;
    errors: string[];
  };
  config: {
    frequency: number;
    overclock_profile: string;
    power_limit: number;
  };
}

export interface HashrateTuningRequest {
  miner_id: string;
  miner_ip?: string;
  hashrate_percent: number;
  dry_run?: boolean;
}

export interface PowerOptimizationRequest {
  miner_id: string;
  miner_ip?: string;
  power_limit_factor: number;
  dry_run?: boolean;
}

export interface OverclockingRequest {
  miner_id: string;
  miner_ip?: string;
  core_clock_offset: number;
  memory_clock_offset: number;
  power_limit_percent: number;
  core_voltage_offset: number;
  dry_run?: boolean;
}

// Zod schemas for validation
const MinerDeviceSchema = z.object({
  id: z.string(),
  name: z.string(),
  model: z.string(),
  firmwareVersion: z.string(),
  lastUpdated: z.string().transform(str => new Date(str)),
  status: z.enum(['online', 'offline', 'updating', 'error']),
  ipAddress: z.string(),
  macAddress: z.string()
});

const MinerTelemetrySchema = z.object({
  timestamp: z.number(),
  miner_id: z.string(),
  ip_address: z.string(),
  model: z.string(),
  firmware_version: z.string(),
  hashrate: z.object({
    total: z.number(),
    unit: z.string(),
    per_hashboard: z.array(z.object({
      board_id: z.number(),
      hashrate: z.number(),
      status: z.string()
    }))
  }),
  temperature: z.object({
    ambient: z.number(),
    avg_chip: z.number(),
    max_chip: z.number()
  }).catchall(z.any()),
  power: z.object({
    consumption: z.number(),
    efficiency: z.number(),
    voltage: z.number()
  }),
  fans: z.array(z.object({
    fan_id: z.number(),
    speed: z.number(),
    speed_percent: z.number(),
    status: z.string()
  })),
  pool: z.object({
    url: z.string(),
    user: z.string(),
    status: z.string()
  }),
  shares: z.object({
    accepted: z.number(),
    rejected: z.number(),
    stale: z.number(),
    last_share_time: z.number()
  }),
  status: z.object({
    mining_status: z.string(),
    uptime: z.number(),
    errors: z.array(z.string())
  }),
  config: z.object({
    frequency: z.number(),
    overclock_profile: z.string(),
    power_limit: z.number()
  })
});

export class VNishFirmwareClient {
  private config: FirmwareConfig;
  private mlApiEndpoint: string;
  private axiosInstance: AxiosInstance;
  
  constructor(config: FirmwareConfig) {
    this.config = config;
    
    // ML API endpoint for Vnish integration
    this.mlApiEndpoint = process.env.ML_API_ENDPOINT || 'http://localhost:8000';
    
    // Create axios instance with default config
    this.axiosInstance = axios.create({
      baseURL: this.config.apiEndpoint,
      timeout: this.config.timeout,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.apiKey}`
      }
    });
    
    // Add response interceptor for error handling
    this.axiosInstance.interceptors.response.use(
      response => response,
      error => {
        console.error('VNish API Error:', error.response?.data || error.message);
        return Promise.reject(error);
      }
    );
  }
  
  /**
   * Get a list of all miner devices
   */
  async getDevices(): Promise<MinerDevice[]> {
    try {
      const response = await this.axiosInstance.get('/vnish/devices');
      
      // Validate response data
      const devices = z.array(MinerDeviceSchema).parse(response.data.devices);
      return devices;
    } catch (error) {
      console.error('Failed to get devices:', error);
      throw error;
    }
  }
  
  /**
   * Get detailed information about a specific device
   */
  async getDeviceDetails(deviceId: string): Promise<MinerDevice | null> {
    try {
      const response = await this.axiosInstance.get(`/vnish/devices/${deviceId}`);
      
      // Validate response data
      const device = MinerDeviceSchema.parse(response.data.device);
      return device;
    } catch (error) {
      console.error(`Failed to get device details for ${deviceId}:`, error);
      return null;
    }
  }
  
  /**
   * Get telemetry data for a specific miner
   */
  async getTelemetry(minerIp: string): Promise<MinerTelemetry | null> {
    try {
      const response = await this.axiosInstance.get(`/vnish/telemetry/${minerIp}`);
      
      // Validate response data
      const telemetry = MinerTelemetrySchema.parse(response.data.telemetry);
      return telemetry;
    } catch (error) {
      console.error(`Failed to get telemetry for ${minerIp}:`, error);
      return null;
    }
  }
  
  /**
   * Apply hashrate tuning to a miner
   */
  async applyHashrateTuning(request: HashrateTuningRequest): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/vnish/hashrate-tuning', request);
      return response.data;
    } catch (error) {
      console.error(`Failed to apply hashrate tuning:`, error);
      throw error;
    }
  }
  
  /**
   * Apply power optimization to a miner
   */
  async applyPowerOptimization(request: PowerOptimizationRequest): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/vnish/power-optimization', request);
      return response.data;
    } catch (error) {
      console.error(`Failed to apply power optimization:`, error);
      throw error;
    }
  }
  
  /**
   * Apply overclocking to a miner
   */
  async applyOverclocking(request: OverclockingRequest): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/vnish/overclocking', request);
      return response.data;
    } catch (error) {
      console.error(`Failed to apply overclocking:`, error);
      throw error;
    }
  }
  
  /**
   * Apply a specific recommendation to a miner
   */
  async applyRecommendation(recommendationId: string, minerIp?: string, dryRun: boolean = false): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/vnish/apply-recommendation', {
        recommendation_id: recommendationId,
        miner_ip: minerIp,
        dry_run: dryRun
      });
      return response.data;
    } catch (error) {
      console.error(`Failed to apply recommendation:`, error);
      throw error;
    }
  }
  
  /**
   * Generate and apply recommendations for multiple miners
   */
  async generateAndApplyRecommendations(minerIps: string[], recommendationTypes?: string[], dryRun: boolean = false): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/vnish/generate-and-apply', {
        miner_ips: minerIps,
        recommendation_types: recommendationTypes,
        dry_run: dryRun
      });
      return response.data;
    } catch (error) {
      console.error(`Failed to generate and apply recommendations:`, error);
      throw error;
    }
  }
  
  /**
   * Check if firmware updates are available for a device
   */
  async checkForUpdates(deviceId: string): Promise<{available: boolean, latestVersion: string}> {
    try {
      const response = await this.axiosInstance.get(`/vnish/firmware/check/${deviceId}`);
      return response.data;
    } catch (error) {
      console.error(`Failed to check for updates for ${deviceId}:`, error);
      return {
        available: false,
        latestVersion: ''
      };
    }
  }
  
  /**
   * Update firmware on a device
   */
  async updateFirmware(deviceId: string, options: FirmwareUpdateOptions): Promise<{updateId: string}> {
    try {
      const response = await this.axiosInstance.post(`/vnish/firmware/update/${deviceId}`, options);
      return response.data;
    } catch (error) {
      console.error(`Failed to update firmware for ${deviceId}:`, error);
      throw new Error(`Firmware update failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get the status of a firmware update
   */
  async getUpdateStatus(updateId: string): Promise<FirmwareUpdateStatus> {
    try {
      const response = await this.axiosInstance.get(`/vnish/firmware/status/${updateId}`);
      return response.data;
    } catch (error) {
      console.error(`Failed to get update status for ${updateId}:`, error);
      throw new Error(`Failed to get update status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Cancel a pending or in-progress firmware update
   */
  async cancelUpdate(updateId: string): Promise<boolean> {
    try {
      const response = await this.axiosInstance.post(`/vnish/firmware/cancel/${updateId}`);
      return response.data.success;
    } catch (error) {
      console.error(`Failed to cancel update ${updateId}:`, error);
      return false;
    }
  }
}

export default VNishFirmwareClient;
