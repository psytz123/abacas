/**
 * ProHashing API Client
 * 
 * This module provides functionality to interact with the ProHashing mining pool API,
 * allowing for monitoring mining performance, payouts, and pool statistics.
 */

import { z } from 'zod';
import axios, { AxiosInstance } from 'axios';
import crypto from 'crypto';

export interface ProHashingConfig {
  apiKey: string;
  apiSecret: string;
  baseUrl: string;
  userId: string;
}

export interface MiningStats {
  hashrate: number; // in H/s
  workers: number;
  activeWorkers: number;
  acceptedShares: number;
  rejectedShares: number;
  invalidShares: number;
  earnings: {
    today: number;
    yesterday: number;
    thisWeek: number;
    thisMonth: number;
    total: number;
  };
  coins: Record<string, {
    hashrate: number;
    workers: number;
    earnings: number;
  }>;
}

export interface Worker {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'error';
  hashrate: number;
  lastSeen: Date;
  acceptedShares: number;
  rejectedShares: number;
  temperature?: number;
  powerConsumption?: number;
}

export interface Payout {
  id: string;
  timestamp: Date;
  amount: number;
  coin: string;
  txid: string;
  status: 'pending' | 'completed' | 'failed';
}

export interface PoolStats {
  hashrate: number;
  miners: number;
  workers: number;
  fee: number;
  lastBlockFound: Date;
  coins: Record<string, {
    hashrate: number;
    miners: number;
    lastBlockFound: Date;
    currentDifficulty: number;
  }>;
}

// Zod schemas for validation
const MiningStatsSchema = z.object({
  hashrate: z.number(),
  workers: z.number(),
  activeWorkers: z.number(),
  acceptedShares: z.number(),
  rejectedShares: z.number(),
  invalidShares: z.number(),
  earnings: z.object({
    today: z.number(),
    yesterday: z.number(),
    thisWeek: z.number(),
    thisMonth: z.number(),
    total: z.number()
  }),
  coins: z.record(z.object({
    hashrate: z.number(),
    workers: z.number(),
    earnings: z.number()
  }))
});

const WorkerSchema = z.object({
  id: z.string(),
  name: z.string(),
  status: z.enum(['online', 'offline', 'error']),
  hashrate: z.number(),
  lastSeen: z.string().transform(str => new Date(str)),
  acceptedShares: z.number(),
  rejectedShares: z.number(),
  temperature: z.number().optional(),
  powerConsumption: z.number().optional()
});

const PayoutSchema = z.object({
  id: z.string(),
  timestamp: z.string().transform(str => new Date(str)),
  amount: z.number(),
  coin: z.string(),
  txid: z.string(),
  status: z.enum(['pending', 'completed', 'failed'])
});

const PoolStatsSchema = z.object({
  hashrate: z.number(),
  miners: z.number(),
  workers: z.number(),
  fee: z.number(),
  lastBlockFound: z.string().transform(str => new Date(str)),
  coins: z.record(z.object({
    hashrate: z.number(),
    miners: z.number(),
    lastBlockFound: z.string().transform(str => new Date(str)),
    currentDifficulty: z.number()
  }))
});

export class ProHashingClient {
  private config: ProHashingConfig;
  private axiosInstance: AxiosInstance;
  
  constructor(config: ProHashingConfig) {
    this.config = config;
    
    // Create axios instance with default config
    this.axiosInstance = axios.create({
      baseURL: this.config.baseUrl,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    // Add request interceptor to sign API requests
    this.axiosInstance.interceptors.request.use(
      config => {
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const nonce = crypto.randomBytes(16).toString('hex');
        
        // Add query parameters for authentication
        config.params = {
          ...config.params,
          api_key: this.config.apiKey,
          timestamp,
          nonce
        };
        
        // Generate signature
        const message = `${timestamp}${nonce}${this.config.apiKey}${this.config.userId}`;
        const signature = crypto
          .createHmac('sha256', this.config.apiSecret)
          .update(message)
          .digest('hex');
        
        config.params.signature = signature;
        
        return config;
      },
      error => Promise.reject(error)
    );
    
    // Add response interceptor for error handling
    this.axiosInstance.interceptors.response.use(
      response => response,
      error => {
        console.error('ProHashing API Error:', error.response?.data || error.message);
        return Promise.reject(error);
      }
    );
  }
  
  /**
   * Get current mining statistics for the user
   */
  async getMiningStats(): Promise<MiningStats> {
    try {
      const response = await this.axiosInstance.get('/mining/stats', {
        params: { user_id: this.config.userId }
      });
      
      // Validate response data
      const stats = MiningStatsSchema.parse(response.data);
      return stats;
    } catch (error) {
      console.error('Failed to get mining stats:', error);
      throw new Error(`Failed to get mining stats: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get a list of all workers
   */
  async getWorkers(): Promise<Worker[]> {
    try {
      const response = await this.axiosInstance.get('/mining/workers', {
        params: { user_id: this.config.userId }
      });
      
      // Validate response data
      const workers = z.array(WorkerSchema).parse(response.data.workers);
      return workers;
    } catch (error) {
      console.error('Failed to get workers:', error);
      throw new Error(`Failed to get workers: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get detailed information about a specific worker
   */
  async getWorkerDetails(workerId: string): Promise<Worker | null> {
    try {
      const response = await this.axiosInstance.get(`/mining/workers/${workerId}`, {
        params: { user_id: this.config.userId }
      });
      
      // Validate response data
      const worker = WorkerSchema.parse(response.data.worker);
      return worker;
    } catch (error) {
      console.error(`Failed to get worker details for ${workerId}:`, error);
      return null;
    }
  }
  
  /**
   * Get recent payouts
   */
  async getPayouts(limit: number = 10): Promise<Payout[]> {
    try {
      const response = await this.axiosInstance.get('/mining/payouts', {
        params: { 
          user_id: this.config.userId,
          limit
        }
      });
      
      // Validate response data
      const payouts = z.array(PayoutSchema).parse(response.data.payouts);
      return payouts;
    } catch (error) {
      console.error('Failed to get payouts:', error);
      throw new Error(`Failed to get payouts: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get pool statistics
   */
  async getPoolStats(): Promise<PoolStats> {
    try {
      const response = await this.axiosInstance.get('/pool/stats');
      
      // Validate response data
      const stats = PoolStatsSchema.parse(response.data);
      return stats;
    } catch (error) {
      console.error('Failed to get pool stats:', error);
      throw new Error(`Failed to get pool stats: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Set mining preferences (e.g., auto-switching, coin preferences)
   */
  async setMiningPreferences(preferences: Record<string, any>): Promise<boolean> {
    try {
      const response = await this.axiosInstance.post('/mining/preferences', {
        user_id: this.config.userId,
        ...preferences
      });
      
      return response.data.success === true;
    } catch (error) {
      console.error('Failed to set mining preferences:', error);
      throw new Error(`Failed to set mining preferences: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get profitability data for different coins and algorithms
   */
  async getProfitabilityData(): Promise<any> {
    try {
      const response = await this.axiosInstance.get('/pool/profitability');
      return response.data;
    } catch (error) {
      console.error('Failed to get profitability data:', error);
      throw new Error(`Failed to get profitability data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Get historical earnings data
   */
  async getHistoricalEarnings(days: number = 30): Promise<any> {
    try {
      const response = await this.axiosInstance.get('/mining/earnings/history', {
        params: { 
          user_id: this.config.userId,
          days
        }
      });
      return response.data;
    } catch (error) {
      console.error('Failed to get historical earnings:', error);
      throw new Error(`Failed to get historical earnings: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export default ProHashingClient;
