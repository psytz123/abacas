/**
 * API validation utilities
 */

import { UnauthorizedError } from '@/lib/errors';

/**
 * Validates an API key against the expected value
 */
export function validateApiKey(providedKey?: string, expectedKey?: string): boolean {
  if (!expectedKey) {
    // If no expected key is configured, we don't require authentication
    return true;
  }
  
  if (!providedKey) {
    throw new UnauthorizedError('API key is required');
  }
  
  if (providedKey !== expectedKey) {
    throw new UnauthorizedError('Invalid API key');
  }
  
  return true;
}

/**
 * Validates that required fields are present in the request body
 */
export function validateRequiredFields(body: any, requiredFields: string[]): void {
  const missingFields = requiredFields.filter(field => !body[field]);
  
  if (missingFields.length > 0) {
    throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
  }
}