import crypto from 'crypto'

export function generateApiKey(): string {
  // Generate a 32-byte random key and encode it as hex
  const randomBytes = crypto.randomBytes(32)
  const timestamp = Date.now().toString(36)
  
  // Format: mk_<timestamp>_<random_hex>
  return `mk_${timestamp}_${randomBytes.toString('hex')}`
}

export function validateApiKeyFormat(apiKey: string): boolean {
  // API key format: mk_<timestamp>_<64_char_hex>
  if (!apiKey || typeof apiKey !== 'string') {
    return false
  }
  const apiKeyRegex = /^mk_[a-z0-9]+_[a-f0-9]{64}$/i
  return apiKeyRegex.test(apiKey)
}

export function parseApiKey(apiKey: string): { prefix: string; timestamp: string; key: string } | null {
  if (!validateApiKeyFormat(apiKey)) {
    return null
  }
  
  const parts = apiKey.split('_')
  if (parts.length !== 3) {
    return null
  }
  
  return {
    prefix: parts[0],    // Should be 'mk'
    timestamp: parts[1], // Base36 timestamp
    key: parts[2]        // 64-character hex string
  }
}