/**
 * Abacus Serving Client
 * 
 * This module provides functionality to interact with the Abacus serving API,
 * which is used for retrieving recommendations and other ML-powered features.
 */

import { z } from 'zod';
import axios, { AxiosInstance } from 'axios';
import { validateApiKey } from '@/lib/api-validation';
import { ServiceUnavailableError, UnauthorizedError, BadRequestError } from '@/lib/errors';

interface AbacusConfig {
  apiKey?: string;
  endpoint: string;
  region: string;
  modelName: string;
}

export interface Recommendation {
  id: string;
  type: 'optimization' | 'security' | 'maintenance' | 'performance' | 'cost';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  metadata: Record<string, any>;
  createdAt: string;
  status: 'pending' | 'applied' | 'rejected' | 'in_progress';
  appliedAt?: string;
  rejectedAt?: string;
  feedback?: {
    helpful: boolean;
    comment?: string;
    submittedAt: string;
  };
}

export interface RecommendationResponse {
  recommendations: Record<string, Recommendation[]>;
  lastUpdated: string;
}

export interface RecommendationHistoryResponse {
  recommendations: Recommendation[];
  totalCount: number;
  page: number;
  pageSize: number;
}

export interface RecommendationFeedback {
  recommendationId: string;
  helpful: boolean;
  comment?: string;
}

// Zod schemas for validation
const RecommendationSchema = z.object({
  id: z.string(),
  type: z.enum(['optimization', 'security', 'maintenance', 'performance', 'cost']),
  title: z.string(),
  description: z.string(),
  impact: z.enum(['high', 'medium', 'low']),
  confidence: z.number(),
  metadata: z.record(z.any()),
  createdAt: z.string(),
  status: z.enum(['pending', 'applied', 'rejected', 'in_progress']),
  appliedAt: z.string().optional(),
  rejectedAt: z.string().optional(),
  feedback: z.object({
    helpful: z.boolean(),
    comment: z.string().optional(),
    submittedAt: z.string()
  }).optional()
});

const RecommendationResponseSchema = z.object({
  recommendations: z.record(z.array(RecommendationSchema)),
  lastUpdated: z.string()
});

const RecommendationHistoryResponseSchema = z.object({
  recommendations: z.array(RecommendationSchema),
  totalCount: z.number(),
  page: z.number(),
  pageSize: z.number()
});

export class AbacusServingClient {
  private config: AbacusConfig;
  private axiosInstance: AxiosInstance;
  
  constructor(config: AbacusConfig) {
    this.config = config;
    
    // Create axios instance with default config
    this.axiosInstance = axios.create({
      baseURL: this.config.endpoint,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': this.config.apiKey || '',
        'X-Abacus-Region': this.config.region
      }
    });
    
    // Add response interceptor for error handling
    this.axiosInstance.interceptors.response.use(
      response => response,
      error => {
        console.error('Abacus API Error:', error.response?.data || error.message);
        
        if (error.response?.status === 401) {
          return Promise.reject(new UnauthorizedError('Invalid API key'));
        }
        
        if (error.response?.status === 400) {
          return Promise.reject(new BadRequestError(error.response.data.message || 'Bad request'));
        }
        
        if (error.response?.status >= 500) {
          return Promise.reject(new ServiceUnavailableError('Abacus service is currently unavailable'));
        }
        
        return Promise.reject(error);
      }
    );
  }
  
  /**
   * Get recommendations for a specific user or system
   */
  async getRecommendations(userId: string): Promise<RecommendationResponse> {
    try {
      validateApiKey(this.config.apiKey);
      
      console.log(`Fetching recommendations for user: ${userId}`);
      
      const response = await this.axiosInstance.get('/recommendations', {
        params: {
          userId,
          modelName: this.config.modelName
        }
      });
      
      // Validate response data
      const data = RecommendationResponseSchema.parse(response.data);
      return data;
    } catch (error) {
      console.error('Failed to get recommendations:', error);
      
      if (error instanceof UnauthorizedError) {
        throw error;
      }
      
      if (error instanceof ServiceUnavailableError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Recommendation service is currently unavailable');
    }
  }
  
  /**
   * Get recommendation history
   */
  async getRecommendationHistory(
    userId: string,
    page: number = 1,
    pageSize: number = 10,
    status?: string,
    type?: string
  ): Promise<RecommendationHistoryResponse> {
    try {
      validateApiKey(this.config.apiKey);
      
      console.log(`Fetching recommendation history for user: ${userId}`);
      
      // Build query parameters
      const params: Record<string, any> = {
        userId,
        page,
        pageSize,
        modelName: this.config.modelName
      };
      
      if (status) params.status = status;
      if (type) params.type = type;
      
      const response = await this.axiosInstance.get('/recommendations/history', { params });
      
      // Validate response data
      const data = RecommendationHistoryResponseSchema.parse(response.data);
      return data;
    } catch (error) {
      console.error('Failed to get recommendation history:', error);
      
      if (error instanceof UnauthorizedError) {
        throw error;
      }
      
      if (error instanceof ServiceUnavailableError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Recommendation service is currently unavailable');
    }
  }
  
  /**
   * Submit feedback for a recommendation
   */
  async submitRecommendationFeedback(feedback: RecommendationFeedback): Promise<boolean> {
    try {
      validateApiKey(this.config.apiKey);
      
      if (!feedback.recommendationId) {
        throw new BadRequestError('Recommendation ID is required');
      }
      
      if (feedback.helpful === undefined) {
        throw new BadRequestError('Feedback helpfulness is required');
      }
      
      const response = await this.axiosInstance.post('/feedback', {
        recommendation_id: feedback.recommendationId,
        feedback_type: feedback.helpful ? 'accepted' : 'rejected',
        details: feedback.comment
      });
      
      return response.data.success === true;
    } catch (error) {
      console.error('Failed to submit recommendation feedback:', error);
      
      if (error instanceof UnauthorizedError || error instanceof BadRequestError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Recommendation service is currently unavailable');
    }
  }
  
  /**
   * Update recommendation status
   */
  async updateRecommendationStatus(
    recommendationId: string,
    status: 'applied' | 'rejected' | 'in_progress'
  ): Promise<boolean> {
    try {
      validateApiKey(this.config.apiKey);
      
      if (!recommendationId) {
        throw new BadRequestError('Recommendation ID is required');
      }
      
      const response = await this.axiosInstance.post('/recommendations', {
        recommendationId,
        action: status === 'applied' ? 'apply' : 
               status === 'rejected' ? 'reject' : 'in_progress'
      });
      
      return response.data.success === true;
    } catch (error) {
      console.error('Failed to update recommendation status:', error);
      
      if (error instanceof UnauthorizedError || error instanceof BadRequestError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Recommendation service is currently unavailable');
    }
  }
  
  /**
   * Get model predictions for a specific input
   */
  async getPredictions(features: Record<string, any>): Promise<any> {
    try {
      validateApiKey(this.config.apiKey);
      
      const response = await this.axiosInstance.post('/predict', {
        modelName: this.config.modelName,
        features
      });
      
      return response.data;
    } catch (error) {
      console.error('Failed to get predictions:', error);
      
      if (error instanceof UnauthorizedError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Prediction service is currently unavailable');
    }
  }
  
  /**
   * Get feature importance for a specific prediction
   */
  async getFeatureImportance(predictionId: string): Promise<any> {
    try {
      validateApiKey(this.config.apiKey);
      
      const response = await this.axiosInstance.get(`/explain/${predictionId}`);
      return response.data;
    } catch (error) {
      console.error('Failed to get feature importance:', error);
      
      if (error instanceof UnauthorizedError) {
        throw error;
      }
      
      throw new ServiceUnavailableError('Explanation service is currently unavailable');
    }
  }
}

// Export the client class
export default AbacusServingClient;

// Export a singleton instance for convenience
export const RecommendationClient = new AbacusServingClient({
  apiKey: process.env.ABACUS_API_KEY,
  endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
  region: process.env.ABACUS_REGION || 'us-west-2',
  modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
});
