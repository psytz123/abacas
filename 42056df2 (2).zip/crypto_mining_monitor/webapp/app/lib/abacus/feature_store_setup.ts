/**
 * Abacus.AI Feature Store Manager
 * Handles data ingestion to Abacus.AI feature stores
 */

export class FeatureStoreManager {
  private apiKey: string;
  private baseUrl: string;
  private initialized: boolean = false;

  constructor() {
    this.apiKey = process.env.ABACUSAI_API_KEY || '';
    this.baseUrl = process.env.ABACUSAI_API_URL || 'https://api.abacus.ai/v0';
  }

  async initialize(): Promise<void> {
    if (!this.apiKey) {
      throw new Error('Abacus.AI API key is not configured');
    }
    this.initialized = true;
  }

  private checkInitialized(): void {
    if (!this.initialized) {
      throw new Error('FeatureStoreManager must be initialized before use');
    }
  }

  async uploadMinerTelemetryData(data: any[]): Promise<string> {
    this.checkInitialized();
    try {
      const response = await fetch(`${this.baseUrl}/feature-store/miner-telemetry/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          data: data,
          format: 'json'
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to upload miner telemetry data: ${response.statusText}`);
      }

      const result = await response.json();
      return result.upload_job_id;
    } catch (error) {
      console.error('Error uploading miner telemetry data:', error);
      throw error;
    }
  }

  async uploadPoolPerformanceData(data: any[]): Promise<string> {
    this.checkInitialized();
    try {
      const response = await fetch(`${this.baseUrl}/feature-store/pool-performance/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          data: data,
          format: 'json'
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to upload pool performance data: ${response.statusText}`);
      }

      const result = await response.json();
      return result.upload_job_id;
    } catch (error) {
      console.error('Error uploading pool performance data:', error);
      throw error;
    }
  }

  async uploadMarketData(data: any[]): Promise<string> {
    this.checkInitialized();
    try {
      const response = await fetch(`${this.baseUrl}/feature-store/market-data/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          data: data,
          format: 'json'
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to upload market data: ${response.statusText}`);
      }

      const result = await response.json();
      return result.upload_job_id;
    } catch (error) {
      console.error('Error uploading market data:', error);
      throw error;
    }
  }

  async uploadDerivedMetrics(data: any[]): Promise<string> {
    this.checkInitialized();
    try {
      const response = await fetch(`${this.baseUrl}/feature-store/derived-metrics/upload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          data: data,
          format: 'json'
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to upload derived metrics: ${response.statusText}`);
      }

      const result = await response.json();
      return result.upload_job_id;
    } catch (error) {
      console.error('Error uploading derived metrics:', error);
      throw error;
    }
  }

  async getUploadStatus(uploadJobId: string): Promise<any> {
    this.checkInitialized();
    try {
      const response = await fetch(`${this.baseUrl}/jobs/${uploadJobId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get upload status: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting upload status:', error);
      throw error;
    }
  }
}