import { useState, useEffect, useCallback, useMemo } from 'react';

interface Recommendation {
  id: string;
  type: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  confidence: number;
  metadata: Record<string, any>;
  createdAt: string;
  status: 'pending' | 'applied' | 'rejected' | 'in_progress';
}

interface RecommendationsResponse {
  recommendations: Record<string, Recommendation[]>;
  lastUpdated: string;
}

// Cache recommendations for 5 minutes
const CACHE_DURATION = 5 * 60 * 1000;
let cachedRecommendations: RecommendationsResponse | null = null;
let cacheTimestamp: number = 0;

export function useRecommendations() {
  const [recommendations, setRecommendations] = useState<RecommendationsResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);
  
  // Debounce fetch requests to prevent multiple simultaneous calls
  const fetchRecommendations = useCallback(async (forceRefresh = false) => {
    const now = Date.now();
    
    // Use cache if available and not expired, unless force refresh is requested
    if (!forceRefresh && cachedRecommendations && (now - cacheTimestamp < CACHE_DURATION)) {
      setRecommendations(cachedRecommendations);
      setIsLoading(false);
      return;
    }
    
    // Prevent multiple fetches within 2 seconds unless force refresh
    if (!forceRefresh && (now - lastFetchTime < 2000)) {
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      setLastFetchTime(now);
      
      const response = await fetch('/api/recommendations');
      
      if (!response.ok) {
        throw new Error(`Failed to fetch recommendations: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Update cache
      cachedRecommendations = data;
      cacheTimestamp = now;
      
      setRecommendations(data);
    } catch (err) {
      console.error('Error fetching recommendations:', err);
      setError(err instanceof Error ? err : new Error('Failed to fetch recommendations'));
    } finally {
      setIsLoading(false);
    }
  }, [lastFetchTime]);
  
  useEffect(() => {
    fetchRecommendations();
  }, [fetchRecommendations]);
  
  const refresh = useCallback(() => {
    fetchRecommendations(true); // Force refresh
  }, [fetchRecommendations]);
  
  // Memoize recommendation counts by type for better performance
  const recommendationCounts = useMemo(() => {
    if (!recommendations || !recommendations.recommendations) {
      return {};
    }
    
    const counts: Record<string, number> = {};
    
    Object.entries(recommendations.recommendations).forEach(([type, recs]) => {
      counts[type] = Array.isArray(recs) ? recs.length : 0;
    });
    
    return counts;
  }, [recommendations]);
  
  return {
    recommendations,
    isLoading,
    error,
    refresh,
    recommendationCounts
  };
}