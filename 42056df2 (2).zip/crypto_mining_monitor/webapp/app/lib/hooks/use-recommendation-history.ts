'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { RecommendationHistoryResponse, RecommendationType, RecommendationStatus } from '@/lib/types';

interface UseRecommendationHistoryProps {
  initialPage?: number;
  initialPageSize?: number;
  initialType?: RecommendationType | null;
  initialStatus?: RecommendationStatus | null;
}

// Cache history results for 2 minutes
const CACHE_DURATION = 2 * 60 * 1000;
const historyCache = new Map<string, { data: RecommendationHistoryResponse, timestamp: number }>();

export function useRecommendationHistory({
  initialPage = 1,
  initialPageSize = 10,
  initialType = null,
  initialStatus = null,
}: UseRecommendationHistoryProps = {}) {
  const [history, setHistory] = useState<RecommendationHistoryResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState<number>(initialPage);
  const [pageSize, setPageSize] = useState<number>(initialPageSize);
  const [type, setType] = useState<RecommendationType | null>(initialType);
  const [status, setStatus] = useState<RecommendationStatus | null>(initialStatus);
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);

  // Create a cache key based on the current parameters
  const cacheKey = useMemo(() => {
    return `${page}-${pageSize}-${type || 'all'}-${status || 'all'}`;
  }, [page, pageSize, type, status]);

  const fetchHistory = useCallback(async (forceRefresh = false) => {
    const now = Date.now();
    
    // Prevent multiple fetches within 1 second unless force refresh
    if (!forceRefresh && (now - lastFetchTime < 1000)) {
      return;
    }
    
    // Check cache first
    if (!forceRefresh && historyCache.has(cacheKey)) {
      const cached = historyCache.get(cacheKey)!;
      if (now - cached.timestamp < CACHE_DURATION) {
        setHistory(cached.data);
        return;
      }
    }
    
    setIsLoading(true);
    setError(null);
    setLastFetchTime(now);
    
    try {
      // Build query parameters
      const params = new URLSearchParams();
      params.append('page', page.toString());
      params.append('pageSize', pageSize.toString());
      if (type) params.append('type', type);
      if (status) params.append('status', status);
      
      const response = await fetch(`/api/recommendations/history?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch recommendation history: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Update cache
      historyCache.set(cacheKey, { data, timestamp: now });
      
      // Clean up old cache entries if cache gets too large
      if (historyCache.size > 20) {
        const oldestKey = Array.from(historyCache.entries())
          .sort(([, a], [, b]) => a.timestamp - b.timestamp)[0][0];
        historyCache.delete(oldestKey);
      }
      
      setHistory(data);
    } catch (err) {
      console.error('Error fetching recommendation history:', err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  }, [cacheKey, page, pageSize, type, status, lastFetchTime]);

  // Fetch history when parameters change
  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Memoize the total count to prevent unnecessary re-renders
  const totalCount = useMemo(() => history?.totalCount || 0, [history]);

  return {
    history,
    isLoading,
    error,
    page,
    pageSize,
    type,
    status,
    totalCount,
    setPage,
    setPageSize,
    setType,
    setStatus,
    refresh: () => fetchHistory(true),
  };
}