import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a hash rate value with appropriate units (H/s, KH/s, MH/s, GH/s, TH/s, PH/s)
 */
export function formatHashRate(hashrate: number): string {
  if (hashrate === 0) return "0 H/s";
  
  const units = ["H/s", "KH/s", "MH/s", "GH/s", "TH/s", "PH/s"];
  const i = Math.floor(Math.log(hashrate) / Math.log(1000));
  
  if (i >= units.length) return `${(hashrate / Math.pow(1000, units.length - 1)).toFixed(2)} ${units[units.length - 1]}`;
  
  return `${(hashrate / Math.pow(1000, i)).toFixed(2)} ${units[i]}`;
}

/**
 * Format power consumption with appropriate units (W, kW)
 */
export function formatPower(power: number): string {
  if (power < 1000) {
    return `${power.toFixed(2)} W`;
  } else {
    return `${(power / 1000).toFixed(2)} kW`;
  }
}

/**
 * Format uptime in a human-readable format (days, hours, minutes)
 */
export function formatUptime(hours: number): string {
  if (hours < 0) return "0m";
  
  const days = Math.floor(hours / 24);
  const remainingHours = Math.floor(hours % 24);
  const minutes = Math.floor((hours * 60) % 60);
  
  if (days > 0) {
    return `${days}d ${remainingHours}h`;
  } else if (remainingHours > 0) {
    return `${remainingHours}h ${minutes}m`;
  } else {
    return `${minutes}m`;
  }
}

/**
 * Format currency values with appropriate symbol and decimal places
 */
export function formatCurrency(value: number, currency: string = "USD", decimals: number = 2): string {
  const symbols: Record<string, string> = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    BTC: "₿",
    ETH: "Ξ"
  };
  
  const symbol = symbols[currency] || currency;
  
  return `${symbol}${value.toFixed(decimals)}`;
}
