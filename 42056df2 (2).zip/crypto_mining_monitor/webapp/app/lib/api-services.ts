// Mock API services for cryptocurrency mining monitoring system
// These functions simulate API calls to Vnish firmware and Prohashing.com

/**
 * Fetch miner statistics from Vnish firmware API
 */
export async function fetchMinerStats() {
  // In a real implementation, this would make an API call to Vnish firmware
  // For now, we'll return mock data
  return {
    totalHashrate: 485.6, // MH/s
    activeMiners: 10,
    powerConsumption: 3200, // Watts
    avgTemperature: 62, // Celsius
    efficiency: 0.152, // MH/W
    uptime: "98.7%",
    hashrateChange: 3.2, // % change from yesterday
    minerChange: 1, // change in number of active miners
    powerChange: -1.5, // % change in power consumption
    rigs: [
      {
        name: "Rig-01",
        status: "online",
        hashrate: 125.3,
        efficiency: 92,
        gpus: 6,
      },
      {
        name: "Rig-02",
        status: "online",
        hashrate: 118.7,
        efficiency: 88,
        gpus: 6,
      },
      {
        name: "Rig-03",
        status: "online",
        hashrate: 132.1,
        efficiency: 95,
        gpus: 6,
      },
      {
        name: "Rig-04",
        status: "offline",
        hashrate: 0,
        efficiency: 0,
        gpus: 4,
      },
      {
        name: "Rig-05",
        status: "online",
        hashrate: 109.5,
        efficiency: 85,
        gpus: 5,
      },
    ],
    events: [
      {
        type: "warning",
        message: "High temperature detected on Rig-03 GPU #2",
        time: "10 minutes ago",
      },
      {
        type: "error",
        message: "Connection lost with Rig-04",
        time: "2 hours ago",
      },
      {
        type: "info",
        message: "AI optimization applied to Rig-01",
        time: "5 hours ago",
      },
    ],
  };
}

/**
 * Fetch pool statistics from Prohashing.com API
 */
export async function fetchPoolStats() {
  // In a real implementation, this would make an API call to Prohashing.com
  // For now, we'll return mock data
  return {
    poolName: "Prohashing",
    workers: 12,
    currentHashrate: 485.6, // MH/s
    unpaidBalance: 0.0032, // BTC
    earnings24h: 68.45, // USD
    earningsChange: 5.2, // % change from yesterday
  };
}

/**
 * Fetch miners data
 */
export async function fetchMiners() {
  // In a real implementation, this would make an API call to Vnish firmware
  // For now, we'll return mock data
  return [
    {
      id: "miner-1",
      name: "Rig-01",
      model: "RTX 3080 x6",
      status: "online",
      hashrate: 125.3, // MH/s
      temperature: 62, // Celsius
      power: 1050, // Watts
      efficiency: 92, // %
      uptime: "5d 12h",
      gpus: 6,
    },
    {
      id: "miner-2",
      name: "Rig-02",
      model: "RTX 3070 x6",
      status: "online",
      hashrate: 118.7, // MH/s
      temperature: 58, // Celsius
      power: 900, // Watts
      efficiency: 88, // %
      uptime: "3d 8h",
      gpus: 6,
    },
    {
      id: "miner-3",
      name: "Rig-03",
      model: "RTX 3090 x6",
      status: "online",
      hashrate: 132.1, // MH/s
      temperature: 68, // Celsius
      power: 1200, // Watts
      efficiency: 95, // %
      uptime: "7d 3h",
      gpus: 6,
    },
    {
      id: "miner-4",
      name: "Rig-04",
      model: "RTX 3060 Ti x4",
      status: "offline",
      hashrate: 0, // MH/s
      temperature: 0, // Celsius
      power: 0, // Watts
      efficiency: 0, // %
      uptime: "0d 0h",
      gpus: 4,
    },
    {
      id: "miner-5",
      name: "Rig-05",
      model: "RTX 3070 x5",
      status: "online",
      hashrate: 109.5, // MH/s
      temperature: 61, // Celsius
      power: 850, // Watts
      efficiency: 85, // %
      uptime: "2d 15h",
      gpus: 5,
    },
    {
      id: "miner-6",
      name: "Rig-06",
      model: "RTX 3080 x4",
      status: "online",
      hashrate: 98.2, // MH/s
      temperature: 64, // Celsius
      power: 800, // Watts
      efficiency: 90, // %
      uptime: "4d 6h",
      gpus: 4,
    },
  ];
}

/**
 * Fetch analytics data
 */
export async function fetchAnalyticsData(timeRange = "7d") {
  // In a real implementation, this would make an API call to backend
  // For now, we'll return mock data
  return {
    avgHashrate: 485.6, // MH/s
    totalEarnings: timeRange === "24h" ? 68.45 : timeRange === "7d" ? 458.32 : timeRange === "30d" ? 1875.65 : 5620.78, // USD
    avgPower: 3200, // Watts
    efficiency: 0.152, // MH/W
    hashrateChange: 3.2, // % change from previous period
    earningsChange: 5.2, // % change from previous period
    powerChange: -1.5, // % change from previous period
    efficiencyChange: 4.8, // % change from previous period
    stabilityScore: 94, // %
    hashrateVariance: 3.5, // %
    peakHashrate: 512.3, // MH/s
    lowestHashrate: 465.8, // MH/s
    dailyAvgEarnings: 65.47, // USD
    powerCosts: 18.24, // USD
    netProfit: 47.23, // USD
    roi: 12.5, // %
    kwhPerDay: 76.8, // kWh
    costPerKwh: 0.12, // USD
    dailyPowerCost: 9.22, // USD
    powerVariance: 2.8, // %
    hashrateByMiner: [
      { name: "Rig-01", hashrate: 125.3 },
      { name: "Rig-02", hashrate: 118.7 },
      { name: "Rig-03", hashrate: 132.1 },
      { name: "Rig-05", hashrate: 109.5 },
    ],
    earningsByCoin: [
      { coin: "ETH", amount: 42.35 },
      { coin: "RVN", amount: 12.87 },
      { coin: "ETC", amount: 8.64 },
      { coin: "CFX", amount: 4.59 },
    ],
    powerByMiner: [
      { name: "Rig-01", power: 1050 },
      { name: "Rig-02", power: 900 },
      { name: "Rig-03", power: 1200 },
      { name: "Rig-05", power: 850 },
    ],
    efficiencyByMiner: [
      { name: "Rig-01", efficiency: 0.119 },
      { name: "Rig-02", efficiency: 0.132 },
      { name: "Rig-03", efficiency: 0.110 },
      { name: "Rig-05", efficiency: 0.129 },
    ],
    aiHashrateImprovement: 12.4,
    aiPowerReduction: 8.7,
    aiEfficiencyGain: 15.2,
    aiProfitIncrease: 18.5,
  };
}

/**
 * Fetch AI optimization data
 */
export async function fetchAiOptimizationData() {
  try {
    // Try to fetch from the ML engine via our API
    const response = await fetch('/api/recommendations/optimization');
    
    if (!response.ok) {
      throw new Error(`Failed to fetch AI optimization data: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.warn('Failed to fetch AI optimization data, using fallback mock data:', error);
    
    // Fallback to mock data if API call fails
    return {
      hashrateImprovement: 12.4, // %
      powerReduction: 8.7, // %
      efficiencyGain: 15.2, // %
      optimizationScore: 87, // out of 100
      hashrateChange: 2.3, // % change from last week
      powerChange: -1.8, // % change from last week
      efficiencyChange: 3.5, // % change from last week
      scoreChange: 4, // points change from last week
      lastOptimized: "Today, 08:45 AM",
      overclockingProfiles: [
        {
          id: "profile-1",
          name: "RTX 3080 Optimal",
          gpuModel: "NVIDIA RTX 3080",
          optimizationLevel: "High",
          coreClock: 1150,
          memoryClock: 10500,
          powerLimit: 220,
          fanSpeed: 70,
          performanceGain: 15.3,
          applied: true,
        },
        {
          id: "profile-2",
          name: "RTX 3070 Balanced",
          gpuModel: "NVIDIA RTX 3070",
          optimizationLevel: "Medium",
          coreClock: 1100,
          memoryClock: 8800,
          powerLimit: 130,
          fanSpeed: 65,
          performanceGain: 12.8,
          applied: true,
        },
        {
          id: "profile-3",
          name: "RTX 3090 Performance",
          gpuModel: "NVIDIA RTX 3090",
          optimizationLevel: "Extreme",
          coreClock: 1200,
          memoryClock: 11000,
          powerLimit: 280,
          fanSpeed: 80,
          performanceGain: 18.5,
          applied: false,
        },
        {
          id: "profile-4",
          name: "RTX 3060 Ti Efficient",
          gpuModel: "NVIDIA RTX 3060 Ti",
          optimizationLevel: "Low",
          coreClock: 1050,
          memoryClock: 8000,
          powerLimit: 110,
          fanSpeed: 60,
          performanceGain: 9.7,
          applied: false,
        },
      ],
      dynamicTuning: {
        enabled: true,
        currentMode: "Balanced",
        adjustmentFrequency: "Every 30 minutes",
        temperatureThreshold: 70,
        lastAdjustment: "15 minutes ago",
        aggressiveness: 65,
        impact: {
          stabilityImprovement: 8.3,
          temperatureReduction: 4.5,
          uptimeImprovement: 3.2,
        },
        history: [
          {
            type: "increase",
            description: "Increased memory clock on Rig-01 by 200MHz",
            time: "15 minutes ago",
          },
          {
            type: "decrease",
            description: "Reduced power limit on Rig-03 by 10W due to high temperature",
            time: "45 minutes ago",
          },
          {
            type: "optimize",
            description: "Applied balanced profile to Rig-02",
            time: "1 hour ago",
          },
          {
            type: "increase",
            description: "Increased core clock on Rig-05 by 50MHz",
            time: "2 hours ago",
          },
          {
            type: "decrease",
            description: "Reduced memory clock on Rig-03 by 100MHz to improve stability",
            time: "3 hours ago",
          },
        ],
      },
      insights: {
        recommendations: [
          {
            type: "critical",
            title: "Reduce memory clock on Rig-03",
            description: "Memory temperature is approaching critical levels. Reducing memory clock by 200MHz is recommended.",
            impact: "Prevent thermal throttling",
          },
          {
            type: "warning",
            title: "Increase fan speed on Rig-01",
            description: "GPU temperatures are higher than optimal. Increasing fan speed to 75% will improve cooling.",
            impact: "Lower temperatures by 5-7°C",
          },
          {
            type: "optimization",
            title: "Apply efficiency profile to Rig-02",
            description: "Current settings are not optimal for power efficiency. Our AI model suggests a more balanced approach.",
            impact: "Improve efficiency by 8.5%",
          },
        ],
        predictions: {
          hashrateTrend: 2.5,
          earningsForecast: 3.8,
          hardwareHealth: "Good",
          optimalAlgorithm: "Ethash",
        },
        learning: {
          trainingProgress: 87,
          dataPoints: 145280,
          modelVersion: "v2.3.1",
          accuracy: 92.5,
          nextUpdate: "Tomorrow, 02:00 AM",
        },
      },
    };
  }
}

/**
 * Apply AI optimization settings
 */
export async function applyAiOptimization(optimizationLevel: number) {
  try {
    // Try to apply optimization via our API
    const response = await fetch('/api/recommendations/apply', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ optimizationLevel }),
    });
    
    if (!response.ok) {
      throw new Error(`Failed to apply AI optimization: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.warn('Failed to apply AI optimization, simulating success:', error);
    
    // Simulate success if API call fails
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, message: "Optimization applied successfully (simulated)" });
      }, 1500);
    });
  }
}