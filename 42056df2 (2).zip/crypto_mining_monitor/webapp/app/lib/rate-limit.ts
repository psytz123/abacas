
/**
 * Simple in-memory rate limiting implementation
 */

interface RateLimitOptions {
  interval: number; // Time window in milliseconds
  uniqueTokenPerInterval: number; // Max number of unique tokens per interval
}

interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: number;
}

export function rateLimit(options: RateLimitOptions) {
  const { interval, uniqueTokenPerInterval } = options;
  const tokenCache = new Map<string, number[]>();
  
  // Clean up function to remove old tokens
  const cleanup = () => {
    const now = Date.now();
    for (const [key, timestamps] of tokenCache.entries()) {
      const newTimestamps = timestamps.filter(timestamp => now - timestamp < interval);
      if (newTimestamps.length > 0) {
        tokenCache.set(key, newTimestamps);
      } else {
        tokenCache.delete(key);
      }
    }
  };
  
  // Set up periodic cleanup
  setInterval(cleanup, interval);
  
  return {
    check: async (token: string, limit: number): Promise<RateLimitResult> => {
      const now = Date.now();
      const timestamps = tokenCache.get(token) || [];
      const validTimestamps = timestamps.filter(timestamp => now - timestamp < interval);
      
      // Add current timestamp
      validTimestamps.push(now);
      
      // Update cache
      tokenCache.set(token, validTimestamps);
      
      // Ensure cache doesn't grow too large
      if (tokenCache.size > uniqueTokenPerInterval) {
        cleanup();
      }
      
      const remaining = Math.max(0, limit - validTimestamps.length);
      const reset = now + interval;
      
      return {
        success: validTimestamps.length <= limit,
        limit,
        remaining,
        reset
      };
    }
  };
}
