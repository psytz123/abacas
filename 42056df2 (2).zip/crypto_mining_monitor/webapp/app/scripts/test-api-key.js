// Import the API key functions
const { generateApiKey, validateApiKeyFormat, parseApiKey } = require('../lib/api-key');

// Test API key generation
console.log('Testing API key generation and validation...');

// Generate 5 API keys and validate them
for (let i = 0; i < 5; i++) {
  const apiKey = generateApiKey();
  const isValid = validateApiKeyFormat(apiKey);
  const parsed = parseApiKey(apiKey);
  
  console.log(`\nAPI Key ${i + 1}: ${apiKey}`);
  console.log(`Valid format: ${isValid}`);
  console.log('Parsed components:', parsed);
  
  // Verify key length
  console.log(`Total length: ${apiKey.length}`);
  console.log(`Hex part length: ${parsed?.key.length}`);
  
  // Verify parts
  if (parsed) {
    console.log(`Prefix: ${parsed.prefix === 'mk' ? 'Correct ✓' : 'Incorrect ✗'}`);
    console.log(`Timestamp: ${parsed.timestamp.length > 0 ? 'Present ✓' : 'Missing ✗'}`);
    console.log(`Hex key: ${parsed.key.length === 64 ? 'Correct length ✓' : 'Incorrect length ✗'}`);
  }
}

// Test invalid API keys
console.log('\n\nTesting invalid API keys:');
const invalidKeys = [
  '',
  'invalid',
  'mk_timestamp_tooshort',
  'xx_timestamp_' + '0'.repeat(64),
  'mk_' + 'toolong_' + '0'.repeat(65),
  'mk_no_underscore',
  'mk__' + '0'.repeat(64)
];

for (const key of invalidKeys) {
  try {
    const isValid = validateApiKeyFormat(key);
    console.log(`Key: ${key} - Valid: ${isValid}`);
  } catch (error) {
    console.log(`Key: ${key} - Error: ${error?.message || 'Unknown error'}`);
  }
}

console.log('\nAPI key testing complete!');
