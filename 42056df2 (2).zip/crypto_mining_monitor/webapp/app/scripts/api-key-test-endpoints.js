/**
 * API Key Endpoint Testing Script
 * 
 * This script helps test the API key generation and validation endpoints.
 * Run this script with Node.js to test the API endpoints.
 * 
 * Usage:
 * 1. Start the Next.js development server: npm run dev
 * 2. Run this script: node scripts/api-key-test-endpoints.js
 */

const fetch = require('node-fetch');

// Configuration
const BASE_URL = 'http://localhost:3000';
const TEST_USER_TOKEN = 'YOUR_AUTH_TOKEN'; // Replace with a valid JWT token

async function testApiKeyEndpoints() {
  console.log('🔑 API Key Endpoint Testing Script 🔑');
  console.log('=====================================\n');

  try {
    // 1. Create a new API key
    console.log('1. Creating a new API key...');
    const createResponse = await fetch(`${BASE_URL}/api/api-keys`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TEST_USER_TOKEN}`
      },
      body: JSON.stringify({
        name: 'Test API Key ' + new Date().toISOString()
      })
    });

    const createData = await createResponse.json();
    
    if (!createResponse.ok) {
      console.error('❌ Failed to create API key:', createData.error);
      console.log('Status:', createResponse.status);
      console.log('Make sure you have a valid JWT token set in TEST_USER_TOKEN');
      return;
    }

    console.log('✅ API key created successfully!');
    console.log('API Key:', createData.key);
    console.log('ID:', createData.id);
    console.log('Name:', createData.name);
    console.log('Created At:', createData.createdAt);
    
    const apiKey = createData.key;

    // 2. Validate the API key
    console.log('\n2. Validating the API key...');
    const validateResponse = await fetch(`${BASE_URL}/api/api-keys/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        apiKey
      })
    });

    const validateData = await validateResponse.json();
    
    if (!validateResponse.ok) {
      console.error('❌ API key validation failed:', validateData.error);
      console.log('Status:', validateResponse.status);
      if (validateData.details) {
        console.log('Details:', validateData.details);
      }
      return;
    }

    console.log('✅ API key validated successfully!');
    console.log('Valid:', validateData.valid);
    console.log('API Key ID:', validateData.apiKey.id);
    console.log('API Key Name:', validateData.apiKey.name);
    console.log('User ID:', validateData.apiKey.userId);
    console.log('Last Used:', validateData.apiKey.lastUsed);

    // 3. Test with invalid API key
    console.log('\n3. Testing with invalid API key...');
    const invalidKey = apiKey.replace('mk_', 'xx_');
    const invalidResponse = await fetch(`${BASE_URL}/api/api-keys/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        apiKey: invalidKey
      })
    });

    const invalidData = await invalidResponse.json();
    console.log('Status:', invalidResponse.status);
    console.log('Response:', invalidData);

    // 4. Get all API keys
    console.log('\n4. Getting all API keys...');
    const getResponse = await fetch(`${BASE_URL}/api/api-keys`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${TEST_USER_TOKEN}`
      }
    });

    const getData = await getResponse.json();
    
    if (!getResponse.ok) {
      console.error('❌ Failed to get API keys:', getData.error);
      console.log('Status:', getResponse.status);
      return;
    }

    console.log('✅ Retrieved API keys successfully!');
    console.log('Total API keys:', getData.length);
    console.log('First 3 API keys:');
    getData.slice(0, 3).forEach((key, index) => {
      console.log(`\n[${index + 1}] ID: ${key.id}`);
      console.log(`    Name: ${key.name}`);
      console.log(`    Created: ${key.createdAt}`);
      console.log(`    Active: ${key.active}`);
    });

    console.log('\n✅ All tests completed successfully!');
  } catch (error) {
    console.error('❌ Error during testing:', error.message);
    console.log('Make sure the Next.js development server is running on http://localhost:3000');
  }
}

testApiKeyEndpoints();
