export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { validateApiKeyFormat } from '@/lib/api-key'

export async function POST(request: NextRequest) {
  try {
    const { apiKey } = await request.json()
    
    if (!apiKey) {
      return NextResponse.json({ 
        error: 'API key is required',
        valid: false 
      }, { status: 400 })
    }

    // First validate the format
    if (!validateApiKeyFormat(apiKey)) {
      return NextResponse.json({ 
        error: 'Wrong apikey format. Expected format: mk_<timestamp>_<64_char_hex>',
        valid: false,
        details: {
          expected: 'mk_<timestamp>_<64_char_hex>',
          received: apiKey,
          length: apiKey.length
        }
      }, { status: 400 })
    }

    // Check if API key exists in database
    const existingApiKey = await prisma.apiKey.findUnique({
      where: { key: apiKey },
      include: { user: true }
    })

    if (!existingApiKey) {
      return NextResponse.json({ 
        error: 'API key not found',
        valid: false 
      }, { status: 404 })
    }

    if (!existingApiKey.active) {
      return NextResponse.json({ 
        error: 'API key is inactive',
        valid: false 
      }, { status: 403 })
    }

    // Update last used timestamp
    await prisma.apiKey.update({
      where: { id: existingApiKey.id },
      data: { lastUsed: new Date() }
    })

    return NextResponse.json({ 
      valid: true,
      apiKey: {
        id: existingApiKey.id,
        name: existingApiKey.name,
        userId: existingApiKey.userId,
        lastUsed: new Date()
      }
    })
  } catch (error) {
    console.error('Validate API key error:', error)
    return NextResponse.json({ 
      error: 'Internal server error',
      valid: false 
    }, { status: 500 })
  }
}