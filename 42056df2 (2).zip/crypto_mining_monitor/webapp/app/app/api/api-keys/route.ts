export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyToken } from '@/lib/auth'
import { generateApiKey, validateApiKeyFormat } from '@/lib/api-key'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const apiKeys = await prisma.apiKey.findMany({
      where: { userId: payload.userId },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        key: true,
        active: true,
        lastUsed: true,
        createdAt: true,
        updatedAt: true
      }
    })

    return NextResponse.json(apiKeys)
  } catch (error) {
    console.error('Get API keys error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const { name } = await request.json()
    if (!name) {
      return NextResponse.json({ error: 'API key name is required' }, { status: 400 })
    }

    // Generate new API key
    const apiKey = generateApiKey()
    
    // Validate the generated key format
    if (!validateApiKeyFormat(apiKey)) {
      return NextResponse.json({ error: 'Failed to generate valid API key format' }, { status: 500 })
    }

    const newApiKey = await prisma.apiKey.create({
      data: {
        key: apiKey,
        name,
        userId: payload.userId
      }
    })

    return NextResponse.json(newApiKey)
  } catch (error) {
    console.error('Create API key error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}