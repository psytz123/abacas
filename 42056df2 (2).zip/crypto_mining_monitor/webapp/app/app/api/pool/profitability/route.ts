import { NextResponse } from "next/server";
import { ProHashingClient } from "@/lib/prohashing/api-client";
import { Profitability } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const client = new ProHashingClient({
      apiKey: process.env.PROHASHING_API_KEY || "",
      apiSecret: process.env.PROHASHING_API_SECRET || "",
      baseUrl: process.env.PROHASHING_BASE_URL || "https://api.prohashing.com",
      userId: process.env.PROHASHING_USER_ID || "",
    });
    
    // Fetch mining stats from ProHashing
    const miningStats = await client.getMiningStats();
    
    // Fetch profitability data
    const profitabilityData = await client.getProfitabilityData();
    
    // Get current BTC price (in a real implementation, this would come from a price API)
    const btcPrice = profitabilityData.btcPrice || 60000; // Default to $60,000 if not available
    
    // Calculate power costs (in a real implementation, this would be configurable)
    const dailyPowerCost = 3.75; // $3.75 per day
    
    // Calculate profitability metrics
    const profitability: Profitability = {
      daily: miningStats.earnings.today,
      weekly: miningStats.earnings.thisWeek,
      monthly: miningStats.earnings.thisMonth,
      currency: "BTC",
      fiatValue: {
        daily: miningStats.earnings.today * btcPrice,
        weekly: miningStats.earnings.thisWeek * btcPrice,
        monthly: miningStats.earnings.thisMonth * btcPrice,
        currency: "USD"
      },
      coins: miningStats.coins,
      estimatedAnnual: miningStats.earnings.today * 365,
      breakEvenDays: Math.round((5000 / (miningStats.earnings.today * btcPrice - dailyPowerCost)) || 0), // Assuming $5000 investment
      roi: ((miningStats.earnings.today * btcPrice - dailyPowerCost) * 365) / 5000, // Annual ROI
      powerCost: {
        daily: dailyPowerCost,
        weekly: dailyPowerCost * 7,
        monthly: dailyPowerCost * 30,
        currency: "USD"
      }
    };
    
    return NextResponse.json(profitability, { status: 200 });
  } catch (error) {
    console.error("Error fetching pool profitability:", error);
    return NextResponse.json(
      { error: "Failed to fetch pool profitability" },
      { status: 500 }
    );
  }
}
