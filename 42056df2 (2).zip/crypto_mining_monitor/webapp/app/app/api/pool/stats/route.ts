import { NextResponse } from "next/server";
import { ProHashingClient } from "@/lib/prohashing/api-client";
import { PoolStats } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const client = new ProHashingClient({
      apiKey: process.env.PROHASHING_API_KEY || "",
      apiSecret: process.env.PROHASHING_API_SECRET || "",
      baseUrl: process.env.PROHASHING_BASE_URL || "https://api.prohashing.com",
      userId: process.env.PROHASHING_USER_ID || "",
    });
    
    // Fetch pool stats from ProHashing
    const poolStats: PoolStats = await client.getPoolStats();
    
    return NextResponse.json(poolStats, { status: 200 });
  } catch (error) {
    console.error("Error fetching pool stats:", error);
    
    // Provide more detailed error message if available
    const errorMessage = error instanceof Error 
      ? error.message 
      : "Failed to fetch pool stats";
    
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
}
