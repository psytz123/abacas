import { NextRequest, NextResponse } from 'next/server';
import { AbacusServingClient } from '@/lib/abacus/serving_client';
import { VNishFirmwareClient } from '@/lib/vnish/firmware-client';
import { getUserFromToken } from '@/lib/auth';
import { handleApiError } from '@/lib/errors';
import { prisma } from '@/lib/prisma';

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    // Initialize VNish client
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    // Get miners for the user
    const miners = await prisma.miner.findMany({
      where: { userId: user.id },
      select: {
        id: true,
        ipAddress: true,
        status: true
      },
      take: 50 // Limit to 50 miners for performance
    });
    
    // Collect telemetry data for all miners
    const minerTelemetryData = [];
    for (const miner of miners) {
      if (miner.ipAddress) {
        try {
          const telemetry = await vnishClient.getTelemetry(miner.ipAddress);
          if (telemetry) {
            minerTelemetryData.push(telemetry);
          }
        } catch (error) {
          console.error(`Failed to get telemetry for miner ${miner.id}:`, error);
        }
      }
    }
    
    // Get user preferences from database
    const userPreferences = await prisma.userPreference.findUnique({
      where: { userId: user.id }
    }) || {
      minImprovementThreshold: 0.05,
      confidenceThreshold: 0.7,
      cooldownPeriodHours: 12,
      minEfficiencyImprovement: 0.03,
      maxHashrateReduction: 0.05,
      minProfitImprovement: 0.03,
      minHashrateImprovement: 0.05,
      minStabilityScore: 0.8,
      maxTemperatureIncrease: 5,
      optimizationGoal: "balanced"
    };
    
    // Get recommendations from Abacus
    const features = {
      miner_telemetry: minerTelemetryData,
      user_preferences: {
        // Coin switching preferences
        min_improvement_threshold: userPreferences.minImprovementThreshold,
        confidence_threshold: userPreferences.confidenceThreshold,
        cooldown_period_hours: userPreferences.cooldownPeriodHours,
        
        // Power optimization preferences
        min_efficiency_improvement: userPreferences.minEfficiencyImprovement,
        max_hashrate_reduction: userPreferences.maxHashrateReduction,
        
        // Dynamic hashrate tuning preferences
        min_profit_improvement: userPreferences.minProfitImprovement,
        
        // Intelligent overclocking preferences
        min_hashrate_improvement: userPreferences.minHashrateImprovement,
        min_stability_score: userPreferences.minStabilityScore,
        max_temperature_increase: userPreferences.maxTemperatureIncrease,
        optimization_goal: userPreferences.optimizationGoal
      }
    };
    
    const predictions = await abacusClient.getPredictions(features);
    
    // Extract recommendations from predictions
    const hashrateRecommendations = predictions.dynamic_hashrate_tuning || [];
    const overclockingRecommendations = predictions.intelligent_overclocking || [];
    
    // Calculate average improvements from recommendations
    const calculateAverage = (arr: any[], field: string) => {
      if (arr.length === 0) return 0;
      return arr.reduce((sum, item) => sum + (item[field] || 0), 0) / arr.length;
    };
    
    const hashrateImprovement = calculateAverage(hashrateRecommendations, 'profit_improvement_percent');
    const powerReduction = calculateAverage(overclockingRecommendations, 'power_change_percent') * -1; // Invert to make reduction positive
    const efficiencyGain = calculateAverage(overclockingRecommendations, 'efficiency_improvement_percent');
    
    // Get recommendations from Abacus
    const recommendationsResponse = await abacusClient.getRecommendations(user.id);
    
    // Transform the recommendations into the format expected by the frontend
    const optimizationData = {
      hashrateImprovement: hashrateImprovement || 0,
      powerReduction: powerReduction || 0,
      efficiencyGain: efficiencyGain || 0,
      optimizationScore: Math.round((hashrateImprovement + powerReduction + efficiencyGain) / 3 * 10) || 0,
      hashrateChange: hashrateRecommendations.length > 0 ? hashrateRecommendations[0].hashrate_change_percent : 0,
      powerChange: overclockingRecommendations.length > 0 ? overclockingRecommendations[0].power_change_percent : 0,
      efficiencyChange: overclockingRecommendations.length > 0 ? overclockingRecommendations[0].efficiency_improvement_percent : 0,
      scoreChange: 0,
      lastOptimized: new Date().toISOString(),
      overclockingProfiles: overclockingRecommendations.length > 0 ? 
        overclockingRecommendations.map((rec: any, index: number) => ({
          id: rec.id || `profile-${index + 1}`,
          name: rec.profile_name || `${rec.hardware_type} ${rec.algorithm}`,
          gpuModel: rec.hardware_type || "ASIC Miner",
          optimizationLevel: rec.optimization_goal || "Balanced",
          coreClock: rec.core_clock_offset || 0,
          memoryClock: rec.memory_clock_offset || 0,
          powerLimit: rec.power_limit_percent || 100,
          coreVoltage: rec.core_voltage_offset || 0,
          performanceGain: rec.hashrate_improvement_percent || 0,
          applied: false,
          stabilityScore: rec.stability_score || 0.9,
          confidence: rec.confidence || 0.8,
        })) : [],
      dynamicTuning: {
        enabled: hashrateRecommendations.length > 0,
        currentMode: userPreferences.optimizationGoal || "Balanced",
        adjustmentFrequency: "Every 30 minutes",
        temperatureThreshold: userPreferences.maxTemperatureIncrease || 70,
        lastAdjustment: new Date().toISOString(),
        aggressiveness: userPreferences.minImprovementThreshold * 100 || 65,
        impact: {
          stabilityImprovement: hashrateRecommendations.length > 0 ? 
            hashrateRecommendations[0].stability_improvement || 0 : 0,
          temperatureReduction: overclockingRecommendations.length > 0 ? 
            overclockingRecommendations[0].temperature_change || 0 : 0,
          uptimeImprovement: hashrateRecommendations.length > 0 ? 
            hashrateRecommendations[0].uptime_improvement || 0 : 0,
        },
        history: hashrateRecommendations.length > 0 ? 
          hashrateRecommendations.map((rec: any) => ({
            type: rec.hashrate_change_percent > 0 ? "increase" : "decrease",
            description: `Adjusted hashrate to ${rec.recommended_hashrate_percent?.toFixed(1) || 0}% (${Math.abs(rec.hashrate_change_percent || 0).toFixed(1)}% ${rec.hashrate_change_percent > 0 ? 'increase' : 'decrease'})`,
            time: new Date(rec.timestamp || Date.now()).toISOString(),
            profitImprovement: rec.profit_improvement_percent || 0,
            confidence: rec.confidence || 0
          })) : [],
      },
      insights: {
        recommendations: [
          ...(hashrateRecommendations.map((rec: any) => ({
            type: "optimization",
            title: `Adjust hashrate to ${rec.recommended_hashrate_percent?.toFixed(1) || 0}%`,
            description: rec.reasoning || "Optimize hashrate for better performance",
            impact: `Profit: +${(rec.profit_improvement_percent || 0).toFixed(1)}%, Confidence: ${((rec.confidence || 0) * 100).toFixed(1)}%`,
          }))),
          ...(overclockingRecommendations.map((rec: any) => ({
            type: "critical",
            title: `Apply ${rec.profile_name || "optimized"} overclocking profile`,
            description: rec.reasoning || "Apply optimized settings for better performance",
            impact: `Hashrate: +${(rec.hashrate_improvement_percent || 0).toFixed(1)}%, Efficiency: +${(rec.efficiency_improvement_percent || 0).toFixed(1)}%`,
          }))),
          ...(recommendationsResponse.recommendations.optimization?.slice(0, 3).map((rec: any) => ({
            type: rec.impact === 'high' ? "critical" : rec.impact === 'medium' ? "warning" : "optimization",
            title: rec.title,
            description: rec.description,
            impact: `Confidence: ${(rec.confidence * 100).toFixed(1)}%`,
          })) || [])
        ].slice(0, 5),
        predictions: {
          hashrateTrend: hashrateRecommendations.length > 0 ? hashrateRecommendations[0].hashrate_change_percent || 0 : 0,
          earningsForecast: hashrateRecommendations.length > 0 ? hashrateRecommendations[0].profit_improvement_percent || 0 : 0,
          hardwareHealth: "Good",
          optimalAlgorithm: overclockingRecommendations.length > 0 ? overclockingRecommendations[0].algorithm || "SHA-256" : "SHA-256",
        },
        learning: {
          trainingProgress: 100,
          dataPoints: minerTelemetryData.length * 1000 || 0,
          modelVersion: "v1.0.0",
          accuracy: 90,
          nextUpdate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        },
      },
    };
    
    return NextResponse.json(optimizationData);
  } catch (error) {
    return handleApiError(error);
  }
}
