export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { handleApiError, BadRequestError } from '@/lib/errors';
import { AbacusServingClient } from '@/lib/abacus/serving_client';
import { getUserFromToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    // Get query parameters
    const url = new URL(request.url);
    const type = url.searchParams.get('type');
    const status = url.searchParams.get('status');
    
    // Fetch recommendations from Abacus
    const recommendationsResponse = await abacusClient.getRecommendations(user.id);
    
    // Filter recommendations if needed
    if (type || status) {
      const filteredRecommendations: Record<string, any[]> = {};
      
      Object.entries(recommendationsResponse.recommendations).forEach(([recType, recs]) => {
        if (type && recType !== type) return;
        
        const filteredRecs = status 
          ? recs.filter(rec => rec.status === status)
          : recs;
        
        if (filteredRecs.length > 0) {
          filteredRecommendations[recType] = filteredRecs;
        }
      });
      
      return NextResponse.json({
        recommendations: filteredRecommendations,
        lastUpdated: recommendationsResponse.lastUpdated
      });
    }
    
    return NextResponse.json(recommendationsResponse);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    
    if (!body.recommendationId) {
      throw new BadRequestError('Recommendation ID is required');
    }
    
    if (!body.action || !['apply', 'reject', 'dismiss'].includes(body.action)) {
      throw new BadRequestError('Valid action (apply, reject, or dismiss) is required');
    }
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    // Map action to status
    const statusMap = {
      'apply': 'applied',
      'reject': 'rejected',
      'dismiss': 'in_progress'
    } as const;
    
    // Update recommendation status
    const success = await abacusClient.updateRecommendationStatus(
      body.recommendationId,
      statusMap[body.action as keyof typeof statusMap]
    );
    
    if (!success) {
      throw new Error(`Failed to ${body.action} recommendation`);
    }
    
    return NextResponse.json({
      success: true,
      message: `Recommendation ${body.recommendationId} ${body.action}ed successfully`
    });
  } catch (error) {
    return handleApiError(error);
  }
}
