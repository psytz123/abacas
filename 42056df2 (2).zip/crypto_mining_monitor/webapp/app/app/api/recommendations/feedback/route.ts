import { NextRequest, NextResponse } from "next/server";
import { AbacusServingClient } from "@/lib/abacus/serving_client";
import { getUserFromToken } from "@/lib/auth";
import { handleApiError, BadRequestError } from "@/lib/errors";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    
    if (!body.recommendationId) {
      throw new BadRequestError("Recommendation ID is required");
    }
    
    if (body.helpful === undefined) {
      throw new BadRequestError("Feedback helpfulness is required");
    }
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    // Submit feedback
    const result = await abacusClient.submitRecommendationFeedback({
      recommendationId: body.recommendationId,
      helpful: body.helpful,
      comment: body.comment
    });
    
    // Update recommendation in database if needed
    // This would be implemented in a real application
    
    return NextResponse.json(
      { success: result },
      { status: 200 }
    );
  } catch (error) {
    return handleApiError(error);
  }
}
