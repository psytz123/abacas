import { NextRequest, NextResponse } from 'next/server';
import { VNishFirmwareClient } from '@/lib/vnish/firmware-client';
import { AbacusServingClient } from '@/lib/abacus/serving_client';
import { getUserFromToken } from '@/lib/auth';
import { handleApiError, BadRequestError } from '@/lib/errors';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    
    // Validate request body
    if (!body.recommendation_id) {
      throw new BadRequestError('Missing recommendation_id in request body');
    }
    
    // Extract parameters
    const { recommendation_id, miner_ip, miner_id, dry_run = false } = body;
    
    // Initialize VNish client
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    let ipAddress = miner_ip;
    
    // If miner_id is provided but not miner_ip, look up the IP address
    if (!ipAddress && miner_id) {
      const miner = await prisma.miner.findUnique({
        where: { 
          id: miner_id,
          userId: user.id // Ensure the miner belongs to the user
        }
      });
      
      if (!miner) {
        throw new BadRequestError('Miner not found');
      }
      
      if (!miner.ipAddress) {
        throw new BadRequestError('Miner has no IP address configured');
      }
      
      ipAddress = miner.ipAddress;
    }
    
    // Apply the recommendation
    const result = await vnishClient.applyRecommendation(recommendation_id, ipAddress, dry_run);
    
    // If not a dry run and the application was successful, update the recommendation status
    if (!dry_run && result.success) {
      await abacusClient.updateRecommendationStatus(recommendation_id, 'applied');
    }
    
    return NextResponse.json(result);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function GET(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const searchParams = request.nextUrl.searchParams;
    const recommendationId = searchParams.get('recommendation_id');
    const minerIp = searchParams.get('miner_ip');
    const minerId = searchParams.get('miner_id');
    const dryRun = searchParams.get('dry_run') === 'true';
    
    if (!recommendationId) {
      throw new BadRequestError('Missing recommendation_id query parameter');
    }
    
    // Initialize VNish client
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    let ipAddress = minerIp;
    
    // If miner_id is provided but not miner_ip, look up the IP address
    if (!ipAddress && minerId) {
      const miner = await prisma.miner.findUnique({
        where: { 
          id: minerId,
          userId: user.id // Ensure the miner belongs to the user
        }
      });
      
      if (!miner) {
        throw new BadRequestError('Miner not found');
      }
      
      if (!miner.ipAddress) {
        throw new BadRequestError('Miner has no IP address configured');
      }
      
      ipAddress = miner.ipAddress;
    }
    
    // Apply the recommendation
    const result = await vnishClient.applyRecommendation(recommendationId, ipAddress, dryRun);
    
    // If not a dry run and the application was successful, update the recommendation status
    if (!dryRun && result.success) {
      await abacusClient.updateRecommendationStatus(recommendationId, 'applied');
    }
    
    return NextResponse.json(result);
  } catch (error) {
    return handleApiError(error);
  }
}
