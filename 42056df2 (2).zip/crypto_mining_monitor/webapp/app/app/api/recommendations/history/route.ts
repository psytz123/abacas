import { NextRequest, NextResponse } from "next/server";
import { AbacusServingClient } from "@/lib/abacus/serving_client";
import { getUserFromToken } from "@/lib/auth";
import { handleApiError } from "@/lib/errors";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    // Get user from token
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get("page") || "1");
    const pageSize = parseInt(url.searchParams.get("pageSize") || "10");
    const status = url.searchParams.get("status") || undefined;
    const type = url.searchParams.get("type") || undefined;
    
    // Initialize Abacus client
    const abacusClient = new AbacusServingClient({
      apiKey: process.env.ABACUS_API_KEY,
      endpoint: process.env.ABACUS_ENDPOINT || 'https://api.abacus.ai',
      region: process.env.ABACUS_REGION || 'us-west-2',
      modelName: process.env.ABACUS_MODEL_NAME || 'mining-recommendations'
    });
    
    // Fetch recommendation history
    const history = await abacusClient.getRecommendationHistory(
      user.id,
      page,
      pageSize,
      status,
      type
    );
    
    return NextResponse.json(history, { status: 200 });
  } catch (error) {
    return handleApiError(error);
  }
}
