import { NextResponse } from "next/server";
import { FeatureStoreManager } from "@/lib/abacus/feature_store_setup";

export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<NextResponse> {
  try {
    // Parse the request body
    const body = await request.json();
    
    // Validate the request
    if (!body.data_type || !body.data) {
      return NextResponse.json(
        { error: "Missing required fields: data_type and data" },
        { status: 400 }
      );
    }
    
    // Initialize the feature store manager
    const manager = new FeatureStoreManager();
    await manager.initialize();
    
    // Upload data to the appropriate feature store
    let uploadJobId;
    
    switch (body.data_type) {
      case "miner_telemetry":
        uploadJobId = await manager.uploadMinerTelemetryData(body.data);
        break;
      case "pool_performance":
        uploadJobId = await manager.uploadPoolPerformanceData(body.data);
        break;
      case "market_data":
        uploadJobId = await manager.uploadMarketData(body.data);
        break;
      case "derived_metrics":
        uploadJobId = await manager.uploadDerivedMetrics(body.data);
        break;
      default:
        return NextResponse.json(
          { error: `Invalid data_type: ${body.data_type}` },
          { status: 400 }
        );
    }
    
    return NextResponse.json({ 
      success: true, 
      message: "Data ingested successfully",
      upload_job_id: uploadJobId,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error ingesting data:", error);
    return NextResponse.json(
      { 
        error: "Failed to ingest data",
        message: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}