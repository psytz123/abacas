export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server';
import { ProHashingClient } from '@/lib/prohashing/api-client';
import { VNishFirmwareClient } from '@/lib/vnish/firmware-client';
import { DashboardSummary } from '@/lib/types';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    // Initialize API clients
    const proHashingClient = new ProHashingClient({
      apiKey: process.env.PROHASHING_API_KEY || '',
      apiSecret: process.env.PROHASHING_API_SECRET || '',
      baseUrl: process.env.PROHASHING_BASE_URL || 'https://api.prohashing.com',
      userId: process.env.PROHASHING_USER_ID || '',
    });
    
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    // Fetch mining stats from ProHashing
    const miningStats = await proHashingClient.getMiningStats();
    
    // Fetch miners from the database to get the count of active rigs
    const miners = await prisma.miner.findMany({
      where: { status: 'online' },
      select: {
        id: true,
        ipAddress: true
      },
      take: 100 // Limit to 100 miners for performance
    });
    
    // Calculate average temperature from miners
    let totalTemperature = 0;
    let minerCount = 0;
    
    for (const miner of miners) {
      if (miner.ipAddress) {
        try {
          const telemetry = await vnishClient.getTelemetry(miner.ipAddress);
          if (telemetry) {
            totalTemperature += telemetry.temperature.avg_chip;
            minerCount++;
          }
        } catch (error) {
          console.error(`Failed to get telemetry for miner ${miner.id}:`, error);
        }
      }
    }
    
    const avgTemperature = minerCount > 0 ? totalTemperature / minerCount : 0;
    
    // Calculate efficiency (accepted shares / total shares)
    const efficiency = miningStats.acceptedShares / 
      (miningStats.acceptedShares + miningStats.rejectedShares + miningStats.invalidShares) * 100;
    
    // Create dashboard summary
    const stats: DashboardSummary = {
      totalHashrate: miningStats.hashrate,
      activeRigs: miners.filter(m => m.status === 'online').length,
      totalRevenue: miningStats.earnings.today,
      avgTemperature,
      efficiency,
      uptime: 99.8, // This would ideally come from a monitoring service
      timestamp: new Date().toISOString()
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Error fetching mining stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch mining stats' },
      { status: 500 }
    );
  }
}
