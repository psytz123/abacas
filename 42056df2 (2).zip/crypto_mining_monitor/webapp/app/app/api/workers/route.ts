export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyToken } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const workers = await prisma.worker.findMany({
      where: { userId: payload.userId },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        status: true,
        hashRate: true,
        temperature: true,
        power: true,
        uptime: true,
        ipAddress: true,
        port: true,
        createdAt: true,
        updatedAt: true
      }
    })

    return NextResponse.json(workers)
  } catch (error) {
    console.error('Get workers error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const { name, ipAddress, port } = await request.json()
    if (!name || !ipAddress || !port) {
      return NextResponse.json({ error: 'Name, IP address, and port are required' }, { status: 400 })
    }

    // Check if worker with same IP and port already exists
    const existingWorker = await prisma.worker.findFirst({
      where: {
        userId: payload.userId,
        ipAddress: ipAddress.trim(),
        port: parseInt(port)
      }
    })

    if (existingWorker) {
      return NextResponse.json({ error: 'Worker with this IP and port already exists' }, { status: 400 })
    }

    const newWorker = await prisma.worker.create({
      data: {
        name: name.trim(),
        ipAddress: ipAddress.trim(),
        port: parseInt(port),
        userId: payload.userId,
        status: 'connecting',
        hashRate: 0,
        temperature: 0,
        power: 0,
        uptime: 0
      }
    })

    // Simulate worker connection and status update
    setTimeout(async () => {
      try {
        await prisma.worker.update({
          where: { id: newWorker.id },
          data: {
            status: Math.random() > 0.3 ? 'online' : 'offline',
            hashRate: Math.random() * 100 + 50,
            temperature: Math.random() * 20 + 60,
            power: Math.random() * 500 + 1000,
            uptime: Math.floor(Math.random() * 86400)
          }
        })
      } catch (error) {
        console.error('Error updating worker status:', error)
      }
    }, 2000)

    return NextResponse.json(newWorker)
  } catch (error) {
    console.error('Create worker error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    
    if (!id) {
      return NextResponse.json({ error: 'Worker ID is required' }, { status: 400 })
    }

    await prisma.worker.delete({
      where: { id }
    })

    return NextResponse.json({ message: 'Worker deleted successfully' })
  } catch (error) {
    console.error('Delete worker error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}