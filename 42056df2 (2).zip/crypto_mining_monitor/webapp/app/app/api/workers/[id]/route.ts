export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyToken } from '@/lib/auth'

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const { name, ipAddress, port } = await request.json()
    
    if (!name || !ipAddress || !port) {
      return NextResponse.json({ error: 'Name, IP address, and port are required' }, { status: 400 })
    }

    const updatedWorker = await prisma.worker.update({
      where: { id: params.id },
      data: {
        name: name.trim(),
        ipAddress: ipAddress.trim(),
        port: parseInt(port)
      }
    })

    return NextResponse.json(updatedWorker)
  } catch (error) {
    console.error('Update worker error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    await prisma.worker.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Worker deleted successfully' })
  } catch (error) {
    console.error('Delete worker error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}