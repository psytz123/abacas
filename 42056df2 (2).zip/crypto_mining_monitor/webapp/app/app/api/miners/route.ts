export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getUserFromToken } from '@/lib/auth';
import { VNishFirmwareClient } from '@/lib/vnish/firmware-client';

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('auth-token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const miners = await prisma.miner.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        status: true,
        hashRate: true,
        temperature: true,
        power: true,
        earnings: true,
        model: true,
        ipAddress: true,
        createdAt: true,
        updatedAt: true
      }
    });

    return NextResponse.json({ miners });

  } catch (error) {
    console.error('Miners fetch error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('auth-token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, ipAddress, model } = body;

    if (!name) {
      return NextResponse.json(
        { error: 'Miner name is required' },
        { status: 400 }
      );
    }

    // If IP address is provided, try to get miner details from VNish
    let minerData = {
      name,
      status: 'online',
      hashRate: 0,
      temperature: 0,
      power: 0,
      earnings: 0,
      model: model || 'Unknown',
      ipAddress,
      userId: user.id
    };

    if (ipAddress) {
      try {
        const vnishClient = new VNishFirmwareClient({
          apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
          apiKey: process.env.VNISH_API_KEY || '',
          timeout: 30000
        });

        const telemetry = await vnishClient.getTelemetry(ipAddress);
        
        if (telemetry) {
          minerData = {
            ...minerData,
            model: telemetry.model,
            hashRate: telemetry.hashrate.total,
            temperature: telemetry.temperature.avg_chip,
            power: telemetry.power.consumption,
            // Earnings would come from a different source in a real implementation
          };
        }
      } catch (error) {
        console.error(`Failed to get telemetry for miner at ${ipAddress}:`, error);
        // Continue with default values if telemetry fetch fails
      }
    }

    const miner = await prisma.miner.create({
      data: minerData
    });

    return NextResponse.json({ miner }, { status: 201 });

  } catch (error) {
    console.error('Miner creation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
