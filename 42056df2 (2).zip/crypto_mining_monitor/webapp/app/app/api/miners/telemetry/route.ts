import { NextRequest, NextResponse } from 'next/server';
import { VNishFirmwareClient } from '@/lib/vnish/firmware-client';
import { getUserFromToken } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    // Authenticate user
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    // Get query parameters
    const searchParams = request.nextUrl.searchParams;
    const minerIp = searchParams.get('miner_ip');
    const minerId = searchParams.get('miner_id');
    
    if (!minerIp && !minerId) {
      return NextResponse.json(
        { error: 'Missing miner_ip or miner_id query parameter' },
        { status: 400 }
      );
    }
    
    // Initialize VNish client
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    let ipAddress = minerIp;
    
    // If miner_id is provided but not miner_ip, look up the IP address
    if (!ipAddress && minerId) {
      const miner = await prisma.miner.findUnique({
        where: { 
          id: minerId,
          userId: user.id // Ensure the miner belongs to the user
        }
      });
      
      if (!miner) {
        return NextResponse.json(
          { error: 'Miner not found' },
          { status: 404 }
        );
      }
      
      if (!miner.ipAddress) {
        return NextResponse.json(
          { error: 'Miner has no IP address configured' },
          { status: 400 }
        );
      }
      
      ipAddress = miner.ipAddress;
    }
    
    // Get telemetry data
    const telemetry = await vnishClient.getTelemetry(ipAddress!);
    
    if (!telemetry) {
      return NextResponse.json(
        { error: `Failed to get telemetry data for miner ${ipAddress}` },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ telemetry });
  } catch (error) {
    console.error('Error getting telemetry:', error);
    
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Authenticate user
    const token = request.cookies.get('auth-token')?.value;
    
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    const user = await getUserFromToken(token);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    
    // Validate request body
    if (!body.miner_ip && !body.miner_id) {
      return NextResponse.json(
        { error: 'Missing miner_ip or miner_id in request body' },
        { status: 400 }
      );
    }
    
    // Initialize VNish client
    const vnishClient = new VNishFirmwareClient({
      apiEndpoint: process.env.VNISH_API_ENDPOINT || '',
      apiKey: process.env.VNISH_API_KEY || '',
      timeout: 30000
    });
    
    let ipAddress = body.miner_ip;
    
    // If miner_id is provided but not miner_ip, look up the IP address
    if (!ipAddress && body.miner_id) {
      const miner = await prisma.miner.findUnique({
        where: { 
          id: body.miner_id,
          userId: user.id // Ensure the miner belongs to the user
        }
      });
      
      if (!miner) {
        return NextResponse.json(
          { error: 'Miner not found' },
          { status: 404 }
        );
      }
      
      if (!miner.ipAddress) {
        return NextResponse.json(
          { error: 'Miner has no IP address configured' },
          { status: 400 }
        );
      }
      
      ipAddress = miner.ipAddress;
    }
    
    // Get telemetry data
    const telemetry = await vnishClient.getTelemetry(ipAddress!);
    
    if (!telemetry) {
      return NextResponse.json(
        { error: `Failed to get telemetry data for miner ${ipAddress}` },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ telemetry });
  } catch (error) {
    console.error('Error getting telemetry:', error);
    
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
