import { NextRequest, NextResponse } from 'next/server';
import VNishFirmwareClient, { 
  HashrateTuningRequest, 
  PowerOptimizationRequest, 
  OverclockingRequest 
} from '@/lib/vnish/firmware-client';

// Initialize the VNish firmware client
const vnishClient = new VNishFirmwareClient({
  apiEndpoint: process.env.VNISH_API_ENDPOINT || 'http://localhost:8000',
  apiKey: process.env.VNISH_API_KEY || '',
  timeout: 30000
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate request body
    if (!body.type) {
      return NextResponse.json(
        { error: 'Missing optimization type in request body' },
        { status: 400 }
      );
    }
    
    if (!body.miner_id) {
      return NextResponse.json(
        { error: 'Missing miner_id in request body' },
        { status: 400 }
      );
    }
    
    // Extract common parameters
    const { type, miner_id, miner_ip, dry_run = false } = body;
    
    let result;
    
    // Apply the appropriate optimization based on type
    switch (type) {
      case 'hashrate_tuning':
        if (typeof body.hashrate_percent !== 'number') {
          return NextResponse.json(
            { error: 'Missing or invalid hashrate_percent in request body' },
            { status: 400 }
          );
        }
        
        const hashrateTuningRequest: HashrateTuningRequest = {
          miner_id,
          miner_ip,
          hashrate_percent: body.hashrate_percent,
          dry_run
        };
        
        result = await vnishClient.applyHashrateTuning(hashrateTuningRequest);
        break;
        
      case 'power_optimization':
        if (typeof body.power_limit_factor !== 'number') {
          return NextResponse.json(
            { error: 'Missing or invalid power_limit_factor in request body' },
            { status: 400 }
          );
        }
        
        const powerOptimizationRequest: PowerOptimizationRequest = {
          miner_id,
          miner_ip,
          power_limit_factor: body.power_limit_factor,
          dry_run
        };
        
        result = await vnishClient.applyPowerOptimization(powerOptimizationRequest);
        break;
        
      case 'overclocking':
        if (
          typeof body.core_clock_offset !== 'number' ||
          typeof body.memory_clock_offset !== 'number' ||
          typeof body.power_limit_percent !== 'number' ||
          typeof body.core_voltage_offset !== 'number'
        ) {
          return NextResponse.json(
            { error: 'Missing or invalid overclocking parameters in request body' },
            { status: 400 }
          );
        }
        
        const overclockingRequest: OverclockingRequest = {
          miner_id,
          miner_ip,
          core_clock_offset: body.core_clock_offset,
          memory_clock_offset: body.memory_clock_offset,
          power_limit_percent: body.power_limit_percent,
          core_voltage_offset: body.core_voltage_offset,
          dry_run
        };
        
        result = await vnishClient.applyOverclocking(overclockingRequest);
        break;
        
      default:
        return NextResponse.json(
          { error: `Unsupported optimization type: ${type}` },
          { status: 400 }
        );
    }
    
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error applying optimization:', error);
    
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
