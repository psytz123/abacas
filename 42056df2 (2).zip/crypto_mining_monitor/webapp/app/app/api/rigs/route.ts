export const dynamic = "force-dynamic";

import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Simulate rigs data
    const rigs = [
      {
        id: '1',
        name: 'Antminer S19 Pro #001',
        status: 'active',
        hashrate: 110.5 + (Math.random() - 0.5) * 10,
        power: 3250 + Math.random() * 100,
        temperature: 68 + (Math.random() - 0.5) * 10,
        uptime: 99.8,
        efficiency: 29.4
      },
      {
        id: '2',
        name: 'Antminer S19 Pro #002',
        status: 'active',
        hashrate: 108.2 + (Math.random() - 0.5) * 10,
        power: 3280 + Math.random() * 100,
        temperature: 71 + (Math.random() - 0.5) * 10,
        uptime: 98.5,
        efficiency: 33.0
      },
      {
        id: '3',
        name: 'Whatsminer M30S #001',
        status: 'maintenance',
        hashrate: 0,
        power: 0,
        temperature: 25,
        uptime: 0,
        efficiency: 0
      },
      {
        id: '4',
        name: 'Antminer S19 Pro #003',
        status: 'active',
        hashrate: 112.8 + (Math.random() - 0.5) * 10,
        power: 3200 + Math.random() * 100,
        temperature: 65 + (Math.random() - 0.5) * 10,
        uptime: 99.9,
        efficiency: 28.4
      },
      {
        id: '5',
        name: 'Whatsminer M30S #002',
        status: 'active',
        hashrate: 86.5 + (Math.random() - 0.5) * 10,
        power: 3400 + Math.random() * 100,
        temperature: 73 + (Math.random() - 0.5) * 10,
        uptime: 97.2,
        efficiency: 39.3
      }
    ]

    return NextResponse.json(rigs)
  } catch (error) {
    console.error('Error fetching rigs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch rigs' },
      { status: 500 }
    )
  }
}