'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import { Globe, Plus, Users, Zap, DollarSign } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function PoolsPage() {
  const [pools, setPools] = useState<any[]>([])

  useEffect(() => {
    // Generate sample pools data
    const samplePools = [
      {
        id: '1',
        name: 'Antpool',
        url: 'stratum+tcp://stratum-btc.antpool.com',
        port: 3333,
        fee: 2.5,
        workers: 12,
        hashrate: 450.2,
        status: 'connected'
      },
      {
        id: '2',
        name: 'F2Pool',
        url: 'stratum+tcp://btc.f2pool.com',
        port: 3333,
        fee: 2.0,
        workers: 8,
        hashrate: 320.8,
        status: 'connected'
      },
      {
        id: '3',
        name: 'Poolin',
        url: 'stratum+tcp://btc-us.ss.poolin.me',
        port: 443,
        fee: 2.5,
        workers: 4,
        hashrate: 180.5,
        status: 'disconnected'
      }
    ]

    setPools(samplePools)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
      case 'disconnected':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center justify-between mb-8"
            >
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                  <Globe className="h-8 w-8 mr-3 text-blue-600" />
                  Mining Pools
                </h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Manage your mining pool connections and monitor performance
                </p>
              </div>
              <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Pool
              </Button>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {pools.map((pool, index) => (
                <motion.div
                  key={pool.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      {pool.name}
                    </h3>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(pool.status)}`}>
                      {pool.status}
                    </span>
                  </div>

                  <div className="space-y-3">
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <strong>URL:</strong> {pool.url}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <strong>Port:</strong> {pool.port}
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-blue-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {pool.workers}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Workers
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-green-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {pool.fee}%
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Fee
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 col-span-2">
                        <Zap className="h-4 w-4 text-yellow-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {pool.hashrate} TH/s
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            Pool Hashrate
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2 mt-6">
                    <Button variant="outline" size="sm" className="flex-1">
                      Configure
                    </Button>
                    <Button 
                      variant={pool.status === 'connected' ? 'destructive' : 'default'} 
                      size="sm" 
                      className="flex-1"
                    >
                      {pool.status === 'connected' ? 'Disconnect' : 'Connect'}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}