'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import AlertsPanel from '@/components/alerts-panel'
import { AlertTriangle, Settings } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function AlertsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center justify-between mb-8"
            >
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                  <AlertTriangle className="h-8 w-8 mr-3 text-red-600" />
                  Alerts & Notifications
                </h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Monitor system alerts and configure notification settings
                </p>
              </div>
              <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
                <Settings className="h-4 w-4 mr-2" />
                Alert Settings
              </Button>
            </motion.div>

            <div className="max-w-4xl">
              <AlertsPanel />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}