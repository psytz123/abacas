'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import RigsList from '@/components/rigs-list'
import FiltersPanel from '@/components/filters-panel'
import { Cpu, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function RigsPage() {
  const [filters, setFilters] = useState({
    timeRange: '24h',
    rigStatus: 'all',
    minHashrate: 0,
    maxHashrate: 1000,
    minTemperature: 0,
    maxTemperature: 100
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center justify-between mb-8"
            >
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                  <Cpu className="h-8 w-8 mr-3 text-blue-600" />
                  Mining Rigs
                </h1>
                <p className="text-gray-600 dark:text-gray-400">
                  Manage and monitor your cryptocurrency mining hardware
                </p>
              </div>
              <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
                <Plus className="h-4 w-4 mr-2" />
                Add New Rig
              </Button>
            </motion.div>

            <FiltersPanel filters={filters} onFiltersChange={setFilters} />
            <RigsList filters={filters} />
          </div>
        </main>
      </div>
    </div>
  )
}