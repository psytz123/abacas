'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import { Wallet, Bitcoin, DollarSign, TrendingUp, Copy, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function WalletPage() {
  const [walletData, setWalletData] = useState({
    btcBalance: 0,
    usdValue: 0,
    totalMined: 0,
    pendingPayouts: 0,
    address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
  })

  const [animatedValues, setAnimatedValues] = useState({
    btcBalance: 0,
    usdValue: 0,
    totalMined: 0,
    pendingPayouts: 0
  })

  useEffect(() => {
    // Simulate fetching wallet data
    const newData = {
      btcBalance: 2.45678901,
      usdValue: 105420.75,
      totalMined: 15.23456789,
      pendingPayouts: 0.12345678,
      address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
    }
    setWalletData(newData)
  }, [])

  useEffect(() => {
    // Animate numbers
    const duration = 2000
    const steps = 60
    const stepDuration = duration / steps

    Object.keys(walletData).forEach((key) => {
      if (typeof walletData[key as keyof typeof walletData] === 'number') {
        const start = animatedValues[key as keyof typeof animatedValues] || 0
        const end = walletData[key as keyof typeof walletData] as number
        const increment = (end - start) / steps

        let currentStep = 0
        const timer = setInterval(() => {
          currentStep++
          setAnimatedValues(prev => ({
            ...prev,
            [key]: start + (increment * currentStep)
          }))

          if (currentStep >= steps) {
            clearInterval(timer)
            setAnimatedValues(prev => ({
              ...prev,
              [key]: end
            }))
          }
        }, stepDuration)
      }
    })
  }, [walletData])

  const copyAddress = () => {
    navigator.clipboard.writeText(walletData.address)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                <Wallet className="h-8 w-8 mr-3 text-orange-600" />
                Wallet Overview
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Monitor your cryptocurrency earnings and wallet balance
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-lg bg-gradient-to-r from-orange-500 to-orange-600">
                    <Bitcoin className="h-6 w-6 text-white" />
                  </div>
                  <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                  BTC Balance
                </h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {animatedValues.btcBalance.toFixed(8)} BTC
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-lg bg-gradient-to-r from-green-500 to-green-600">
                    <DollarSign className="h-6 w-6 text-white" />
                  </div>
                  <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                  USD Value
                </h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  ${animatedValues.usdValue.toFixed(2)}
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-lg bg-gradient-to-r from-blue-500 to-blue-600">
                    <Bitcoin className="h-6 w-6 text-white" />
                  </div>
                  <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                  Total Mined
                </h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {animatedValues.totalMined.toFixed(8)} BTC
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 rounded-lg bg-gradient-to-r from-purple-500 to-purple-600">
                    <Wallet className="h-6 w-6 text-white" />
                  </div>
                  <TrendingUp className="h-5 w-5 text-yellow-500" />
                </div>
                <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                  Pending Payouts
                </h3>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {animatedValues.pendingPayouts.toFixed(8)} BTC
                </p>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
            >
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Wallet Address
              </h3>
              <div className="flex items-center space-x-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex-1 font-mono text-sm text-gray-900 dark:text-white break-all">
                  {walletData.address}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={copyAddress}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  )
}