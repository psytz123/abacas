'use client';

import { motion } from 'framer-motion';
import { UnifiedRecommendationsPanel } from '@/components/unified-recommendations-panel';

export default function RecommendationsPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-2">ML Recommendations</h1>
        <p className="text-muted-foreground mb-6">
          View and manage machine learning recommendations to optimize your mining operations
        </p>
      </motion.div>

      <UnifiedRecommendationsPanel />
    </div>
  );
}