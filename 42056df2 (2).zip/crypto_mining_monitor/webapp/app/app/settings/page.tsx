'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import { Settings, Bell, Shield, Monitor, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: false,
      sms: false,
      temperatureAlerts: true,
      hashrateAlerts: true,
      offlineAlerts: true
    },
    monitoring: {
      refreshInterval: 30,
      dataRetention: 90,
      autoRestart: true,
      powerSaving: false
    },
    security: {
      twoFactor: false,
      apiAccess: true,
      remoteAccess: false
    }
  })

  const updateSetting = (category: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [key]: value
      }
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                <Settings className="h-8 w-8 mr-3 text-gray-600" />
                Settings
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Configure your mining monitoring preferences and system settings
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Notifications Settings */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <Bell className="h-6 w-6 text-blue-600" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Notifications
                  </h3>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <Switch
                      id="email-notifications"
                      checked={settings.notifications.email}
                      onCheckedChange={(checked) => updateSetting('notifications', 'email', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="push-notifications">Push Notifications</Label>
                    <Switch
                      id="push-notifications"
                      checked={settings.notifications.push}
                      onCheckedChange={(checked) => updateSetting('notifications', 'push', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="temperature-alerts">Temperature Alerts</Label>
                    <Switch
                      id="temperature-alerts"
                      checked={settings.notifications.temperatureAlerts}
                      onCheckedChange={(checked) => updateSetting('notifications', 'temperatureAlerts', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="hashrate-alerts">Hashrate Alerts</Label>
                    <Switch
                      id="hashrate-alerts"
                      checked={settings.notifications.hashrateAlerts}
                      onCheckedChange={(checked) => updateSetting('notifications', 'hashrateAlerts', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="offline-alerts">Offline Alerts</Label>
                    <Switch
                      id="offline-alerts"
                      checked={settings.notifications.offlineAlerts}
                      onCheckedChange={(checked) => updateSetting('notifications', 'offlineAlerts', checked)}
                    />
                  </div>
                </div>
              </motion.div>

              {/* Monitoring Settings */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <Monitor className="h-6 w-6 text-green-600" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Monitoring
                  </h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="refresh-interval">Refresh Interval (seconds)</Label>
                    <Input
                      id="refresh-interval"
                      type="number"
                      value={settings.monitoring.refreshInterval}
                      onChange={(e) => updateSetting('monitoring', 'refreshInterval', parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="data-retention">Data Retention (days)</Label>
                    <Input
                      id="data-retention"
                      type="number"
                      value={settings.monitoring.dataRetention}
                      onChange={(e) => updateSetting('monitoring', 'dataRetention', parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-restart">Auto Restart Failed Rigs</Label>
                    <Switch
                      id="auto-restart"
                      checked={settings.monitoring.autoRestart}
                      onCheckedChange={(checked) => updateSetting('monitoring', 'autoRestart', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="power-saving">Power Saving Mode</Label>
                    <Switch
                      id="power-saving"
                      checked={settings.monitoring.powerSaving}
                      onCheckedChange={(checked) => updateSetting('monitoring', 'powerSaving', checked)}
                    />
                  </div>
                </div>
              </motion.div>

              {/* Security Settings */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <Shield className="h-6 w-6 text-red-600" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Security
                  </h3>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="two-factor">Two-Factor Authentication</Label>
                    <Switch
                      id="two-factor"
                      checked={settings.security.twoFactor}
                      onCheckedChange={(checked) => updateSetting('security', 'twoFactor', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="api-access">API Access</Label>
                    <Switch
                      id="api-access"
                      checked={settings.security.apiAccess}
                      onCheckedChange={(checked) => updateSetting('security', 'apiAccess', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="remote-access">Remote Access</Label>
                    <Switch
                      id="remote-access"
                      checked={settings.security.remoteAccess}
                      onCheckedChange={(checked) => updateSetting('security', 'remoteAccess', checked)}
                    />
                  </div>
                </div>
              </motion.div>

              {/* System Information */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <Zap className="h-6 w-6 text-yellow-600" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    System Information
                  </h3>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Version:</span>
                    <span className="text-gray-900 dark:text-white">v2.1.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Uptime:</span>
                    <span className="text-gray-900 dark:text-white">15 days, 8 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Last Update:</span>
                    <span className="text-gray-900 dark:text-white">2024-01-15</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Database Size:</span>
                    <span className="text-gray-900 dark:text-white">2.4 GB</span>
                  </div>
                </div>

                <div className="mt-6 space-y-2">
                  <Button variant="outline" className="w-full">
                    Export Data
                  </Button>
                  <Button variant="outline" className="w-full">
                    Check for Updates
                  </Button>
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex justify-end space-x-4"
            >
              <Button variant="outline">
                Reset to Defaults
              </Button>
              <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
                Save Settings
              </Button>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  )
}