'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import MiningCharts from '@/components/mining-charts'
import StatsCards from '@/components/stats-cards'
import FiltersPanel from '@/components/filters-panel'
import { Activity } from 'lucide-react'

export default function PerformancePage() {
  const [filters, setFilters] = useState({
    timeRange: '24h',
    rigStatus: 'all',
    minHashrate: 0,
    maxHashrate: 1000,
    minTemperature: 0,
    maxTemperature: 100
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                <Activity className="h-8 w-8 mr-3 text-green-600" />
                Performance Analytics
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Detailed performance metrics and analytics for your mining operations
              </p>
            </motion.div>

            <FiltersPanel filters={filters} onFiltersChange={setFilters} />
            <StatsCards filters={filters} />
            <MiningCharts filters={filters} />
          </div>
        </main>
      </div>
    </div>
  )
}