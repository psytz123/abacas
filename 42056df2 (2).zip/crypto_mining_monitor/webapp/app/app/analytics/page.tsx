'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import MiningCharts from '@/components/mining-charts'
import { BarChart3 } from 'lucide-react'

export default function AnalyticsPage() {
  const [filters, setFilters] = useState({
    timeRange: '24h',
    rigStatus: 'all',
    minHashrate: 0,
    maxHashrate: 1000,
    minTemperature: 0,
    maxTemperature: 100
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
                <BarChart3 className="h-8 w-8 mr-3 text-purple-600" />
                Advanced Analytics
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Deep dive into your mining data with advanced analytics and insights
              </p>
            </motion.div>

            <MiningCharts filters={filters} />
          </div>
        </main>
      </div>
    </div>
  )
}