'use client'

import { motion } from 'framer-motion';
import RecommendationHistory from '@/components/recommendations/recommendation-history';

export default function HistoryPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">History</h1>
          <p className="text-white/70">
            View your complete recommendation and optimization history
          </p>
        </motion.div>

        {/* Recommendation History Component */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <RecommendationHistory />
        </motion.div>
      </div>
    </div>
  );
}