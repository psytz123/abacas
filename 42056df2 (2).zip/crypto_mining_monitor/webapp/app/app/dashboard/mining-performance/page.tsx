'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  TrendingUp, 
  Zap, 
  Thermometer, 
  DollarSign,
  Activity,
  BarChart3,
  PieChart,
  Calendar
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  miningData, 
  profitabilityComparison,
  type MiningData,
  type ProfitabilityData
} from "@/lib/mock-data"
import { formatCurrency } from "@/lib/utils"

export default function MiningPerformance() {
  const [timeRange, setTimeRange] = useState('24h')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 1000)
    return () => clearTimeout(timer)
  }, [])

  // Calculate total earnings in USD
  const totalEarnings = miningData.reduce((sum, data) => sum + data.earnings, 0)
  const avgHashRate = miningData.reduce((sum, data) => sum + data.hashRate, 0) / miningData.length
  const avgPower = miningData.reduce((sum, data) => sum + data.power, 0) / miningData.length
  const avgTemperature = miningData.reduce((sum, data) => sum + data.temperature, 0) / miningData.length

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading performance data...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Mining Performance</h1>
          <p className="text-white/70">
            Analyze your mining operations with detailed performance metrics and profitability insights
          </p>
        </motion.div>

        {/* Time Range Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex space-x-2">
            {['1h', '24h', '7d', '30d'].map((range) => (
              <Button
                key={range}
                variant={timeRange === range ? "default" : "outline"}
                onClick={() => setTimeRange(range)}
                className={timeRange === range ? "bg-blue-600 hover:bg-blue-700" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}
              >
                {range}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Performance Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Total Earnings</p>
                  <p className="text-2xl font-bold text-white">{formatCurrency(totalEarnings)}</p>
                  <p className="text-green-400 text-sm">+12.5% from yesterday</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Avg Hash Rate</p>
                  <p className="text-2xl font-bold text-white">{avgHashRate.toFixed(1)} TH/s</p>
                  <p className="text-blue-400 text-sm">+3.2% efficiency</p>
                </div>
                <Activity className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Avg Power</p>
                  <p className="text-2xl font-bold text-white">{avgPower.toFixed(0)} W</p>
                  <p className="text-yellow-400 text-sm">Optimal range</p>
                </div>
                <Zap className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Avg Temperature</p>
                  <p className="text-2xl font-bold text-white">{avgTemperature.toFixed(1)}°C</p>
                  <p className="text-green-400 text-sm">Within safe limits</p>
                </div>
                <Thermometer className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Mining Data Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Performance Trends
                </CardTitle>
                <CardDescription className="text-white/70">
                  Hash rate and earnings over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {miningData.map((data, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                      className="p-4 bg-white/5 rounded-lg border border-white/10"
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-white/70 text-sm">
                          {new Date(data.timestamp).toLocaleTimeString()}
                        </span>
                        <Badge variant="success">{formatCurrency(data.earnings)}</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-white/60">Hash Rate:</span>
                          <span className="text-white ml-2">{data.hashRate} TH/s</span>
                        </div>
                        <div>
                          <span className="text-white/60">Power:</span>
                          <span className="text-white ml-2">{data.power} W</span>
                        </div>
                        <div>
                          <span className="text-white/60">Temp:</span>
                          <span className="text-white ml-2">{data.temperature}°C</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Profitability Comparison */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <PieChart className="h-5 w-5 mr-2" />
                  Profitability Comparison
                </CardTitle>
                <CardDescription className="text-white/70">
                  Compare different cryptocurrencies
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {profitabilityComparison.map((coin, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                      className="p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-200"
                    >
                      <div className="flex justify-between items-center mb-3">
                        <div>
                          <h3 className="font-semibold text-white">{coin.coin}</h3>
                          <p className="text-white/60 text-sm">{coin.algorithm}</p>
                        </div>
                        <Badge 
                          variant={coin.profitability > 80 ? "success" : coin.profitability > 60 ? "warning" : "destructive"}
                        >
                          {coin.profitability.toFixed(1)}%
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-white/60">Daily Earnings:</span>
                          <span className="text-white ml-2">{formatCurrency(coin.dailyEarnings)}</span>
                        </div>
                        <div>
                          <span className="text-white/60">Power:</span>
                          <span className="text-white ml-2">{coin.power} W</span>
                        </div>
                      </div>
                      <div className="mt-2">
                        <div className="w-full bg-white/10 rounded-full h-2">
                          <div 
                            className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${coin.profitability}%` }}
                          />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Additional Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Performance Insights
              </CardTitle>
              <CardDescription className="text-white/70">
                Key metrics and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <h3 className="font-semibold text-white mb-2">Efficiency Score</h3>
                  <div className="flex items-center space-x-2">
                    <div className="text-2xl font-bold text-green-400">92%</div>
                    <Badge variant="success">Excellent</Badge>
                  </div>
                  <p className="text-white/60 text-sm mt-2">
                    Your mining operation is performing above average
                  </p>
                </div>

                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <h3 className="font-semibold text-white mb-2">Cost Efficiency</h3>
                  <div className="flex items-center space-x-2">
                    <div className="text-2xl font-bold text-blue-400">{formatCurrency(0.08)}/kWh</div>
                    <Badge variant="info">Good</Badge>
                  </div>
                  <p className="text-white/60 text-sm mt-2">
                    Energy costs are within optimal range
                  </p>
                </div>

                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <h3 className="font-semibold text-white mb-2">Uptime</h3>
                  <div className="flex items-center space-x-2">
                    <div className="text-2xl font-bold text-purple-400">99.2%</div>
                    <Badge variant="success">Stable</Badge>
                  </div>
                  <p className="text-white/60 text-sm mt-2">
                    Minimal downtime detected
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}