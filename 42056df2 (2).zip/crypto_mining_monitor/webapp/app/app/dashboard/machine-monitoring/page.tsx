'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Monitor, 
  Cpu, 
  Thermometer, 
  Zap, 
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface Machine {
  id: string
  name: string
  status: 'online' | 'offline' | 'warning'
  hashRate: number
  temperature: number
  power: number
  uptime: number
  lastSeen: string
}

export default function MachineMonitoring() {
  const [loading, setLoading] = useState(true)
  const [machines, setMachines] = useState<Machine[]>([])

  useEffect(() => {
    // Simulate loading machine data
    const timer = setTimeout(() => {
      setMachines([
        {
          id: '1',
          name: 'Mining Rig 01',
          status: 'online',
          hashRate: 125.5,
          temperature: 65,
          power: 1500,
          uptime: 86400,
          lastSeen: new Date().toISOString()
        },
        {
          id: '2',
          name: 'Mining Rig 02',
          status: 'warning',
          hashRate: 98.2,
          temperature: 78,
          power: 1450,
          uptime: 72000,
          lastSeen: new Date().toISOString()
        },
        {
          id: '3',
          name: 'Mining Rig 03',
          status: 'offline',
          hashRate: 0,
          temperature: 45,
          power: 0,
          uptime: 0,
          lastSeen: new Date(Date.now() - 3600000).toISOString()
        }
      ])
      setLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "online":
        return <Badge variant="secondary">Online</Badge>;
      case "offline":
        return <Badge variant="destructive">Offline</Badge>;
      case "warning":
        return <Badge variant="secondary">Warning</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "online":
        return <CheckCircle className="h-5 w-5 text-green-400" />
      case "offline":
        return <AlertTriangle className="h-5 w-5 text-red-400" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-400" />
      default:
        return <Monitor className="h-5 w-5 text-gray-400" />
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading machine data...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Machine Monitoring</h1>
          <p className="text-white/70">
            Monitor the health and performance of your mining machines in real-time
          </p>
        </motion.div>

        {/* Overview Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Total Machines</p>
                  <p className="text-2xl font-bold text-white">{machines.length}</p>
                </div>
                <Monitor className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Online</p>
                  <p className="text-2xl font-bold text-white">
                    {machines.filter(m => m.status === 'online').length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Warnings</p>
                  <p className="text-2xl font-bold text-white">
                    {machines.filter(m => m.status === 'warning').length}
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Offline</p>
                  <p className="text-2xl font-bold text-white">
                    {machines.filter(m => m.status === 'offline').length}
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Machine List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Monitor className="h-5 w-5 mr-2" />
                Mining Machines
              </CardTitle>
              <CardDescription className="text-white/70">
                Real-time status and performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {machines.map((machine, index) => (
                  <motion.div
                    key={machine.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * index }}
                    whileHover={{ scale: 1.01 }}
                    className="p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(machine.status)}
                        <div>
                          <h3 className="font-semibold text-white">{machine.name}</h3>
                          <p className="text-white/60 text-sm">
                            Last seen: {new Date(machine.lastSeen).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      {getStatusBadge(machine.status)}
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="flex items-center space-x-2">
                        <Activity className="h-4 w-4 text-blue-400" />
                        <div>
                          <p className="text-white/70 text-sm">Hash Rate</p>
                          <p className="text-white font-medium">{machine.hashRate} TH/s</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Thermometer className="h-4 w-4 text-red-400" />
                        <div>
                          <p className="text-white/70 text-sm">Temperature</p>
                          <p className="text-white font-medium">{machine.temperature}°C</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Zap className="h-4 w-4 text-yellow-400" />
                        <div>
                          <p className="text-white/70 text-sm">Power</p>
                          <p className="text-white font-medium">{machine.power} W</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-green-400" />
                        <div>
                          <p className="text-white/70 text-sm">Uptime</p>
                          <p className="text-white font-medium">
                            {Math.floor(machine.uptime / 3600)}h {Math.floor((machine.uptime % 3600) / 60)}m
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end mt-4 space-x-2">
                      <Button size="sm" variant="outline" className="text-white border-white/20 hover:bg-white/10">
                        View Details
                      </Button>
                      {machine.status === 'offline' && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          Restart
                        </Button>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}