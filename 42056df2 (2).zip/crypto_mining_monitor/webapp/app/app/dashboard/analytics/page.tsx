"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import { 
  Calendar, 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Download,
  ChevronDown,
  Zap,
  Clock,
  Cpu
} from "lucide-react";

// Dynamically import chart components with SSR disabled
const LineChart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Line),
  { ssr: false, loading: () => <div className="h-64 w-full bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">Loading chart...</div> }
);

const BarChart = dynamic(
  () => import("react-chartjs-2").then((mod) => mod.Bar),
  { ssr: false, loading: () => <div className="h-64 w-full bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">Loading chart...</div> }
);

// Import Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("7d");
  
  // Mock data for charts
  const labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  
  // Hashrate data
  const hashrateData = {
    labels,
    datasets: [
      {
        label: "Hashrate (TH/s)",
        data: [420, 435, 450, 445, 460, 475, 452],
        borderColor: "rgb(59, 130, 246)",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        tension: 0.3,
        fill: true,
      },
    ],
  };
  
  // Revenue data
  const revenueData = {
    labels,
    datasets: [
      {
        label: "Revenue (USD)",
        data: [1250, 1180, 1320, 1290, 1350, 1400, 1245],
        borderColor: "rgb(16, 185, 129)",
        backgroundColor: "rgba(16, 185, 129, 0.1)",
        tension: 0.3,
        fill: true,
      },
    ],
  };
  
  // Worker status data
  const workerStatusData = {
    labels,
    datasets: [
      {
        label: "Online Workers",
        data: [28, 27, 29, 28, 26, 25, 24],
        backgroundColor: "rgb(16, 185, 129)",
      },
      {
        label: "Warning Workers",
        data: [1, 2, 0, 1, 3, 3, 4],
        backgroundColor: "rgb(245, 158, 11)",
      },
      {
        label: "Offline Workers",
        data: [1, 1, 1, 1, 1, 2, 2],
        backgroundColor: "rgb(239, 68, 68)",
      },
    ],
  };

  // Chart options
  const lineChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
      },
    },
    interaction: {
      mode: "nearest" as const,
      axis: "x" as const,
      intersect: false,
    },
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
        beginAtZero: true,
      },
    },
  };

  // Summary stats
  const summaryStats = [
    {
      title: "Average Hashrate",
      value: "448.1 TH/s",
      change: "+3.2%",
      isPositive: true,
      icon: <Zap className="h-5 w-5 text-blue-500" />,
      color: "bg-blue-50 dark:bg-blue-900"
    },
    {
      title: "Total Revenue",
      value: "$9,035.00",
      change: "+5.8%",
      isPositive: true,
      icon: <DollarSign className="h-5 w-5 text-green-500" />,
      color: "bg-green-50 dark:bg-green-900"
    },
    {
      title: "Average Uptime",
      value: "98.2%",
      change: "-0.3%",
      isPositive: false,
      icon: <Clock className="h-5 w-5 text-purple-500" />,
      color: "bg-purple-50 dark:bg-purple-900"
    },
    {
      title: "Worker Efficiency",
      value: "92.5%",
      change: "+1.5%",
      isPositive: true,
      icon: <Cpu className="h-5 w-5 text-orange-500" />,
      color: "bg-orange-50 dark:bg-orange-900"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Analytics</h1>
            <p className="mt-1 text-gray-500 dark:text-gray-400">Monitor your mining performance and revenue</p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-3">
            <div className="inline-flex shadow-sm rounded-md">
              <button
                onClick={() => setTimeRange("24h")}
                className={`px-4 py-2 text-sm font-medium rounded-l-md ${
                  timeRange === "24h"
                    ? "bg-blue-600 text-white"
                    : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600"
                }`}
              >
                24h
              </button>
              <button
                onClick={() => setTimeRange("7d")}
                className={`px-4 py-2 text-sm font-medium ${
                  timeRange === "7d"
                    ? "bg-blue-600 text-white"
                    : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-t border-b border-gray-300 dark:border-gray-600"
                }`}
              >
                7d
              </button>
              <button
                onClick={() => setTimeRange("30d")}
                className={`px-4 py-2 text-sm font-medium ${
                  timeRange === "30d"
                    ? "bg-blue-600 text-white"
                    : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border-t border-b border-gray-300 dark:border-gray-600"
                }`}
              >
                30d
              </button>
              <button
                onClick={() => setTimeRange("all")}
                className={`px-4 py-2 text-sm font-medium rounded-r-md ${
                  timeRange === "all"
                    ? "bg-blue-600 text-white"
                    : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600"
                }`}
              >
                All
              </button>
            </div>
            <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </motion.div>

        {/* Summary stats */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8"
        >
          {summaryStats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 * index }}
              className={`${stat.color} overflow-hidden rounded-lg shadow-lg`}
            >
              <div className="px-4 py-5 sm:p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-white p-3 shadow-sm dark:bg-gray-800">
                    {stat.icon}
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate dark:text-gray-400">{stat.title}</dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900 dark:text-white">{stat.value}</div>
                      </dd>
                    </dl>
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className={stat.isPositive ? "text-green-500" : "text-red-500"}>
                    {stat.change}
                  </span>
                  <span className="ml-2 text-gray-500 dark:text-gray-400">from previous period</span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-8">
          {/* Hashrate chart */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <TrendingUp className="h-5 w-5 text-blue-500 mr-2" />
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">Hashrate Performance</h2>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <Calendar className="h-4 w-4 mr-1" />
                    Custom Range
                    <ChevronDown className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
              <div className="h-80">
                <LineChart data={hashrateData} options={lineChartOptions} />
              </div>
            </div>
          </motion.div>

          {/* Revenue chart */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-green-500 mr-2" />
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">Revenue Analysis</h2>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <Calendar className="h-4 w-4 mr-1" />
                    Custom Range
                    <ChevronDown className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
              <div className="h-80">
                <LineChart data={revenueData} options={lineChartOptions} />
              </div>
            </div>
          </motion.div>

          {/* Worker status chart */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <BarChart3 className="h-5 w-5 text-purple-500 mr-2" />
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">Worker Status Distribution</h2>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <Calendar className="h-4 w-4 mr-1" />
                    Custom Range
                    <ChevronDown className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
              <div className="h-80">
                <BarChart data={workerStatusData} options={barChartOptions} />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}