'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Lightbulb, 
  TrendingUp, 
  Filter,
  CheckCircle,
  X,
  Clock
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface Recommendation {
  id: string
  title: string
  description: string
  category: string
  urgency: 'low' | 'medium' | 'high'
  impact: string
  status: 'pending' | 'implemented' | 'rejected'
  createdAt: string
}

export default function RecommendationsPage() {
  const [loading, setLoading] = useState(true)
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    // Simulate loading recommendations
    const timer = setTimeout(() => {
      setRecommendations([
        {
          id: '1',
          title: 'Optimize GPU Memory Clock',
          description: 'Increase memory clock speed by 200MHz to improve hash rate by approximately 5-8%',
          category: 'Performance',
          urgency: 'medium',
          impact: '+7% hash rate',
          status: 'pending',
          createdAt: '2024-01-15T10:30:00Z'
        },
        {
          id: '2',
          title: 'Reduce Power Limit',
          description: 'Lower power limit to 80% to improve efficiency without significant performance loss',
          category: 'Efficiency',
          urgency: 'low',
          impact: '+12% efficiency',
          status: 'pending',
          createdAt: '2024-01-14T14:20:00Z'
        },
        {
          id: '3',
          title: 'Update Mining Software',
          description: 'New version available with 3% performance improvement and bug fixes',
          category: 'Software',
          urgency: 'high',
          impact: '+3% performance',
          status: 'implemented',
          createdAt: '2024-01-13T09:15:00Z'
        }
      ])
      setLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="default">Pending</Badge>;
      case 'implemented':
        return <Badge variant="secondary">Implemented</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  }

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge variant="secondary">Medium</Badge>;
      case 'low':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge>{urgency}</Badge>;
    }
  }

  const getImpactBadge = (impact: string) => {
    if (impact === 'Preventive') {
      return <Badge variant="secondary">Preventive</Badge>;
    }
    
    const numericImpact = parseFloat(impact.replace('%', '').replace('+', ''));
    
    if (numericImpact > 10) {
      return <Badge variant="secondary">{impact}</Badge>;
    } else if (numericImpact > 5) {
      return <Badge variant="secondary">{impact}</Badge>;
    } else {
      return <Badge>{impact}</Badge>;
    }
  }

  const filteredRecommendations = recommendations.filter(rec => 
    filter === 'all' || rec.status === filter
  )

  const handleAccept = (id: string) => {
    setRecommendations(prev => 
      prev.map(rec => 
        rec.id === id ? { ...rec, status: 'implemented' as const } : rec
      )
    )
  }

  const handleReject = (id: string) => {
    setRecommendations(prev => 
      prev.map(rec => 
        rec.id === id ? { ...rec, status: 'rejected' as const } : rec
      )
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading recommendations...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Recommendations</h1>
          <p className="text-white/70">
            AI-powered suggestions to optimize your mining operations
          </p>
        </motion.div>

        {/* Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-white/60" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
            >
              <option value="all">All Recommendations</option>
              <option value="pending">Pending</option>
              <option value="implemented">Implemented</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </motion.div>

        {/* Recommendations List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          {filteredRecommendations.map((recommendation, index) => (
            <motion.div
              key={recommendation.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
              whileHover={{ scale: 1.01 }}
            >
              <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <Lightbulb className="h-5 w-5 text-yellow-400 mt-1" />
                      <div>
                        <CardTitle className="text-white text-lg">{recommendation.title}</CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline">{recommendation.category}</Badge>
                          {getStatusBadge(recommendation.status)}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-white/70 mb-4">
                    {recommendation.description}
                  </CardDescription>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-white/60 text-sm">Urgency:</span>
                      {getUrgencyBadge(recommendation.urgency)}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/60 text-sm">Impact:</span>
                      {getImpactBadge(recommendation.impact)}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/60 text-sm">Created:</span>
                      <span className="text-white text-sm">
                        {new Date(recommendation.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {recommendation.status === 'pending' && (
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => handleAccept(recommendation.id)}
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Accept
                      </Button>
                      <Button
                        onClick={() => handleReject(recommendation.id)}
                        variant="destructive"
                        size="sm"
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  )}

                  {recommendation.status === 'implemented' && (
                    <div className="flex items-center space-x-2 text-green-400">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm">Implemented successfully</span>
                    </div>
                  )}

                  {recommendation.status === 'rejected' && (
                    <div className="flex items-center space-x-2 text-red-400">
                      <X className="h-4 w-4" />
                      <span className="text-sm">Rejected</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {filteredRecommendations.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Lightbulb className="h-16 w-16 text-white/30 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No recommendations found</h3>
            <p className="text-white/60">
              {filter === 'all' 
                ? 'Check back later for AI-powered optimization suggestions'
                : `No ${filter} recommendations at the moment`
              }
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}