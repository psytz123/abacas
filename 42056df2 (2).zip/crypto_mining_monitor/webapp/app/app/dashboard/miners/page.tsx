'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Cpu, 
  Plus, 
  Settings, 
  Activity,
  Zap,
  Thermometer,
  Clock,
  Search,
  Filter
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { formatHashRate, formatPower, formatUptime } from '@/lib/utils'

interface Miner {
  id: string
  name: string
  status: 'online' | 'offline' | 'warning'
  hashRate: number
  temperature: number
  power: number
  uptime: number
  model: string
  location: string
}

export default function MinersPage() {
  const [loading, setLoading] = useState(true)
  const [miners, setMiners] = useState<Miner[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [newMinerName, setNewMinerName] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  useEffect(() => {
    // Simulate loading miner data
    const timer = setTimeout(() => {
      setMiners([
        {
          id: '1',
          name: 'Antminer S19 Pro #1',
          status: 'online',
          hashRate: 110.5,
          temperature: 65,
          power: 3250,
          uptime: 86400,
          model: 'Antminer S19 Pro',
          location: 'Rack A1'
        },
        {
          id: '2',
          name: 'Antminer S19 Pro #2',
          status: 'online',
          hashRate: 108.2,
          temperature: 67,
          power: 3200,
          uptime: 72000,
          model: 'Antminer S19 Pro',
          location: 'Rack A2'
        },
        {
          id: '3',
          name: 'Antminer S19 Pro #3',
          status: 'warning',
          hashRate: 95.1,
          temperature: 78,
          power: 3100,
          uptime: 45000,
          model: 'Antminer S19 Pro',
          location: 'Rack A3'
        },
        {
          id: '4',
          name: 'Antminer S19 Pro #4',
          status: 'offline',
          hashRate: 0,
          temperature: 45,
          power: 0,
          uptime: 0,
          model: 'Antminer S19 Pro',
          location: 'Rack B1'
        },
        {
          id: '5',
          name: 'WhatsMiner M30S #1',
          status: 'online',
          hashRate: 88.5,
          temperature: 62,
          power: 3344,
          uptime: 120000,
          model: 'WhatsMiner M30S',
          location: 'Rack B2'
        },
        {
          id: '6',
          name: 'WhatsMiner M30S #2',
          status: 'online',
          hashRate: 90.2,
          temperature: 64,
          power: 3380,
          uptime: 98000,
          model: 'WhatsMiner M30S',
          location: 'Rack B3'
        }
      ])
      setLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const addMiner = () => {
    if (!newMinerName.trim()) return

    const newMiner: Miner = {
      id: Date.now().toString(),
      name: newMinerName,
      status: 'online',
      hashRate: Math.random() * 50 + 80,
      temperature: Math.random() * 20 + 60,
      power: Math.random() * 500 + 3000,
      uptime: Math.floor(Math.random() * 86400),
      model: 'Antminer S19 Pro',
      location: 'Rack C1'
    }

    setMiners([...miners, newMiner])
    setNewMinerName('')
    setShowAddForm(false)
  }

  const filteredMiners = miners.filter(miner => {
    const matchesSearch = miner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         miner.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         miner.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || miner.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusStats = () => {
    const online = miners.filter(m => m.status === 'online').length
    const offline = miners.filter(m => m.status === 'offline').length
    const warning = miners.filter(m => m.status === 'warning').length
    return { online, offline, warning, total: miners.length }
  }

  const stats = getStatusStats()

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-white/20 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-white/20 rounded"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-white/20 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center mb-8"
      >
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Mining Rigs</h1>
          <p className="text-white/70">
            Manage and monitor your cryptocurrency mining hardware
          </p>
        </div>
        <Button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Miner
        </Button>
      </motion.div>

      {/* Stats Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
      >
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Total Miners</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <Cpu className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Online</p>
                <p className="text-2xl font-bold text-green-400">{stats.online}</p>
              </div>
              <Activity className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Warnings</p>
                <p className="text-2xl font-bold text-yellow-400">{stats.warning}</p>
              </div>
              <Thermometer className="h-8 w-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Offline</p>
                <p className="text-2xl font-bold text-red-400">{stats.offline}</p>
              </div>
              <Cpu className="h-8 w-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Filters and Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-6"
      >
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex items-center space-x-2 flex-1">
                <Search className="h-4 w-4 text-white/60" />
                <Input
                  placeholder="Search miners by name, model, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-white/60" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
                >
                  <option value="all">All Status</option>
                  <option value="online">Online</option>
                  <option value="offline">Offline</option>
                  <option value="warning">Warning</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Add Miner Form */}
      {showAddForm && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Add New Miner</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Input
                  placeholder="Miner name (e.g., Antminer S19 Pro #7)"
                  value={newMinerName}
                  onChange={(e) => setNewMinerName(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50"
                />
                <Button onClick={addMiner} className="bg-green-600 hover:bg-green-700">
                  Add
                </Button>
                <Button 
                  onClick={() => setShowAddForm(false)} 
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Miners Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredMiners.map((miner, index) => (
          <motion.div
            key={miner.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
            whileHover={{ scale: 1.02 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg text-white">{miner.name}</CardTitle>
                    <CardDescription className="text-white/60">
                      {miner.model} • {miner.location}
                    </CardDescription>
                  </div>
                  <Badge variant={miner.status === "online" ? "secondary" : miner.status === "warning" ? "secondary" : "destructive"}>
                    {miner.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Activity className="h-4 w-4 text-blue-400" />
                      <div>
                        <p className="text-white/70 text-sm">Hash Rate</p>
                        <p className="text-white font-medium">{formatHashRate(miner.hashRate)}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Thermometer className={`h-4 w-4 ${miner.temperature > 75 ? 'text-red-400' : 'text-orange-400'}`} />
                      <div>
                        <p className="text-white/70 text-sm">Temperature</p>
                        <p className={`font-medium ${miner.temperature > 75 ? 'text-red-400' : 'text-white'}`}>
                          {miner.temperature}°C
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Zap className="h-4 w-4 text-yellow-400" />
                      <div>
                        <p className="text-white/70 text-sm">Power</p>
                        <p className="text-white font-medium">{formatPower(miner.power)}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-green-400" />
                      <div>
                        <p className="text-white/70 text-sm">Uptime</p>
                        <p className="text-white font-medium">{formatUptime(miner.uptime)}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1 border-white/20 text-white hover:bg-white/10">
                      <Settings className="h-4 w-4 mr-1" />
                      Configure
                    </Button>
                    <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                      <Activity className="h-4 w-4 mr-1" />
                      Monitor
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {filteredMiners.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <Cpu className="h-16 w-16 text-white/30 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">
            {searchTerm || statusFilter !== 'all' ? 'No miners match your filters' : 'No miners found'}
          </h3>
          <p className="text-white/60 mb-4">
            {searchTerm || statusFilter !== 'all' 
              ? 'Try adjusting your search or filter criteria'
              : 'Add your first mining rig to get started'
            }
          </p>
          {!searchTerm && statusFilter === 'all' && (
            <Button
              onClick={() => setShowAddForm(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Miner
            </Button>
          )}
        </motion.div>
      )}
    </div>
  )
}