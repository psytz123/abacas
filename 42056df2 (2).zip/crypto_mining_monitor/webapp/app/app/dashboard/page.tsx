'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Header from '@/components/header'
import Sidebar from '@/components/sidebar'
import StatsCards from '@/components/stats-cards'
import MiningCharts from '@/components/mining-charts'
import RigsList from '@/components/rigs-list'
import AlertsPanel from '@/components/alerts-panel'
import FiltersPanel from '@/components/filters-panel'

export default function DashboardPage() {
  const [filters, setFilters] = useState({
    timeRange: '24h',
    rigStatus: 'all',
    minHashrate: 0,
    maxHashrate: 1000,
    minTemperature: 0,
    maxTemperature: 100
  })

  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 ml-64 pt-16">
          <div className="p-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8"
            >
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Mining Dashboard
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Monitor your cryptocurrency mining operations in real-time
              </p>
            </motion.div>

            <FiltersPanel filters={filters} onFiltersChange={setFilters} />

            <motion.div
              ref={ref}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <StatsCards filters={filters} />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <MiningCharts filters={filters} />
            </motion.div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <motion.div
                className="xl:col-span-2"
                initial={{ opacity: 0, x: -30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <RigsList filters={filters} />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.8 }}
              >
                <AlertsPanel />
              </motion.div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}