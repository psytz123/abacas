'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  Zap, 
  TrendingUp, 
  Settings, 
  Play, 
  Pause,
  BarChart3,
  Cpu,
  Thermometer
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface OptimizationProfile {
  id: string
  name: string
  description: string
  applied: boolean
  performance: number
  efficiency: number
}

interface AIData {
  dynamicTuning: {
    enabled: boolean
    currentProfile: string
    performance: number
  }
  predictions: {
    hashRate: number
    power: number
    efficiency: number
  }
}

export default function AIOptimization() {
  const [loading, setLoading] = useState(true)
  const [aiData, setAIData] = useState<AIData | null>(null)
  const [profiles] = useState<OptimizationProfile[]>([
    {
      id: '1',
      name: 'Performance Mode',
      description: 'Maximize hash rate performance',
      applied: true,
      performance: 95,
      efficiency: 85
    },
    {
      id: '2',
      name: 'Efficiency Mode',
      description: 'Optimize for power efficiency',
      applied: false,
      performance: 80,
      efficiency: 95
    },
    {
      id: '3',
      name: 'Balanced Mode',
      description: 'Balance between performance and efficiency',
      applied: false,
      performance: 88,
      efficiency: 90
    }
  ])

  useEffect(() => {
    // Simulate loading AI data
    const timer = setTimeout(() => {
      setAIData({
        dynamicTuning: {
          enabled: true,
          currentProfile: 'Performance Mode',
          performance: 95
        },
        predictions: {
          hashRate: 1250.5,
          power: 8500,
          efficiency: 92.3
        }
      })
      setLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading AI optimization...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">AI Optimization</h1>
          <p className="text-white/70">
            Leverage artificial intelligence to optimize your mining operations automatically
          </p>
        </motion.div>

        {/* Optimization Profiles */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Optimization Profiles
              </CardTitle>
              <CardDescription className="text-white/70">
                Choose from pre-configured optimization profiles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {profiles.map((profile) => (
                  <motion.div
                    key={profile.id}
                    whileHover={{ scale: 1.02 }}
                    className="p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between">
                      <CardTitle>{profile.name}</CardTitle>
                      <Badge variant={profile.applied ? "secondary" : "outline"}>
                        {profile.applied ? "Applied" : "Not Applied"}
                      </Badge>
                    </div>
                    <CardDescription className="text-white/70 mt-2 mb-4">
                      {profile.description}
                    </CardDescription>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span className="text-white/60">Performance:</span>
                        <span className="text-white">{profile.performance}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Efficiency:</span>
                        <span className="text-white">{profile.efficiency}%</span>
                      </div>
                    </div>
                    <Button 
                      className={profile.applied ? "bg-gray-600" : "bg-blue-600 hover:bg-blue-700"}
                      disabled={profile.applied}
                      size="sm"
                    >
                      {profile.applied ? "Currently Applied" : "Apply Profile"}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Dynamic Tuning */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Dynamic Tuning Status</CardTitle>
                  <Badge variant={loading ? "outline" : (aiData?.dynamicTuning?.enabled ? "secondary" : "outline")}>
                    {loading ? "Loading..." : (aiData?.dynamicTuning?.enabled ? "Enabled" : "Disabled")}
                  </Badge>
                </div>
                <CardDescription className="text-white/70">
                  Real-time AI-powered optimization
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Current Profile:</span>
                    <span className="text-white font-medium">{aiData?.dynamicTuning?.currentProfile}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Performance:</span>
                    <span className="text-white font-medium">{aiData?.dynamicTuning?.performance}%</span>
                  </div>
                  <div className="flex space-x-2">
                    <Button className="bg-green-600 hover:bg-green-700" size="sm">
                      <Play className="h-4 w-4 mr-1" />
                      Start
                    </Button>
                    <Button variant="destructive" size="sm">
                      <Pause className="h-4 w-4 mr-1" />
                      Pause
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* AI Predictions */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="h-5 w-5 mr-2" />
                  AI Predictions
                </CardTitle>
                <CardDescription className="text-white/70">
                  Predicted performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Cpu className="h-4 w-4 text-blue-400" />
                      <span className="text-white/70">Hash Rate:</span>
                    </div>
                    <span className="text-white font-medium">{aiData?.predictions?.hashRate} TH/s</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Zap className="h-4 w-4 text-yellow-400" />
                      <span className="text-white/70">Power:</span>
                    </div>
                    <span className="text-white font-medium">{aiData?.predictions?.power} W</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-green-400" />
                      <span className="text-white/70">Efficiency:</span>
                    </div>
                    <span className="text-white font-medium">{aiData?.predictions?.efficiency}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Performance Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Optimization Performance
              </CardTitle>
              <CardDescription className="text-white/70">
                Track the impact of AI optimizations over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center">
                <div className="text-white/60">
                  Performance chart would be displayed here
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}