'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  BarChart3, 
  TrendingUp, 
  Calendar,
  Activity,
  Zap,
  Thermometer,
  DollarSign
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ChartCard } from "@/components/dashboard/chart-card";
import { 
  historicalHashrate, 
  historicalEarnings, 
  historicalEfficiency,
  historicalTemperature,
  type HistoricalData
} from "@/lib/mock-data";

export default function HistoricalAnalysis() {
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState('30d')
  const [selectedMetric, setSelectedMetric] = useState('hashrate')

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 1000)
    return () => clearTimeout(timer)
  }, [])

  const getMetricData = (): HistoricalData[] => {
    switch (selectedMetric) {
      case 'hashrate':
        return historicalHashrate
      case 'earnings':
        return historicalEarnings
      case 'efficiency':
        return historicalEfficiency
      case 'temperature':
        return historicalTemperature
      default:
        return historicalHashrate
    }
  }

  const getMetricInfo = () => {
    const data = getMetricData()
    const latest = data[data.length - 1]?.value || 0
    const previous = data[data.length - 2]?.value || 0
    const change = ((latest - previous) / previous * 100).toFixed(1)
    const trend = latest > previous ? 'up' : 'down'

    switch (selectedMetric) {
      case 'hashrate':
        return {
          title: 'Hash Rate',
          value: `${latest.toFixed(1)} TH/s`,
          change: `${change}% from yesterday`,
          trend,
          icon: <Activity className="h-5 w-5 text-blue-400" />
        }
      case 'earnings':
        return {
          title: 'Daily Earnings',
          value: `$${latest.toFixed(2)}`,
          change: `${change}% from yesterday`,
          trend,
          icon: <DollarSign className="h-5 w-5 text-green-400" />
        }
      case 'efficiency':
        return {
          title: 'Efficiency',
          value: `${latest.toFixed(1)}%`,
          change: `${change}% from yesterday`,
          trend,
          icon: <Zap className="h-5 w-5 text-yellow-400" />
        }
      case 'temperature':
        return {
          title: 'Average Temperature',
          value: `${latest.toFixed(1)}°C`,
          change: `${change}% from yesterday`,
          trend,
          icon: <Thermometer className="h-5 w-5 text-red-400" />
        }
      default:
        return {
          title: 'Hash Rate',
          value: `${latest.toFixed(1)} TH/s`,
          change: `${change}% from yesterday`,
          trend,
          icon: <Activity className="h-5 w-5 text-blue-400" />
        }
    }
  }

  const calculateStats = (data: HistoricalData[]) => {
    if (data.length === 0) return { avg: 0, min: 0, max: 0 }
    
    const values = data.map(d => d.value)
    const avg = values.reduce((sum, val) => sum + val, 0) / values.length
    const min = Math.min(...values)
    const max = Math.max(...values)
    
    return { avg, min, max }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading historical analysis...</div>
      </div>
    )
  }

  const metricInfo = getMetricInfo()
  const currentData = getMetricData()
  const stats = calculateStats(currentData)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Historical Analysis</h1>
          <p className="text-white/70">
            Analyze historical performance data and identify trends in your mining operations
          </p>
        </motion.div>

        {/* Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6 flex flex-col sm:flex-row gap-4"
        >
          {/* Time Range Selector */}
          <div className="flex space-x-2">
            {['7d', '30d', '90d', '1y'].map((range) => (
              <Button
                key={range}
                variant={timeRange === range ? "default" : "outline"}
                onClick={() => setTimeRange(range)}
                className={timeRange === range ? "bg-blue-600 hover:bg-blue-700" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}
                size="sm"
              >
                {range}
              </Button>
            ))}
          </div>

          {/* Metric Selector */}
          <div className="flex space-x-2">
            {[
              { key: 'hashrate', label: 'Hash Rate' },
              { key: 'earnings', label: 'Earnings' },
              { key: 'efficiency', label: 'Efficiency' },
              { key: 'temperature', label: 'Temperature' }
            ].map((metric) => (
              <Button
                key={metric.key}
                variant={selectedMetric === metric.key ? "default" : "outline"}
                onClick={() => setSelectedMetric(metric.key)}
                className={selectedMetric === metric.key ? "bg-purple-600 hover:bg-purple-700" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}
                size="sm"
              >
                {metric.label}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Main Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <ChartCard
            title={metricInfo.title}
            description={`Historical ${metricInfo.title.toLowerCase()} data over the last ${timeRange}`}
            value={metricInfo.value}
            change={metricInfo.change}
            trend={metricInfo.trend as 'up' | 'down'}
            icon={metricInfo.icon}
          >
            <div className="h-64 flex items-center justify-center bg-white/5 rounded-lg border border-white/10">
              <div className="text-white/60">
                {metricInfo.title} chart would be displayed here
              </div>
            </div>
          </ChartCard>
        </motion.div>

        {/* Statistics Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Average</p>
                  <p className="text-2xl font-bold text-white">
                    {selectedMetric === 'earnings' ? `$${stats.avg.toFixed(2)}` :
                     selectedMetric === 'efficiency' ? `${stats.avg.toFixed(1)}%` :
                     selectedMetric === 'temperature' ? `${stats.avg.toFixed(1)}°C` :
                     `${stats.avg.toFixed(1)} TH/s`}
                  </p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Minimum</p>
                  <p className="text-2xl font-bold text-white">
                    {selectedMetric === 'earnings' ? `$${stats.min.toFixed(2)}` :
                     selectedMetric === 'efficiency' ? `${stats.min.toFixed(1)}%` :
                     selectedMetric === 'temperature' ? `${stats.min.toFixed(1)}°C` :
                     `${stats.min.toFixed(1)} TH/s`}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm">Maximum</p>
                  <p className="text-2xl font-bold text-white">
                    {selectedMetric === 'earnings' ? `$${stats.max.toFixed(2)}` :
                     selectedMetric === 'efficiency' ? `${stats.max.toFixed(1)}%` :
                     selectedMetric === 'temperature' ? `${stats.max.toFixed(1)}°C` :
                     `${stats.max.toFixed(1)} TH/s`}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Data Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Historical Data
              </CardTitle>
              <CardDescription className="text-white/70">
                Detailed {metricInfo.title.toLowerCase()} data for the selected time period
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-3 px-4 text-white/80 font-medium">Date</th>
                      <th className="text-left py-3 px-4 text-white/80 font-medium">{metricInfo.title}</th>
                      <th className="text-left py-3 px-4 text-white/80 font-medium">Change</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentData.slice(-10).map((dataPoint, index) => {
                      const prevValue = index > 0 ? currentData[currentData.length - 10 + index - 1].value : dataPoint.value
                      const change = ((dataPoint.value - prevValue) / prevValue * 100).toFixed(1)
                      const isPositive = dataPoint.value > prevValue
                      
                      return (
                        <tr key={dataPoint.timestamp} className="border-b border-white/10 hover:bg-white/5">
                          <td className="px-4 py-3 text-white">
                            {new Date(dataPoint.timestamp).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 text-white font-medium">
                            {selectedMetric === 'earnings' ? `$${dataPoint.value.toFixed(2)}` :
                             selectedMetric === 'efficiency' ? `${dataPoint.value.toFixed(1)}%` :
                             selectedMetric === 'temperature' ? `${dataPoint.value.toFixed(1)}°C` :
                             `${dataPoint.value.toFixed(1)} TH/s`}
                          </td>
                          <td className={`px-4 py-3 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                            {index > 0 ? `${isPositive ? '+' : ''}${change}%` : '-'}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}